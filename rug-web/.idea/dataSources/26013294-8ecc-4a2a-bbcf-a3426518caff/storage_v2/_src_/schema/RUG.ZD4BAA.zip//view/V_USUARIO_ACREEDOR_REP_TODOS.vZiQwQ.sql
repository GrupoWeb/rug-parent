create view V_USUARIO_ACREEDOR_REP_TODOS as
SELECT   RRTIP.ID_TRAMITE_TEMP,
            TRI.ID_TIPO_TRAMITE,
            RUA.ID_USUARIO AS USUARIO_LOGIN,
            RUA.ID_ACREEDOR AS ID_PERSONA,
            RUA.B_FIRMADO,
            RPP.PER_JURIDICA,
            CASE
               WHEN RPP.PER_JURIDICA IN ('PM')
               THEN
                  (SELECT   RAZON_SOCIAL
                     FROM   RUG_PERSONAS_MORALES
                    WHERE   ID_PERSONA = RUA.ID_ACREEDOR)
            END
               AS RAZON_SOCIAL,
            DECODE (
               RPP.PER_JURIDICA,
               'PF',
               (SELECT      F.NOMBRE_PERSONA
                         || ' '
                         || F.AP_PATERNO
                         || ' '
                         || F.AP_MATERNO
                  FROM   RUG_PERSONAS_FISICAS F
                 WHERE   F.ID_PERSONA = RPP.ID_PERSONA),
               'PM',
               (SELECT   M.RAZON_SOCIAL
                  FROM   RUG_PERSONAS_MORALES M
                 WHERE   M.ID_PERSONA = RPP.ID_PERSONA)
            )
               AS NOMBRE_ACREEDOR,
            CASE
               WHEN RPP.PER_JURIDICA IN ('PF')
               THEN
                  (SELECT   NOMBRE_PERSONA
                     FROM   RUG_PERSONAS_FISICAS
                    WHERE   ID_PERSONA = RUA.ID_ACREEDOR)
            END
               AS NOMBRE,
            CASE
               WHEN RPP.PER_JURIDICA IN ('PF')
               THEN
                  (SELECT   AP_PATERNO
                     FROM   RUG_PERSONAS_FISICAS
                    WHERE   ID_PERSONA = RUA.ID_ACREEDOR)
            END
               AS AP_PATERNO,
            CASE
               WHEN RPP.PER_JURIDICA IN ('PF')
               THEN
                  (SELECT   AP_MATERNO
                     FROM   RUG_PERSONAS_FISICAS
                    WHERE   ID_PERSONA = RUA.ID_ACREEDOR)
            END
               AS AP_MATERNO,
            RPP.FOLIO_MERCANTIL,
            RPP.RFC,
            DECODE (RPP.PER_JURIDICA,
                    'PF',
                    (SELECT   CURP
                       FROM   RUG_PERSONAS_FISICAS
                      WHERE   ID_PERSONA = RUA.ID_ACREEDOR),
                    'PM',
                    (SELECT   CURP_DOC
                       FROM   RUG_PERSONAS
                      WHERE   ID_PERSONA = RUA.ID_ACREEDOR))
               AS CURP,
            RPP.ID_DOMICILIO,
            RDM.CALLE,
            '' CALLE_COLINDANTE_1,
            '' CALLE_COLINDANTE_2,
            RDM.LOCALIDAD,
            RDM.NUM_EXTERIOR,
            RDM.NUM_INTERIOR,
            RDM.ID_COLONIA,
            RDM.NOM_COLONIA DESC_COLONIA,
            RDM.ID_LOCALIDAD,
            RDM.LOCALIDAD DESC_LOCALIDAD,
            RDM.CVE_ESTADO,
            RDM.CVE_PAIS,
            RDM.CVE_DELEG_MUNICIP CVE_MUNICIP_DELEG,
            RDM.CODIGO_POSTAL,
            RCN.ID_NACIONALIDAD,
            RCN.DESC_NACIONALIDAD,
            RT.CLAVE_PAIS,
            RT.TELEFONO,
            RT.EXTENSION,
            RPP.E_MAIL,
            RDM.ID_PAIS_RESIDENCIA,
            RDM.UBICA_DOMICILIO_1,
            RDM.UBICA_DOMICILIO_2,
            RDM.POBLACION,
            RDM.ZONA_POSTAL
     FROM                     REL_USU_ACREEDOR RUA
                           INNER JOIN
                              RUG_PERSONAS RPP
                           ON RPP.ID_PERSONA = RUA.ID_ACREEDOR
                        LEFT JOIN
                           RUG_CAT_NACIONALIDADES RCN
                        ON RCN.ID_NACIONALIDAD = RPP.ID_NACIONALIDAD
                     LEFT JOIN
                        RUG_TELEFONOS RT
                     ON RT.ID_PERSONA = RPP.ID_PERSONA
                  LEFT JOIN
                     V_DOMICILIOS RDM
                  ON RPP.ID_DOMICILIO = RDM.ID_DOMICILIO
               INNER JOIN
                  RUG_REL_TRAM_INC_PARTES RRTIP
               ON RUA.ID_ACREEDOR = RRTIP.ID_PERSONA
            INNER JOIN
               TRAMITES_RUG_INCOMP TRI
            ON RRTIP.ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP
    WHERE       RUA.STATUS_REG = 'AC'
            AND RRTIP.ID_PARTE = 4
            AND TRI.ID_TIPO_TRAMITE = 12
            AND TRI.id_tramite_temp NOT IN
                     (SELECT   DISTINCT A.ID_TRAMITE_TEMP
                        FROM   RUG_FIRMA_MASIVA A, TRAMITES_RUG_INCOMP B
                       WHERE       B.ID_TRAMITE_TEMP = A.ID_TRAMITE_TEMP
                               AND B.ID_TIPO_TRAMITE = 12
                               AND B.ID_STATUS_TRAM = 5)
   UNION ALL
   SELECT   RRTIP.ID_TRAMITE_TEMP,
            TRI.ID_TIPO_TRAMITE,
            RRMA.ID_USUARIO_MODIFICA AS USUARIO_LOGIN,
            RRMA.ID_ACREEDOR_NUEVO AS ID_PERSONA,
            RRMA.B_FIRMADO,
            RPP.PER_JURIDICA,
            CASE
               WHEN RPP.PER_JURIDICA IN ('PM')
               THEN
                  (SELECT   RAZON_SOCIAL
                     FROM   RUG_PERSONAS_MORALES
                    WHERE   ID_PERSONA = RRMA.ID_ACREEDOR)
            END
               AS RAZON_SOCIAL,
            DECODE (
               RPP.PER_JURIDICA,
               'PF',
               (SELECT      F.NOMBRE_PERSONA
                         || ' '
                         || F.AP_PATERNO
                         || ' '
                         || F.AP_MATERNO
                  FROM   RUG_PERSONAS_FISICAS F
                 WHERE   F.ID_PERSONA = RPP.ID_PERSONA),
               'PM',
               (SELECT   M.RAZON_SOCIAL
                  FROM   RUG_PERSONAS_MORALES M
                 WHERE   M.ID_PERSONA = RPP.ID_PERSONA)
            )
               AS NOMBRE_ACREEDOR,
            CASE
               WHEN RPP.PER_JURIDICA IN ('PF')
               THEN
                  (SELECT   NOMBRE_PERSONA
                     FROM   RUG_PERSONAS_FISICAS
                    WHERE   ID_PERSONA = RRMA.ID_ACREEDOR)
            END
               AS NOMBRE,
            CASE
               WHEN RPP.PER_JURIDICA IN ('PF')
               THEN
                  (SELECT   AP_PATERNO
                     FROM   RUG_PERSONAS_FISICAS
                    WHERE   ID_PERSONA = RRMA.ID_ACREEDOR)
            END
               AS AP_PATERNO,
            CASE
               WHEN RPP.PER_JURIDICA IN ('PF')
               THEN
                  (SELECT   AP_MATERNO
                     FROM   RUG_PERSONAS_FISICAS
                    WHERE   ID_PERSONA = RRMA.ID_ACREEDOR)
            END
               AS AP_MATERNO,
            RPP.FOLIO_MERCANTIL,
            RPP.RFC,
            DECODE (RPP.PER_JURIDICA,
                    'PF',
                    (SELECT   CURP
                       FROM   RUG_PERSONAS_FISICAS
                      WHERE   ID_PERSONA = RRMA.ID_ACREEDOR),
                    'PM',
                    (SELECT   CURP_DOC
                       FROM   RUG_PERSONAS
                      WHERE   ID_PERSONA = RRMA.ID_ACREEDOR))
               AS CURP,
            RPP.ID_DOMICILIO,
            RDM.CALLE,
            '' CALLE_COLINDANTE_1,
            '' CALLE_COLINDANTE_2,
            RDM.LOCALIDAD,
            RDM.NUM_EXTERIOR,
            RDM.NUM_INTERIOR,
            RDM.ID_COLONIA,
            RDM.NOM_COLONIA DESC_COLONIA,
            RDM.ID_LOCALIDAD,
            RDM.LOCALIDAD DESC_LOCALIDAD,
            RDM.CVE_ESTADO,
            RDM.CVE_PAIS,
            RDM.CVE_DELEG_MUNICIP CVE_MUNICIP_DELEG,
            RDM.CODIGO_POSTAL,
            RCN.ID_NACIONALIDAD,
            RCN.DESC_NACIONALIDAD,
            RT.CLAVE_PAIS,
            RT.TELEFONO,
            RT.EXTENSION,
            RPP.E_MAIL,
            RDM.ID_PAIS_RESIDENCIA,
            RDM.UBICA_DOMICILIO_1,
            RDM.UBICA_DOMICILIO_2,
            RDM.POBLACION,
            RDM.ZONA_POSTAL
     FROM                     RUG_REL_MODIFICA_ACREEDOR RRMA
                           INNER JOIN
                              RUG_PERSONAS RPP
                           ON RPP.ID_PERSONA = RRMA.ID_ACREEDOR_NUEVO
                        LEFT JOIN
                           RUG_CAT_NACIONALIDADES RCN
                        ON RCN.ID_NACIONALIDAD = RPP.ID_NACIONALIDAD
                     LEFT JOIN
                        RUG_TELEFONOS RT
                     ON RT.ID_PERSONA = RPP.ID_PERSONA
                  LEFT JOIN
                     V_DOMICILIOS RDM
                  ON RPP.ID_DOMICILIO = RDM.ID_DOMICILIO
               INNER JOIN
                  RUG_REL_TRAM_INC_PARTES RRTIP
               ON RRMA.ID_ACREEDOR_NUEVO = RRTIP.ID_PERSONA
            INNER JOIN
               TRAMITES_RUG_INCOMP TRI
            ON RRTIP.ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP
    WHERE       RRMA.STATUS_REG = 'AC'
            AND RRTIP.ID_PARTE = 4
            AND TRI.ID_TIPO_TRAMITE = 19
            AND TRI.id_tramite_temp NOT IN
                     (SELECT   DISTINCT A.ID_TRAMITE_TEMP
                        FROM   RUG_FIRMA_MASIVA A, TRAMITES_RUG_INCOMP B
                       WHERE       B.ID_TRAMITE_TEMP = A.ID_TRAMITE_TEMP
                               AND B.ID_TIPO_TRAMITE = 12
                               AND B.ID_STATUS_TRAM = 5)

--   UNION ALL
--   SELECT   RFM.ID_FIRMA_MASIVA ID_TRAMITE_TEMP,
--            TRI.ID_TIPO_TRAMITE,
--            TRI.ID_PERSONA AS USUARIO_LOGIN,
--            0 ID_PERSONA,
--            'N' B_FIRMADO,
--            '' PER_JURIDICA,
--            '' RAZON_SOCIAL,
--            'CARGA MASIVA DE ACREEDORES' NOMBRE_ACREEDOR,
--            '' NOMBRE,
--            '' AP_PATERNO,
--            '' AP_MATERNO,
--            '' FOLIO_MERCANTIL,
--            '' RFC,
--            '' CURP,
--            0 ID_DOMICILIO,
--            '' CALLE,
--            '' CALLE_COLINDANTE_1,
--            '' CALLE_COLINDANTE_2,
--            '' LOCALIDAD,
--            '' NUM_EXTERIOR,
--            '' NUM_INTERIOR,
--            0 ID_COLONIA,
--            '' DESC_COLONIA,
--            0 ID_LOCALIDAD,
--            '' DESC_LOCALIDAD,
--            '' CVE_ESTADO,
--            '' CVE_PAIS,
--            0 CVE_MUNICIP_DELEG,
--            '' CODIGO_POSTAL,
--            0 ID_NACIONALIDAD,
--            '' DESC_NACIONALIDAD,
--            '' CLAVE_PAIS,
--            '' TELEFONO,
--            '' EXTENSION,
--            '' E_MAIL,
--            0 ID_PAIS_RESIDENCIA,
--            '' UBICA_DOMICILIO_1,
--            '' UBICA_DOMICILIO_2,
--            '' POBLACION,
--            '' ZONA_POSTAL
--     FROM   RUG_FIRMA_MASIVA RFM, TRAMITES_RUG_INCOMP TRI
--    WHERE       RFM.ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP
--            AND TRI.ID_STATUS_TRAM = 5
--            AND TRI.ID_TIPO_TRAMITE = 12;;
/

