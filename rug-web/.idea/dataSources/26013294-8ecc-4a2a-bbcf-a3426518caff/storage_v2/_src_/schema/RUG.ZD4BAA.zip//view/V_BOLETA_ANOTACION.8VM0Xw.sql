create view V_BOLETA_ANOTACION as
SELECT   S.ID_TRAMITE,
            S.VIGENCIA_ANOTACION,
            TO_CHAR (RBB.FECHA_STATUS, 'DD/MM/YYYY - HH24:MI:SS')
            || DECODE ( (SELECT   COUNT ( * )
                           FROM   V_FIRMA_DOCTOS
                          WHERE   ID_TRAMITE_TEMP = S.ID_TRAMITE_TEMP),
                       1, ' * ZULU GMT / UTC',
                       ' * Hora central Mexico, D.F.')
               AS FECHA_CREACION,
            S.ID_USUARIO,
            S.NOMBRE_USUARIO,
            S.ANOTACION,
            S.RESOLUCION,
            S.AUTORIDAD_INSTRUYE,
            S.PERFIL,
            S.FOLIO_OTORGANTE
     FROM      (SELECT   T.ID_TRAMITE,
                         CAST (RASG.VIGENCIA_ANOTACION AS VARCHAR (10))
                         || ' Meses'
                            VIGENCIA_ANOTACION,
                         T.ID_PERSONA AS ID_USUARIO,
                            RPH.NOMBRE_PERSONA
                         || ' '
                         || RPH.AP_PATERNO
                         || ' '
                         || RPH.AP_MATERNO
                            AS NOMBRE_USUARIO,
                         RASG.ANOTACION,
                         NULL AS RESOLUCION,   -- MMESCN2013-81 GGR 26/08/2013
                         RASG.AUTORIDAD_AUTORIZA AS AUTORIDAD_INSTRUYE,
                         RPH.CVE_PERFIL AS PERFIL,
                         (SELECT   DISTINCT RPP.FOLIO_MERCANTIL
                            FROM   RUG_PERSONAS RPP, RUG_REL_TRAM_PARTES RRT
                           WHERE       RPP.ID_PERSONA = RRT.ID_PERSONA
                                   AND RRT.ID_PARTE = 1
                                   AND RRT.ID_TRAMITE = T.ID_TRAMITE)
                            AS FOLIO_OTORGANTE,
                         T.ID_TRAMITE_TEMP
                  FROM   TRAMITES T,
                         RUG_PERSONAS_H RPH,
                         RUG_ANOTACIONES_SIN_GARANTIA RASG
                 WHERE       RPH.ID_TRAMITE = T.ID_TRAMITE
                         AND RASG.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
                         AND T.ID_TIPO_TRAMITE = 10
                         AND RPH.ID_PARTE = 5
                UNION ALL
                SELECT   T.ID_TRAMITE,
                         CAST (RASG.VIGENCIA_ANOTACION AS VARCHAR (10))
                         || ' Meses'
                            VIGENCIA_ANOTACION,
                         T.ID_PERSONA AS ID_USUARIO,
                            RPH.NOMBRE_PERSONA
                         || ' '
                         || RPH.AP_PATERNO
                         || ' '
                         || RPH.AP_MATERNO,
                         RASG.ANOTACION,
                         NULL AS RESOLUCION,   -- MMESCN2013-81 GGR 26/08/2013
                         RASG.AUTORIDAD_AUTORIZA,
                         RPH.CVE_PERFIL,
                         (SELECT   DISTINCT RPP.FOLIO_MERCANTIL
                            FROM   RUG_PERSONAS RPP, RUG_REL_TRAM_PARTES RRT
                           WHERE       RPP.ID_PERSONA = RRT.ID_PERSONA
                                   AND RRT.ID_PARTE = 1
                                   AND RRT.ID_TRAMITE = T.ID_TRAMITE),
                         T.ID_TRAMITE_TEMP
                  FROM   RUG_PERSONAS_H RPH, TRAMITES T, RUG_ANOTACIONES RASG
                 WHERE       RPH.ID_TRAMITE = T.ID_TRAMITE
                         AND RASG.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
                         AND RPH.ID_PARTE = 5
                UNION ALL
                /* MMESCN2013-81 GGR 23/08/2013 INICIO*/
                SELECT   T.ID_TRAMITE,
                         CAST (A.VIGENCIA AS VARCHAR (10)) || ' Meses',
                         T.ID_PERSONA,
                            P.NOMBRE_PERSONA
                         || ' '
                         || P.AP_PATERNO
                         || ' '
                         || P.AP_MATERNO,
                         A.ANOTACION,
                         A.RESOLUCION,
                         A.AUTORIDAD_AUTORIZA,
                         P.CVE_PERFIL,
                         (SELECT   DISTINCT RPP.FOLIO_MERCANTIL
                            FROM   RUG_PERSONAS RPP, RUG_REL_TRAM_PARTES RRT
                           WHERE       RPP.ID_PERSONA = RRT.ID_PERSONA
                                   AND RRT.ID_PARTE = 1
                                   AND RRT.ID_TRAMITE = T.ID_TRAMITE),
                         T.ID_TRAMITE_TEMP
                  FROM         RUG.RUG_ANOTACIONES_SEG_INC_CSG A
                            INNER JOIN
                               RUG.TRAMITES T
                            ON T.ID_TRAMITE_TEMP = A.ID_ANOTACION_TEMP
                         INNER JOIN
                            RUG.RUG_PERSONAS_H P
                         ON P.ID_TRAMITE = T.ID_TRAMITE AND P.ID_PARTE = 5 /* MMESCN2013-81 GGR 23/08/2013 FIN*/
                                                                          ) S
            INNER JOIN
               RUG.RUG_BITAC_TRAMITES RBB
            ON RBB.ID_TRAMITE_TEMP = S.ID_TRAMITE_TEMP
    WHERE   RBB.ID_STATUS = 3
/

