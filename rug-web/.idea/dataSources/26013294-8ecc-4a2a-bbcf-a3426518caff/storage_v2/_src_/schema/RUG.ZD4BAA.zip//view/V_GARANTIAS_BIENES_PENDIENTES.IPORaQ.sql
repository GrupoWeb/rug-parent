create view V_GARANTIAS_BIENES_PENDIENTES as
SELECT   DISTINCT RGG.ID_GARANTIA_PEND,
                       GGT.ID_TIPO_BIEN,
                       BNT.DESC_TIPO_BIEN,
                       GGT.RELACION_BIEN
       FROM         RUG_GARANTIAS_PENDIENTES RGG
                 INNER JOIN
                    RUG_REL_GAR_TIPO_BIEN GGT
                 ON RGG.ID_GARANTIA_PEND = GGT.ID_GARANTIA_PEND
              INNER JOIN
                 RUG_CAT_TIPO_BIEN BNT
              ON GGT.ID_TIPO_BIEN = BNT.ID_TIPO_BIEN
      WHERE   RGG.GARANTIA_STATUS = 'AC'
   ORDER BY   ID_GARANTIA_PEND
/

