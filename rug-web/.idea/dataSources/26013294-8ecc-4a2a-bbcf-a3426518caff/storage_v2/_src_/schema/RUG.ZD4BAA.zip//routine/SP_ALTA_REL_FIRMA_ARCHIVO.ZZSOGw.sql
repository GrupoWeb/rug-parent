create PROCEDURE         SP_ALTA_REL_FIRMA_ARCHIVO (               
                                                        peId_Firma_Masiva     IN  NUMBER,
                                                        peArchivo             IN  BLOB,  
                                                        peId_Usuario          IN  NUMBER,
                                                        psResult           OUT  NUMBER,
                                                        psTxResult         OUT  VARCHAR2   
                                                     )
IS

vlArchivo           NUMBER;
vlIdMail            NUMBER;
vlResult            NUMBER;
vlTxResult          VARCHAR2(500);
vlCveUsuario        VARCHAR2(50);
vlValorParametro    CLOB;
vlValorSubject      CLOB;

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_REL_FIRMA_ARCHIVO', 'peId_Firma_Masiva', peId_Firma_Masiva, 'IN');

    vlArchivo := SEQ_ARCHIVOXML.NEXTVAL;

    INSERT INTO RUG_ARCHIVO (ID_ARCHIVO, ID_USUARIO, ALGORITMO_HASH, NOMBRE_ARCHIVO, ARCHIVO, TIPO_ARCHIVO, DESCRIPCION, FECHA_REG, STATUS_REG)
    VALUES(vlArchivo, peId_Usuario, NULL,  SYSDATE || '.xml', peArchivo, 'xml', 'Archivo xml del resultado de una carga masiva', SYSDATE, 'AC');

    INSERT INTO RUG_REL_ARCHIVO_FIRMA_MASIVA(ID_REL_ARCH_FIRM, ID_FIRMA_MAISVA, ID_ARCHIVO, FECHA_REG, STATUS_REG)
    VALUES(RUG.SEQ_REL_ARCHIVO_FIRMA.NEXTVAL, peId_Firma_Masiva, vlArchivo, SYSDATE, 'AC');


    SELECT CVE_USUARIO
      INTO vlCveUsuario
      FROM RUG_SECU_USUARIOS
     WHERE ID_PERSONA = peId_Usuario;

    SELECT VALOR_PARAMETRO 
      INTO vlValorParametro
      FROM RUG.RUG_PARAMETRO_CONF
     WHERE CVE_PARAMETRO = 'mailCargaMasiva';

     SELECT VALOR_PARAMETRO 
       INTO vlValorSubject
       FROM RUG.RUG_PARAMETRO_CONF
      WHERE CVE_PARAMETRO = 'mailSubjectCargaMasiva';



    SP_ALTA_MAIL(
                  14,
                  1,
                  vlCveUsuario,
                  NULL,
                  NULL,
                  vlValorSubject,
                  vlValorParametro || vlArchivo,
                  vlIdMail,                                                
                  vlResult,
                  vlTxResult
                );

psResult := 0;    
psTxResult := 'proceso terminado con ?to';

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_REL_FIRMA_ARCHIVO', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_REL_FIRMA_ARCHIVO', 'psTxResult', psTxResult, 'OUT');


  EXCEPTION

   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_REL_FIRMA_ARCHIVO', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_REL_FIRMA_ARCHIVO', 'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE(psTxResult); 


END;
/

