create PROCEDURE         SP_ALTA_ANOTACION_MASIVA 
(
    peIdPersona                 IN     NUMBER, -- IDENTIFICADOR DE LA PESONA K SeLOGUEA
    peIdGarantia                IN     NUMBER,    
    peIdArchivo                 IN     NUMBER,
    peCveRastreo                IN     VARCHAR2,
    peVigencia                  IN     NUMBER,
    peAutoridad                 IN     VARCHAR2,
    peAnotacion                 IN     CLOB,
    psIdAcreedor               OUT     NUMBER,
    psIdTramiteIncompleto      OUT     NUMBER,
    psResult                   OUT     INTEGER,
    psTxResult                 OUT     VARCHAR2
)
IS


vlAcreedor                  CHAR(2);
vlPerJuridica               CHAR(2);

vlCantidad                  NUMBER;
vlIdAcreedor                NUMBER;
vlIdTipoTramite             NUMBER;
vlIdTramiteIncompleto       NUMBER;


Ex_Error EXCEPTION;


BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION_MASIVA', 'peIdPersona', peIdPersona, 'IN');    
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION_MASIVA', 'peIdGarantia', peIdGarantia, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION_MASIVA', 'peIdArchivo', peIdArchivo, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION_MASIVA', 'peCveRastreo', peCveRastreo, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION_MASIVA', 'peVigencia', peVigencia, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION_MASIVA', 'peAutoridad', peAutoridad, 'IN');


    SELECT COUNT(*)
      INTO vlCantidad
      FROM RUG_SECU_USUARIOS
     WHERE ID_PERSONA = peIdPersona;

     IF vlCantidad < 1 THEN

        psResult:= 2;
        RAISE Ex_Error;

     END IF;  

     vlCantidad:= 0;

    SELECT COUNT(*)
      INTO vlCantidad
      FROM RUG_GARANTIAS
     WHERE ID_GARANTIA = peIdGarantia;

     IF vlCantidad < 1 THEN

        psResult:= 14;
        RAISE Ex_Error;

     END IF;  


    SELECT B.ID_PERSONA, B.PER_JURIDICA 
      INTO vlIdAcreedor, vlPerJuridica
      FROM RUG_GARANTIAS A, 
           RUG_REL_TRAM_PARTES B
     WHERE A.ID_ULTIMO_TRAMITE = B.ID_TRAMITE
       AND B.ID_PARTE = 4
       AND A.ID_GARANTIA = peIdGarantia;

    BEGIN
        SELECT ID_TIPO_TRAMITE 
          INTO vlIdTipoTramite
          FROM (
                    SELECT ID_ACREEDOR, ID_TIPO_TRAMITE FROM V_TRAMITES_TERMINADOS
                     WHERE ID_GARANTIA = peIdGarantia
                     ORDER BY 1)
         WHERE ROWNUM < 2;

    EXCEPTION WHEN NO_DATA_FOUND THEN
        psResult := 14;
        RAISE Ex_Error;

    END;


    IF (vlIdTipoTramite = 4) THEN

        psResult := 59;
        RAISE Ex_Error;

    END IF;

    IF (peVigencia > 9999) THEN

        psResult := 74;
        RAISE Ex_Error;  

    END IF;


    BEGIN

        SP_ALTA_TRAMITE_RASTREO(peIdPersona, 2, vlIdAcreedor, vlPerJuridica, 0, NULL, SYSDATE, peCveRastreo, peIdArchivo,  
                                vlIdTramiteIncompleto, psResult, psTxResult);

        IF (psResult = 0) THEN                                            

            SP_ALTA_ANOTACION(peIdPersona, vlIdTramiteIncompleto, peIdGarantia, peAutoridad, peAnotacion, peVigencia, psResult, psTxResult);

            IF (psResult = 0) THEN

                SP_Alta_Bitacora_Tramite2(vlIdTramiteIncompleto, 5, 0, NULL, 'V', psResult, psTxResult);

                psIdAcreedor := vlIdAcreedor;
                psIdTramiteIncompleto := vlIdTramiteIncompleto;

            END IF;

        END IF;                

    END;

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION_MASIVA', 'psIdTramiteIncompleto', psIdTramiteIncompleto, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION_MASIVA', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION_MASIVA', 'psTxResult', psTxResult, 'OUT');


EXCEPTION


WHEN Ex_Error  THEN

      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);

      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION_MASIVA', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION_MASIVA', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;

WHEN OTHERS THEN

      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION_MASIVA', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ANOTACION_MASIVA', 'psTxResult', psTxResult, 'OUT');

END;
/

