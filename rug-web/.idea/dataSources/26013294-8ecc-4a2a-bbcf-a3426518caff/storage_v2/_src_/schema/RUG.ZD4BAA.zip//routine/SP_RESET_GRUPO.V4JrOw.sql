create PROCEDURE     SP_RESET_GRUPO 
(
    P_CVE_USUARIO   IN RUG.RUG_SECU_USUARIOS.CVE_USUARIO%TYPE,
    P_ID_GRUPO      IN RUG.RUG_GRUPOS.ID_GRUPO%TYPE,
    psResult        OUT  INTEGER,   
    psTxResult      OUT  VARCHAR2
)
IS
    V_PASS              VARCHAR2(400);

    EXC_SIN_PWD_DEF     EXCEPTION;
    EXC_MAIL_ERROR      EXCEPTION;


    PRAGMA AUTONOMOUS_TRANSACTION;

BEGIN 

    REG_PARAM_PLS2('SP_RESET_GRUPO', 'P_CVE_USUARIO', P_CVE_USUARIO, 'IN');
    REG_PARAM_PLS2('SP_RESET_GRUPO', 'P_ID_GRUPO', P_ID_GRUPO, 'IN');


    SELECT NVL(
                (SELECT P.CVE_PERFIL
                   FROM RUG.RUG_REL_GRUPO_PERFIL GP
                  INNER JOIN RUG.RUG_CAT_PERFILES P
                     ON P.ID_PERFIL = GP.ID_PERFIL
                  WHERE GP.ID_GRUPO = P_ID_GRUPO )
              , '')
      INTO V_PASS
      FROM DUAL;

    IF V_PASS = '' THEN

        RAISE EXC_SIN_PWD_DEF;

    END IF;



    UPDATE RUG.RUG_SECU_USUARIOS 
       SET ID_GRUPO = P_ID_GRUPO
         , FH_ULT_ACTUALIZACION = SYSDATE
     WHERE CVE_USUARIO = P_CVE_USUARIO; 

    UPDATE RUG.RUG_SECU_PERFILES_USUARIO
       SET CVE_PERFIL  = V_PASS
     WHERE CVE_USUARIO = P_CVE_USUARIO;        


    COMMIT;


    REG_PARAM_PLS2('SP_RESET_GRUPO', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS2('SP_RESET_GRUPO', 'psTxResult', psTxResult, 'OUT');

EXCEPTION
    WHEN EXC_SIN_PWD_DEF THEN
        psTxResult:= 25;
        psTxResult:= RUG.FN_MENSAJE_ERROR(psResult);
        ROLLBACK;
        REG_PARAM_PLS2('SP_RESET_GRUPO', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS2('SP_RESET_GRUPO', 'psTxResult', psTxResult, 'OUT');    


    WHEN OTHERS THEN
        psResult  := 999;   
        psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
        ROLLBACK;
        REG_PARAM_PLS2('SP_RESET_GRUPO', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS2('SP_RESET_GRUPO', 'psTxResult', psTxResult, 'OUT');    

END;
/

