create FUNCTION         FNDPSWENCRYPT (pePassword IN RUG_SECU_USUARIOS.PASSWORD%TYPE)
  RETURN RAW
IS
  l_ccn_raw         RAW (128);
  l_key             RAW (128);
  l_decrypted_raw   RAW (2048);
BEGIN
  l_ccn_raw := UTL_RAW.cast_to_raw (pePassword);
  RETURN LOWER (DBMS_CRYPTO.hash (l_ccn_raw, 3));
END fndPswEncrypt;
/

