create PROCEDURE           SP_CONSULTA_GARANTIAS_PRUEBA 
(    peDescBienMueble        IN VARCHAR2
   , peNombOtorganteGarantia IN VARCHAR2
   , peNumGarantiaMobiliaria IN NUMBER
   , peFolioElectronicoOtorg IN VARCHAR
   , pePagina                IN NUMBER
   , peOrden                 IN NUMBER
   , peNumPagina             IN NUMBER
   , psCursorConsulta       OUT SYS_REFCURSOR)

IS

vlCadenaAuxRegistro CLOB;

BEGIN                            


    OPEN psCursorConsulta FOR


    select * from V_BUSQUEDA_TRAMITE_BASE;


end SP_CONSULTA_GARANTIAS_PRUEBA;
/

