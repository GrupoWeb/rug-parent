create PROCEDURE           SP_RECUPERA_PASSWORD 
                        (
                             peCveUsuario            IN V_USUARIO_LOGIN_RUG.CVE_USUARIO%TYPE,
                             peRespPreg              IN RUG_SECU_USUARIOS.RESP_RECUPERA_PSW%TYPE,
                             peNuevoPass            IN RUG_SECU_USUARIOS.PASSWORD%TYPE,                             
                             psResult                OUT NUMBER,
                             psTxResult            OUT VARCHAR2
                        )


AS

vlCantidad          NUMBER;
vlRespuesta         VARCHAR(60);
vlIdError           NUMBER;
vlDescError         VARCHAR2 (255);
vlIdPersona         NUMBER;


Ex_ErrorProceso EXCEPTION;

BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RECUPERA_PASSWORD', 'peCveUsuario', peCveUsuario, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RECUPERA_PASSWORD', 'peRespPreg', peRespPreg, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RECUPERA_PASSWORD', 'peNuevoPass', peNuevoPass, 'IN');

    vlIdError  := 99;
    vlDescError := 'Error en el proceso';

    SELECT COUNT(*)
      INTO vlCantidad
      FROM RUG_SECU_USUARIOS
     WHERE lower(CVE_USUARIO) = lower(peCveUsuario)
       AND SIT_USUARIO = 'AC';

    IF(vlCantidad <> 1) THEN
        vlIdError   := -1;
        vlDescError := 'Error, Validar la clave de usuario';        
        RAISE Ex_ErrorProceso;
    END IF; 


    SELECT  RESP_RECUPERA_PSW, ID_PERSONA
      INTO  vlRespuesta, vlIdPersona
      FROM  RUG_SECU_USUARIOS
     WHERE lower(CVE_USUARIO) = lower(peCveUsuario)
       AND SIT_USUARIO = 'AC';



    IF(vlRespuesta = peRespPreg) THEN

        UPDATE RUG_SECU_USUARIOS
           SET PASSWORD = LOWER (fndPswEncrypt(peNuevoPass))
         WHERE lower(CVE_USUARIO) = lower(peCveUsuario)
           AND SIT_USUARIO = 'AC';


           vlIdError := 0;     
           vlDescError := 'Actualizacion exitosa';
           commit;

    ELSE 

        vlIdError := -2;
        vlDescError := 'Respuesta incorrecta';


    END IF;

    --dbms_output.put_line(peNuevoPass || ' - ' || fndPswEncrypt(peNuevoPass)); 

    psResult:= vlIdError;     
    psTxResult := vlDescError;

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RECUPERA_PASSWORD', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RECUPERA_PASSWORD', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION
    WHEN Ex_ErrorProceso THEN    
        psResult:= vlIdError;     
        psTxResult := vlDescError; 
        rollback;
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RECUPERA_PASSWORD', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RECUPERA_PASSWORD', 'psTxResult', psTxResult, 'OUT');    

END;
/

