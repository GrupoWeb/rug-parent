create FUNCTION     FN_TIENE_SALDO (pUserId IN VARCHAR2, pTipoTramite IN NUMBER, pIdTramite IN NUMBER) -- 0 NO_TIENE 1 TIENE
  RETURN NUMBER IS
  l_saldo       NUMBER;
  l_arancel     NUMBER;
  l_facturas    NUMBER;
  l_vehiculos   NUMBER;
  l_precio      NUMBER;
  v_usuario_maestro NUMBER;

  l_fecha_creacion TRAMITES.FECHA_CREACION%TYPE;
  vlDescMensajeError  VARCHAR(4000);
BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_TIENE_SALDO', 'pUserId', pUserId, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_TIENE_SALDO', 'pTipoTramite', pTipoTramite, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_TIENE_SALDO', 'pIdTramite', pIdTramite, 'IN');

	l_saldo := FN_CALCULAR_SALDO(pUserId);

    -- traslados con pago (es tramite temporales)
        l_fecha_creacion := SYSDATE;

        -- validamos vigencia
        BEGIN
            SELECT
                precio
            INTO l_precio
            FROM RUG_CAT_TIPO_TRAM_PAGO
            WHERE id_tipo_tramite = pTipoTramite
            AND VIGENCIA_PRECIO > TO_TIMESTAMP(l_fecha_creacion);

            EXCEPTION WHEN no_data_found THEN
            BEGIN
                SELECT
                    precio
                INTO l_precio
                FROM RUG_CAT_TIPO_TRAM_PAGO
                WHERE id_tipo_tramite = pTipoTramite
                AND VIGENCIA_PRECIO IS NULL;

                EXCEPTION WHEN no_data_found THEN
                BEGIN
                    SELECT
                       PRECIO
                    INTO   l_precio
                    FROM
                           RUG_CAT_TIPO_TRAMITE
                    WHERE
                           ID_TIPO_TRAMITE = pTipoTramite
                    ;
                END;
            END;
        END;

    IF pTipoTramite = 1 THEN

        SELECT COUNT(*) AS FACTURAS
        INTO l_facturas
        FROM RUG_GARANTIAS_BIENES_PEND
        WHERE ID_TRAMITE_TEMP = pIdTramite
        AND TIPO_BIEN_ESPECIAL = 2;

       l_arancel := 20*l_facturas;

        IF(NVL(l_arancel,0) = 0) THEN
           l_arancel := l_precio;
        END IF;

    ELSE 
        l_arancel := l_precio;
    END IF;

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_TIENE_SALDO', 'saldo', l_saldo - l_arancel, 'OUT');  

    IF (l_saldo - l_arancel) >=0 THEN
        RETURN 1;
    END IF;

    RETURN 0;

	EXCEPTION 
        WHEN OTHERS THEN
            vlDescMensajeError := SUBSTR(SQLCODE||'-'||SQLERRM,1,1000);  
            REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_PRECIO_REAL', 'error', vlDescMensajeError, 'OUT');
            RETURN NULL;
END;
/

