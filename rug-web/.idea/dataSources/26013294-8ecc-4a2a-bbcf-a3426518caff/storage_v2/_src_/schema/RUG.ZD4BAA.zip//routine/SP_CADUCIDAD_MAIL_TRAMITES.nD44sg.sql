create PROCEDURE           SP_CADUCIDAD_MAIL_TRAMITES 
(
  psResult OUT INTEGER  
, psTxResult OUT VARCHAR2  
) AS 

vlFechaFinVigencia  DATE;    
vlIdTramiteTemp     NUMBER;
vlIdTipoTramite     NUMBER;
vlIdGarantia        NUMBER; 
i                   NUMBER;

vlIdMail            NUMBER;
vlResult            NUMBER;
vlTxResult          VARCHAR2(500);

BEGIN
  --ACTUALIZO ESTADO ISRUNNING
  SP_LOG_JOBS_RUG(4, 1, 1);

  For i In(
            Select ID_TRAMITE_TEMP,ID_TRAMITE,ID_TIPO_TRAMITE,ID_GARANTIA,FECHA_TERM,USUARIO_MAIL, ACREEDOR,ACREEDOR_MAIL
            From V_TRAMITES_MAIL_VIGENCIA
          ) Loop
    sp_alta_mail( 10, 
                  1, 
                  i.ACREEDOR_MAIL, 
                  i.USUARIO_MAIL, 
                  Null, 
                  'Pr?a cancelaci?e Garant?', 
                  ' <HTML>
                    <head>            
                    </head>
                    <BODY>
                    <div ID="scroll"
                         STYLE="width:700px;height:400px;overflow:auto;">
                        <Table width="100%" height="100%" cellspacing="1" cellspacing="4" cellpadding="4" border="2" bordercolor=#01A9DB >
                        <tr>
                        <td>
                            <TABLE width="100%" height="100%">
                                    <TR>
                                            <TD width="100%" height="20%"  >
                                                    <table align="center" width="100%" height="100%">
                                                            <tr>
                                                                    <td align="center">
                                                                            <font face="arial" size="4" color="#045FB4">'|| 'Pr?a cancelaci?e Garant?' ||'</font> 
                                                                    </td>                                                
                                                            </tr>
                                                            <tr>
                                                                    <td align="right">
                                                                           <font face="arial" size="1" color="#0174DF"> M?co D.F. a '|| To_Char(Sysdate, 'Day') || To_Char(Sysdate, 'dd') ||' de ' || To_Char(sysdate, 'Month')||'del anio'|| To_Char(sysdate, 'Yyyy')||' </font>
                                                                    </td>
                                                            </tr>
                                                    </table>
                                            </TD>
                                    </TR>
                                    <TR>
                                            <TD width="100%" height="60%" align="center">
                                                    <table width="100%" height="100%">
                                                            <tr>
                                                                    <td align="center">
                                                                            <table>
                                                                                    <tr bgcolor="#FFFFFF">
                                                                                            <td class="labeltxt">
                                                                                                <font face="arial" size="2" color="#0174DF">'||'Estimado '||i.ACREEDOR||' le informamos que el n?o de garant?'||i.ID_GARANTIA||' con asiento '||i.ID_TRAMITE||' esta pr?a a vencer su vigencia en la fecha '||i.FECHA_TERM||'
                                                                                                                                                <br>
                                                                                                                                                <br> 
                                                                                                                                                Para ampliar la vigencia dirigase a "Mis Operaciones" de click en la que desee renovar e ingrese a la pesta?Ronovaci? Reducci?e vigencia".
                                                                                                                                                <br>
                                                                                                                                                <br>
                                                                                                                                                Muchas gracias, saludos                                                                         
                                                                                                </Font>
                                                                                            </td>
                                                                                    </tr>
                                                                            </table>
                                                                    </td>
                                                            </tr>
                                                    </table>
                                            </TD>
                                    </TR>
                                    <TR>
                                            <TD width="100%" height="20%" bgcolor="white" >
                                            </TD>
                                    </TR>
                            </TABLE>
                        </tr>
                        </td>
                        </table>
                    </div>
                    </BODY>
                    </HTML>',
--                  'Estimado usuario '||i.CVE_USUARIO||' le informamos que el n?o de garant?'||i.ID_GARANTIA||' con asiento '||i.ID_TRAMITE||' esta pr?a a vencer su vigencia en la fecha '||i.FECHA_TERM,
                  vlIdMail,
                  vlResult,
                  vlTxResult);

    psResult := 0;    
    psTxResult := 'proceso terminado con ?to';
  End Loop;


EXCEPTION

   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CADUCIDAD_MAIL_TRAMITES', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CADUCIDAD_MAIL_TRAMITES', 'psTxResult', psTxResult, 'OUT');

END SP_CADUCIDAD_MAIL_TRAMITES;
/

