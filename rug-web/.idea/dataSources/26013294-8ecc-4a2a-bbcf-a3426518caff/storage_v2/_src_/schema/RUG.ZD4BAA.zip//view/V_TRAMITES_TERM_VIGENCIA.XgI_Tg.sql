create view V_TRAMITES_TERM_VIGENCIA as
SELECT
         TRA.ID_TRAMITE_TEMP
       , TRA.ID_TIPO_TRAMITE
       , RGA.ID_GARANTIA
       , TO_CHAR ( TO_DATE ( TO_CHAR ( ADD_MONTHS ( DECODE (VTF.NOMBRE_TABLA, 'RUG_FIRMA_DOCTOS', RBB.FECHA_STATUS - 6 / 24, RBB.FECHA_STATUS), RGA.VIGENCIA*12 ), 'DD/MM/YYYY HH24:MI' ), 'DD/MM/YYYY HH24:MI' ) + 1 / (24 * 60), 'DD/MM/YYYY HH24:MI' )
  FROM
         RUG.RUG_GARANTIAS_H    RGH
       , RUG.TRAMITES           TRA
       , RUG.RUG_BITAC_TRAMITES RBB
       , (
                SELECT
                       ID_GARANTIA
                     , VIGENCIA
                FROM
                       RUG.RUG_GARANTIAS
                WHERE
                       GARANTIA_STATUS = 'AC'
         )
                          RGA
       , V_TRAMITES_FIRMA VTF
  WHERE
         RGH.ID_ULTIMO_TRAMITE   = TRA.ID_TRAMITE
         AND TRA.ID_TRAMITE_TEMP = RBB.ID_TRAMITE_TEMP
         AND RGH.ID_GARANTIA     = RGA.ID_GARANTIA
         AND TRA.ID_TIPO_TRAMITE IN (1, 31)
		 AND TRA.B_CARGA_MASIVA <> -1
         AND RBB.ID_STATUS                                  = 3
         AND RBB.STATUS_REG                                 = 'AC'
         AND TRA.ID_TRAMITE_TEMP                            = VTF.ID_TRAMITE_TEMP
         AND ADD_MONTHS (RBB.FECHA_STATUS, RGA.VIGENCIA*12) < SYSDATE
  UNION
  SELECT
         TRA.ID_TRAMITE_TEMP
       , TRA.ID_TIPO_TRAMITE
       , RGA.ID_GARANTIA
       , TO_CHAR( ADD_MONTHS (TO_DATE('15/04/2018 01:00:00','dd/MM/yyyy hh24:mi:ss'), RGA.VIGENCIA*12), 'DD/MM/YYYY HH24:MI' )
  FROM
         RUG.RUG_GARANTIAS_H    RGH
       , RUG.TRAMITES           TRA
       , RUG.RUG_BITAC_TRAMITES RBB
       , (
                SELECT
                       ID_GARANTIA
                     , VIGENCIA
                FROM
                       RUG.RUG_GARANTIAS
                WHERE
                       GARANTIA_STATUS = 'AC'
         )
                          RGA
       , V_TRAMITES_FIRMA VTF
  WHERE
         RGH.ID_ULTIMO_TRAMITE   = TRA.ID_TRAMITE
         AND TRA.ID_TRAMITE_TEMP = RBB.ID_TRAMITE_TEMP
         AND RGH.ID_GARANTIA     = RGA.ID_GARANTIA
         AND TRA.ID_TIPO_TRAMITE IN (1, 31)
		 AND TRA.B_CARGA_MASIVA = -1
         AND RBB.ID_STATUS                                  = 3
         AND RBB.STATUS_REG                                 = 'AC'
         AND TRA.ID_TRAMITE_TEMP                            = VTF.ID_TRAMITE_TEMP
         AND ADD_MONTHS (TO_DATE('15/04/2018 01:00:00','dd/MM/yyyy hh24:mi:ss'), RGA.VIGENCIA*12) < SYSDATE
/

