create view V_ANOTACION_SIN_GARANTIA as
SELECT   ANN.ID_TRAMITE_TEMP,
            ANN.ID_ANOTACION,
            ANN.AUTORIDAD_AUTORIZA,
            ANN.ID_PERSONA,
            RPP.PER_JURIDICA,
            RPP.FOLIO_MERCANTIL,
            RPP.RFC,
            RPF.CURP,
            ANN.ANOTACION,
            RPP.ID_NACIONALIDAD,
            RPF.NOMBRE_PERSONA,
            RPF.AP_PATERNO,
            RPF.AP_MATERNO,
            RPM.RAZON_SOCIAL,
            ANN.VIGENCIA_ANOTACION
     FROM               RUG_ANOTACIONES_SIN_GARANTIA ANN
                     LEFT JOIN
                        RUG_PERSONAS RPP
                     ON ANN.ID_PERSONA = RPP.ID_PERSONA
                  LEFT JOIN
                     RUG_PERSONAS_FISICAS RPF
                  ON ANN.ID_PERSONA = RPF.ID_PERSONA
               LEFT JOIN
                  RUG_PERSONAS_MORALES RPM
               ON ANN.ID_PERSONA = RPM.ID_PERSONA
            INNER JOIN
               RUG_BITAC_TRAMITES RBT
            ON RBT.ID_TRAMITE_TEMP = ANN.ID_TRAMITE_TEMP
               AND RBT.ID_STATUS = 5
/

