create PROCEDURE         SP_ALTA_PARTE_TRAM_INC_RAST (
   peIdPersona                 IN NUMBER, -- IDENTIFICADOR DE LA PESONA K SeLOGUEA
   peIdTipoTramite             IN NUMBER,
   peIdGarantia                IN NUMBER,
   peIdAcreedor                IN NUMBER,
   peIdArchivo                 IN NUMBER,
   peCveRastreo                IN VARCHAR2,
   peIdTramiteIncompleto      OUT NUMBER,
   psResult                   OUT INTEGER,
   psTxResult                 OUT VARCHAR2
)
IS
   vlCveRastreo             NUMBER;
   vlCantidad               NUMBER;
   vlIdTramiteRugIncom      NUMBER;
   vlIdGarantiaTemp         NUMBER;
   vlIdRelacionAnterior     NUMBER;
   vlRelacion               NUMBER;
   vlRelacionBienAnterior   NUMBER;
   vlIdGarantiaend          NUMBER;
   vlIdUltimoTramite        NUMBER;
   vlIdGarantiaPend         NUMBER;
   vlIdOtorgante            NUMBER;
   vlBanderaPrueba          NUMBER;
   vlAltaOtorgante          NUMBER;
   vlPais_residencia        NUMBER;
   vlIdTramite              NUMBER;
   vlParte                  NUMBER;
   vlTipoPersona            VARCHAR2 (2);
   vlRazonSocial            VARCHAR2 (350);
   vlNombre                 VARCHAR2 (60);
   vlAvlllidoP              VARCHAR2 (60);
   vlAvlllidoM              VARCHAR2 (60);
   vlFolioMercantil         VARCHAR2 (200);
   vlRFC                    VARCHAR2 (20);
   vlCURP                   VARCHAR2 (900);
   vlBDomicilio             CHAR;
   vlCalle                  VARCHAR2 (250);
   vlNumExt                 VARCHAR2 (50);
   vlNumInt                 VARCHAR2 (50);
   vlIdColonia              NUMBER;
   vlIdLocalidad            NUMBER;
   vlIdPersona              NUMBER;
   vlIdNacionalidad         NUMBER;
   vlTelefono               VARCHAR2 (50);
   vlExtension              VARCHAR2 (50);
   vlEmail                  VARCHAR2 (200);
   vlIdPersonaAlta          NUMBER;
   vlResult                 INTEGER;
   vlTxResult               VARCHAR2 (250);
   vlUbicaDomicilio1        VARCHAR2(200);
   vlUbicaDomicilio2        VARCHAR2(200);
   vlPoblacion              VARCHAR2(200);
   vlZonaPostal             VARCHAR2(30);       

   vlInscrita               VARCHAR2(250);
   vlFolio                  VARCHAR2(250);
   vlLibro                  VARCHAR2(250);
   vlUbicada                VARCHAR2(250);
   vlEdad                   VARCHAR2(250);
   vlEstadoCivil            VARCHAR2(250);
   vlProfesion              VARCHAR2(250);

   vlResultBien             INTEGER;
   vlTxResultBien           VARCHAR2(250);

   Ex_TipoTramite EXCEPTION;
   Ex_Error       EXCEPTION;
   Ex_Error1       EXCEPTION;

   CURSOR cursPartes (
      cpeIdGarantia   IN            NUMBER
   )
   IS
        SELECT   RPP.ID_PERSONA, RPP.ID_PARTE, REP.PER_JURIDICA
          FROM         RUG_REL_GARANTIA_PARTES RPP
                    INNER JOIN
                       RUG_GARANTIAS RGG
                    ON RPP.ID_RELACION = RGG.ID_RELACION
                 INNER JOIN
                    RUG_PERSONAS REP
                 ON RPP.ID_PERSONA = REP.ID_PERSONA
         WHERE       RPP.ID_GARANTIA = peIdGarantia
                 AND RPP.STATUS_REG = 'AC'
                 AND RPP.ID_PARTE <> 5
      ORDER BY   RPP.ID_PARTE ASC;

   cursPartes_Rec           cursPartes%ROWTYPE;
BEGIN
   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'peIdPersona', peIdPersona, 'IN');
   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'peIdTipoTramite', peIdTipoTramite, 'IN');
   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'peIdGarantia', peIdGarantia, 'IN');
   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'peIdAcreedor', peIdAcreedor, 'IN');
   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'peCveRastreo', peCveRastreo, 'IN');
   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'peIdArchivo', peIdArchivo, 'IN');


   --PL QUE DA DE ALTA UN TRAMITE INCOMPLETO Y COPIA TODAS LAS RELACIIONES DE PERSONAS DEL COMPLETO AL INCOMPLETO

   IF peIdTipoTramite NOT IN (7, 8, 6, 13)
   THEN
      RAISE Ex_TipoTramite;
   END IF;


   SELECT COUNT(*)
     INTO vlCantidad
     FROM RUG.V_TRAMITES_TERMINADOS
    WHERE ID_GARANTIA = peIdGarantia
      AND ID_STATUS_TRAM = 3
      AND ID_ACREEDOR = peIdAcreedor;

   IF(vlCantidad = 0) THEN

      psResult  := 60;
      RAISE Ex_Error;

   END IF;


    SELECT COUNT(*)
      INTO vlCveRastreo
      FROM RUG_TRAMITE_RASTREO
     WHERE CVE_RASTREO = peCveRastreo
       AND ID_ACREEDOR = peIdAcreedor
       AND STATUS_REG = 'AC';


   IF (vlCveRastreo != 0) THEN

        psResult:=58;   
        psTxResult:= REPLACE(RUG.FN_MENSAJE_ERROR(58), '@peCveRastreo', peCveRastreo);
        RAISE Ex_Error1; 

   END IF;

   vlIdTramiteRugIncom := SEQ_TRAM_INCOMP.NEXTVAL;
   vlIdGarantiaTemp := SEQ_GARANTIAS_TEMP.NEXTVAL;

   SELECT   ID_ULTIMO_TRAMITE
     INTO   vlIdUltimoTramite
     FROM   RUG_GARANTIAS
    WHERE   ID_GARANTIA = peIdGarantia;

   INSERT INTO TRAMITES_RUG_INCOMP
     VALUES   (vlIdTramiteRugIncom, peIdPersona, peIdTipoTramite, SYSDATE, NULL, 'AC', 0, 0, SYSDATE, 0);

   INSERT INTO RUG_BITAC_TRAMITES
     VALUES   (vlIdTramiteRugIncom, 0, SYSDATE, 0, peIdTipoTramite, SYSDATE, 'AC');


   INSERT INTO RUG_TRAMITE_RASTREO
   VALUES(SEQ_TRAM_RASTREO.NEXTVAL, peIdAcreedor, vlIdTramiteRugIncom, peCveRastreo, SYSDATE, 'AC', peIdArchivo);


   vlBanderaPrueba := 0;

   BEGIN
      FOR cursPartes_Rec IN cursPartes (peIdGarantia)
      LOOP
         SELECT   RPH.ID_PARTE,
                  RPH.PER_JURIDICA,
                  RPH.RAZON_SOCIAL,
                  RPH.NOMBRE_PERSONA,
                  RPH.AP_PATERNO,
                  RPH.AP_MATERNO,
                  RPH.FOLIO_MERCANTIL,
                  RPH.RFC,
                  RPH.CURP_DOC,
                  'V',
                  RDH.CALLE,
                  RDH.NUM_EXTERIOR,
                  RDH.NUM_INTERIOR,
                  RDH.ID_COLONIA,
                  RDH.ID_LOCALIDAD,
                  peIdPersona,
                  RPH.ID_NACIONALIDAD,
                  RTH.TELEFONO,
                  RTH.EXTENSION,
                  RPH.E_MAIL,
                  RDEH.UBICA_DOMICILIO_1,
                  RDEH.UBICA_DOMICILIO_2,
                  RDEH.POBLACION,
                  RDEH.ZONA_POSTAL,
                  RDEH.ID_PAIS_RESIDENCIA,
                  (SELECT NUM_INSCRITA FROM RUG_PERSONAS_MORALES WHERE ID_PERSONA = peIdPersona),
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL
           INTO   vlParte,
                  vlTipoPersona,
                  vlRazonSocial,
                  vlNombre,
                  vlAvlllidoP,
                  vlAvlllidoM,
                  vlFolioMercantil,
                  vlRFC,
                  vlCURP,
                  vlBDomicilio,
                  vlCalle,
                  vlNumExt,
                  vlNumInt,
                  vlIdColonia,
                  vlIdLocalidad,
                  vlIdPersona,
                  vlIdNacionalidad,
                  vlTelefono,
                  vlExtension,
                  vlEmail,
                  vlUbicaDomicilio1,
                  vlUbicaDomicilio2,
                  vlPoblacion,
                  vlZonaPostal,
                  vlPais_residencia,
                  vlInscrita,
                  vlFolio,
                  vlLibro,
                  vlUbicada,
                  vlEdad,
                  vlEstadoCivil,
                  vlProfesion
           FROM         RUG_PERSONAS_H RPH
                     LEFT JOIN
                        RUG_TELEFONOS_H RTH
                     ON     RPH.ID_TRAMITE = RTH.ID_TRAMITE
                        AND RPH.ID_PERSONA = RTH.ID_PERSONA
                        AND RPH.ID_PARTE = RTH.ID_PARTE
                  LEFT JOIN
                     RUG_DOMICILIOS_H RDH
                  ON     RPH.ID_TRAMITE = RDH.ID_TRAMITE
                     AND RPH.ID_PERSONA = RDH.ID_PERSONA
                     AND RPH.ID_PARTE = RDH.ID_PARTE
                 LEFT JOIN  RUG_DOMICILIOS_EXT_H RDEH
                    ON  RDEH.ID_TRAMITE = RPH.ID_TRAMITE
                    AND RDEH.ID_DOMICILIO = RPH.ID_PERSONA
                    AND RDEH.ID_PARTE = RPH.ID_PARTE
          WHERE       RPH.ID_TRAMITE = vlIdUltimoTramite
                  AND RPH.ID_PERSONA = cursPartes_Rec.ID_PERSONA
                  AND RPH.ID_PARTE = cursPartes_Rec.ID_PARTE;

         IF cursPartes_Rec.ID_PARTE <> 4
         THEN
            IF vlBanderaPrueba = cursPartes_Rec.ID_PERSONA THEN

                vlIdPersonaAlta := vlAltaOtorgante;

            INSERT INTO RUG_REL_TRAM_INC_PARTES
              VALUES   (vlIdTramiteRugIncom, vlIdPersonaAlta, vlParte, vlTipoPersona, 'AC', SYSDATE);

            ELSE

                 SP_ALTAPARTE (vlIdTramiteRugIncom,
                             vlParte,
                             vlTipoPersona,
                             vlRazonSocial,
                             vlNombre,
                             vlAvlllidoP,
                             vlAvlllidoM,
                             vlFolioMercantil,
                             vlRFC,
                             vlCURP,
                             vlBDomicilio,
                             vlCalle,
                             vlNumExt,
                             vlNumInt,
                             vlIdColonia,
                             vlIdLocalidad,
                             vlIdPersona,
                             vlIdNacionalidad,
                             vlTelefono,
                             vlExtension,
                             vlEmail,
                             vlUbicaDomicilio1,
                             vlUbicaDomicilio2,
                             vlPoblacion,
                             vlZonaPostal,
                             vlPais_residencia,
                             vlInscrita,
                             vlFolio,
                             vlLibro,
                             vlUbicada,
                             vlEdad,
                             vlEstadoCivil,
                             vlProfesion,
                             vlIdPersonaAlta,
                             vlResult,
                             vlTxResult);

            END IF;

         ELSE
            vlIdPersonaAlta := cursPartes_Rec.ID_PERSONA;

            INSERT INTO RUG_REL_TRAM_INC_PARTES
              VALUES   (vlIdTramiteRugIncom, vlIdPersonaAlta, vlParte, vlTipoPersona, 'AC', SYSDATE);
         END IF;

          IF cursPartes_Rec.ID_PARTE = 1
            THEN
                vlBanderaPrueba := cursPartes_Rec.ID_PERSONA;
                vlAltaOtorgante := vlIdPersonaAlta;
            END IF;

      END LOOP;
   END;


--   IF peIdTipoTramite = 8
--   THEN                                                         -- TRANSMISION
--      SELECT   ID_RELACION, RELACION_BIEN, ID_GARANTIA_PEND
--        INTO   vlIdRelacionAnterior, vlRelacionBienAnterior, vlIdGarantiaPend
--        FROM   RUG_GARANTIAS
--       WHERE   ID_GARANTIA = peIdGarantia;

--      INSERT INTO RUG_GARANTIAS_PENDIENTES (ID_GARANTIA_PEND, ID_PERSONA, ID_ULTIMO_TRAMITE, ID_GARANTIA_MODIFICAR, ID_RELACION)
--        VALUES   (vlIdGarantiaTemp, peIdPersona, vlIdTramiteRugIncom, peIdGarantia, vlIdRelacionAnterior);

--      INSERT INTO RUG_REL_TRAM_INC_GARAN
--      VALUES   (vlIdGarantiaTemp, vlIdTramiteRugIncom, 'AC', SYSDATE);                  

--      SELECT   RELACION_BIEN + 1
--        INTO   vlRelacion
--        FROM   (  SELECT   RELACION_BIEN
--                    FROM   RUG_REL_GAR_TIPO_BIEN
--                   WHERE   RELACION_BIEN IS NOT NULL
--                ORDER BY   1 DESC)
--       WHERE   ROWNUM = 1;

--      INSERT INTO RUG_REL_GAR_TIPO_BIEN
--         SELECT   vlIdGarantiaTemp, ID_TIPO_BIEN, vlRelacion
--           FROM   RUG_REL_GAR_TIPO_BIEN
--          WHERE   ID_GARANTIA_PEND = vlIdGarantiaPend
--                  AND RELACION_BIEN = vlRelacionBienAnterior;

--      INSERT INTO RUG_CONTRATO
--         SELECT   SEQ_CONTRATO.NEXTVAL, vlIdGarantiaTemp, CONTRATO_NUM, FECHA_INICIO, FECHA_FIN, OTROS_TERMINOS_CONTRATO, MONTO_LIMITE,
--                  OBSERVACIONES, TIPO_CONTRATO, vlIdTramiteRugIncom, SYSDATE, 'AC', ID_USUARIO, CLASIF_CONTRATO
--           FROM   RUG_CONTRATO
--          WHERE   ID_GARANTIA_PEND = vlIdGarantiaPend
--                  AND CLASIF_CONTRATO = 'OB';
--   END IF;

   --aca se cargan los bienes especiales
   BEGIN
        SP_ALTA_BIEN_INCOMPLETO(vlIdTramiteRugIncom,vlIdUltimoTramite,vlResultBien,vlTxResultBien);

       IF (vlResult != 0) THEN
            psResult := vlResultBien;
            RAISE Ex_Error; 
       END IF;

   END;

   peIdTramiteIncompleto := vlIdTramiteRugIncom;

   REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'peIdTramiteIncompleto', peIdTramiteIncompleto, 'OUT');

   psResult := 0;
   psTxResult := RUG.FN_MENSAJE_ERROR(psResult); 

   COMMIT;

EXCEPTION
   WHEN Ex_TipoTramite
   THEN
      psResult  := 13;
      psTxResult := RUG.FN_MENSAJE_ERROR(psResult); 

      ROLLBACK;
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'peIdTramiteIncompleto', peIdTramiteIncompleto, 'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE (psTxResult);
   WHEN Ex_Error1
   THEN       

      ROLLBACK;
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'peIdTramiteIncompleto', peIdTramiteIncompleto, 'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'psTxResult', psTxResult, 'OUT');
   WHEN Ex_Error
   THEN           
      psTxResult := RUG.FN_MENSAJE_ERROR(psResult); 
      ROLLBACK;
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'peIdTramiteIncompleto', peIdTramiteIncompleto, 'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE (psTxResult);        

   WHEN OTHERS
   THEN
      psResult := 999;
      psTxResult := SUBSTR (SQLCODE || ':' || SQLERRM, 1, 250);
      ROLLBACK;
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'peIdTramiteIncompleto', peIdTramiteIncompleto, 'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Parte_Tram_Inc_Rast', 'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE (psTxResult);
END;
/

