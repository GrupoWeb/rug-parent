create PROCEDURE         SP_REL_PARTE_RECTIFICA 
                            (
                                peIdPersona          IN  NUMBER,
                                peIdTramiteTemp      IN  NUMBER,
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )
IS
                        


vlPerJuridica       CHAR(2);
vlTipoTramite       NUMBER;
vlTramiteExiste     NUMBER;
vlCountPersona      NUMBER;
Ex_ErrParametro  EXCEPTION;

fk_exception  EXCEPTION;
PRAGMA EXCEPTION_INIT (fk_exception, -00001);


BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE_RECTIFICA', 'peIdPersona', peIdPersona, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE_RECTIFICA', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');


     BEGIN
             SELECT ID_TRAMITE_TEMP,  ID_TIPO_TRAMITE
             INTO vlTramiteExiste, vlTipoTramite
             FROM TRAMITES_RUG_INCOMP
             WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;
              EXCEPTION
               WHEN NO_DATA_FOUND THEN
                psResult := 16;                
             RAISE Ex_ErrParametro;
       END;

      BEGIN

          SELECT  ID_PERSONA
          INTO vlCountPersona
          FROM RUG_PERSONAS
          WHERE ID_PERSONA = peIdPersona
          AND SIT_PERSONA = 'AC';
          EXCEPTION
               WHEN NO_DATA_FOUND THEN
                psResult := 12;
             RAISE Ex_ErrParametro;

      END;


      SELECT PER_JURIDICA
      INTO vlPerJuridica
      FROM RUG_PERSONAS
      WHERE ID_PERSONA = peIdPersona;


    UPDATE RUG_REL_TRAM_INC_PARTES
    SET STATUS_REG = 'IN', FECHA_REG = SYSDATE
    WHERE ID_TRAMITE_TEMP = peIdTramiteTemp 
    AND ID_PARTE = 4;


       BEGIN

        INSERT INTO RUG_REL_TRAM_INC_PARTES
        VALUES(peIdTramiteTemp, peIdPersona, 4, vlPerJuridica, 'AC', SYSDATE);

    EXCEPTION

        WHEN fk_exception THEN        
        BEGIN
            psResult := 70;
            RAISE Ex_ErrParametro;
        END;

    END;



  COMMIT;

  psResult   :=0;        
  psTxResult :='Actualizacion finalizada satisfactoriamente';

  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE_RECTIFICA', 'psResult', psResult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE_RECTIFICA', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION   
   WHEN Ex_ErrParametro  THEN
      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);

      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE_RECTIFICA', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE_RECTIFICA', 'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE(psTxResult);    

   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE_RECTIFICA', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_PARTE_RECTIFICA', 'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE(psTxResult);
END SP_REL_PARTE_RECTIFICA;
/

