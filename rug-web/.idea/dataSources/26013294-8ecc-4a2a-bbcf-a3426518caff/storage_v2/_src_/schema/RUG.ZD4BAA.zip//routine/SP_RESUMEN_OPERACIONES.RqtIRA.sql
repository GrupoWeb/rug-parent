create PROCEDURE           SP_RESUMEN_OPERACIONES 
                            (
                                peIdPersona         IN  NUMBER, --ID PERSONA LOGIN 
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )
IS

vlCuentas NUMBER;                         
Ex_ErrParametro EXCEPTION;

BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RESUMEN_OPERACIONES', 'peIdPersona', peIdPersona, 'IN');

 SELECT COUNT(*) INTO vlCuentas
 FROM TRAMITES_RUG_INCOMP;

 DBMS_OUTPUT.PUT_LINE(vlCuentas);

  psResult   :=0;        
  psTxResult :='Actualizacion finalizada satisfactoriamente';
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RESUMEN_OPERACIONES', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RESUMEN_OPERACIONES', 'psTxResult', psTxResult, 'OUT');    

EXCEPTION 
  WHEN Ex_ErrParametro  THEN         
      psTxResult:= substr(psResult,1,250);
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RESUMEN_OPERACIONES', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RESUMEN_OPERACIONES', 'psTxResult', psTxResult, 'OUT');

   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RESUMEN_OPERACIONES', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RESUMEN_OPERACIONES', 'psTxResult', psTxResult, 'OUT');

END SP_RESUMEN_OPERACIONES;
/

