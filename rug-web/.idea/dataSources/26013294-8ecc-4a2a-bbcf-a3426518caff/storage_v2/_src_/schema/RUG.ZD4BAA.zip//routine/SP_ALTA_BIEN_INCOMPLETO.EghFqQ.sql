create PROCEDURE         SP_ALTA_BIEN_INCOMPLETO (
															peIdTramiteIncompleto  IN    NUMBER, --IDENTIFICADOR UNICO DEL REGISTRO
															peIdUltimoTramite	   IN 	NUMBER, --tramite a buscar
                                                           psResult               OUT    INTEGER,   
                                                           psTxResult             OUT    VARCHAR2)
IS

  vlIdGarantiaBienPend  NUMBER;
  RegGarantiasBienTemp            RUG_GARANTIAS_BIENES%ROWTYPE;

  CURSOR cursBienesComp(cpeIdUltimoTramite IN NUMBER) IS
	SELECT TIPO_BIEN_ESPECIAL, 
		   TIPO_IDENTIFICADOR, 
		   IDENTIFICADOR, 
		   DESCRIPCION_BIEN
	FROM RUG_GARANTIAS_BIENES_H P
	WHERE ID_TRAMITE = peIdUltimoTramite;

cursBienesComp_REC cursBienesComp%ROWTYPE;

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_BIEN_INCOMPLETO', 'peIdTramiteIncompleto', CAST(peIdTramiteIncompleto AS VARCHAR2), 'IN');

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_BIEN_INCOMPLETO', 'peIdUltimoTramite', CAST(peIdUltimoTramite AS VARCHAR2), 'IN');

	 --lo de bienes inicia
	  OPEN cursBienesComp(peIdUltimoTramite);
	   LOOP
		  FETCH cursBienesComp INTO RegGarantiasBienTemp.TIPO_BIEN_ESPECIAL,
									 RegGarantiasBienTemp.TIPO_IDENTIFICADOR,
									 RegGarantiasBienTemp.IDENTIFICADOR,
									 RegGarantiasBienTemp.DESCRIPCION_BIEN;                                                 
			EXIT WHEN cursBienesComp%NOTFOUND;

			vlIdGarantiaBienPend:=SEQ_GARAN_BIENES_PEND.NEXTVAL;			

			INSERT INTO RUG_GARANTIAS_BIENES_PEND(ID_GARAN_BIEN_PEND,ID_TRAMITE_TEMP,TIPO_BIEN_ESPECIAL,TIPO_IDENTIFICADOR,
						IDENTIFICADOR,DESCRIPCION_BIEN)
			VALUES(vlIdGarantiaBienPend,peIdTramiteIncompleto,RegGarantiasBienTemp.TIPO_BIEN_ESPECIAL,RegGarantiasBienTemp.TIPO_IDENTIFICADOR,
			RegGarantiasBienTemp.IDENTIFICADOR,RegGarantiasBienTemp.DESCRIPCION_BIEN);

		END LOOP;
	CLOSE cursBienesComp;
	 -- lo de bienes finaliza

    COMMIT;

    psResult := 0;
    psTxResult := RUG.FN_MENSAJE_ERROR(psResult);

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_BIEN_INCOMPLETO', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_BIEN_INCOMPLETO', 'psTxResult', psTxResult, 'OUT');    


  psResult:=0;   
  psTxResult:= 'ALTA EXITOSA';--pkg_infz_inst_fenx.FunObtMsgErr(psResult);
  EXCEPTION 
   WHEN OTHERS THEN
        psResult:=-1;   
        psTxResult:= 'ocurrio un error';
  dbms_output.put_line(psTxResult);
  psResult  := 999;   
  psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);  
  ROLLBACK;                
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_BIEN_INCOMPLETO', 'psResult', psResult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_BIEN_INCOMPLETO', 'psTxResult', psTxResult, 'OUT');    


END;
/

