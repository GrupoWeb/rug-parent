create PROCEDURE         SP_ALTA_USUARIO_DOMICILIO 
(
      peOperacion               IN VARCHAR2, -- I ALTA, U ACTIVACION
      peNombre                  IN VARCHAR2, 
      peApellidoP               IN VARCHAR2, 
      peApellidoM               IN VARCHAR2,
      peIdNacionalidad          IN NUMBER, 
      peSexo                    IN VARCHAR2,
      peRFC                     IN VARCHAR, 
      peCURP                    IN VARCHAR2,
      peCveUsuario              IN VARCHAR2,
      peCveUsuarioPadre         IN VARCHAR2,
      pePassword                IN RUG_SECU_USUARIOS.PASSWORD%TYPE,
      pePregRecupera            IN VARCHAR2,
      peRespRecupera            IN VARCHAR2,
      peCveInstitucion          IN VARCHAR2,
      peCvePerfil               IN VARCHAR2,
      peCveAplicacion           IN VARCHAR2,
      peIdGrupo                 IN VARCHAR2,
      peCalle                   IN VARCHAR2,
      peNumExterior             IN VARCHAR2,
      peNumInterior             IN VARCHAR2,
      peIdColonia               IN NUMBER,
      peIdLocalidad             IN NUMBER,
      peTelefono                IN VARCHAR2,
      peExtension               IN VARCHAR2,
      psResult                 OUT NUMBER,
      psTxResult               OUT VARCHAR2
)
IS

  --Variables
vlIdPersona         INTEGER;
vlContador          NUMBER;     
vlContador1         NUMBER;
vlPerfil            VARCHAR2(50);
vlCveAcreedor       VARCHAR2(256);
vlTipoTramite       NUMBER;
vlFirmado           CHAR(2);
vlIdContrato        NUMBER;
vlNumPartes         NUMBER;
vlDomicilio         NUMBER;
vlPersonaBorrar     NUMBER;

Ex_ErrParametro     EXCEPTION;

BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_USUARIO_DOMICILIO', 'peCveUsuario', peCveUsuario, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_USUARIO_DOMICILIO', 'peIdColonia', peIdColonia, 'IN');

    vlFirmado := NULL;



      IF (peIdGrupo IS NULL) THEN
            BEGIN

                psResult   := 1;
                psTxResult :='Debe indicar el grupo';
                RAISE Ex_ErrParametro;  

            END;
        END IF;


    vlContador := 0;

    Select count(*) 
    INTO vlContador
    from RUG_SECU_USUARIOS
    WHERE LOWER(CVE_USUARIO) = LOWER(peCveUsuario);


    IF(peOperacion = 'I') THEN
        BEGIN            

            IF (peIdGrupo IS NOT NULL) THEN
                BEGIN

                    SELECT COUNT(*)
                      INTO vlContador 
                      FROM RUG_GRUPOS
                     WHERE ID_GRUPO = peIdGrupo
                       AND SIT_GRUPO = 'AC';


                    Dbms_output.put_line('peIdGrupo ' || peIdGrupo); 

                    IF(vlContador = 0) THEN
                        BEGIN
                            psResult   := 1;
                            psTxResult :='No existe el grupo';
                            RAISE Ex_ErrParametro;  

                        END; 
                    END IF;
                END;
            END IF;

           vlCveAcreedor := NULL;

            IF(peIdGrupo = 1) THEN
                BEGIN
                    vlCveAcreedor := LOWER(peCveUsuario);
                END;

            ELSIF (peIdGrupo = 3) THEN
                BEGIN
                    vlCveAcreedor := LOWER(peCveUsuarioPadre);
                END;
            ELSE
                BEGIN

                    SELECT CVE_ACREEDOR
                      INTO vlCveAcreedor
                      FROM RUG_SECU_USUARIOS
                     WHERE LOWER(CVE_USUARIO) = LOWER(peCveUsuarioPadre);
                     EXCEPTION
                        WHEN OTHERS THEN
                            vlCveAcreedor := NULL;
                END;
            END IF;


            vlIdPersona:= SEQ_RUG_ID_PERSONA.NEXTVAL;
            vlDomicilio:= SEQ_RUG_ID_DOMICILIO.NEXTVAL;

            BEGIN
                SELECT ID_PERSONA
                INTO  vlPersonaBorrar
                FROM RUG.RUG_SECU_USUARIOS
                WHERE LOWER(CVE_USUARIO) = LOWER(peCveUsuario);

                DELETE FROM RUG_PERSONAS 
                WHERE ID_PERSONA = vlPersonaBorrar;

                DELETE FROM RUG_PERSONAS_FISICAS 
                WHERE ID_PERSONA = vlPersonaBorrar;

                DELETE FROM RUG_PERSONAS_MORALES 
                WHERE ID_PERSONA = vlPersonaBorrar;

                DELETE FROM RUG_TELEFONOS 
                WHERE ID_PERSONA = vlPersonaBorrar;

                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                 DBMS_OUTPUT.PUT_LINE('PERSONA NO EXISTE');           
            END;

            DELETE FROM RUG.RUG_SECU_USUARIOS
            WHERE LOWER(CVE_USUARIO) = LOWER(peCveUsuario);

            DELETE FROM RUG.RUG_SECU_PERFILES_USUARIO
            WHERE LOWER(CVE_USUARIO) = LOWER(peCveUsuario);


            INSERT INTO RUG_DOMICILIOS(ID_DOMICILIO,CALLE,NUM_EXTERIOR,NUM_INTERIOR,ID_COLONIA,CALLE_COLINDANTE_1,CALLE_COLINDANTE_2,CALLE_POSTERIOR,
                                        LOCALIDAD,ID_VIALIDAD,TX_REFER_ADICIONAL,ID_LOCALIDAD)
            VALUES (vlDomicilio,peCalle,peNumExterior,peNumInterior,peIdColonia,NULL,NULL,NULL,NULL,NULL,NULL,peIdLocalidad);


            INSERT INTO RUG_PERSONAS (ID_PERSONA, RFC, ID_NACIONALIDAD, PER_JURIDICA, FH_REGISTRO, PROCEDENCIA, SIT_PERSONA, ID_DOMICILIO,REG_TERMINADO)
            VALUES   (vlIdPersona, peRFC, peIdNacionalidad, 'PF', TRUNC(SYSDATE), 'NAL', 'AC', vlDomicilio,'Y');


            INSERT INTO RUG_PERSONAS_FISICAS (ID_PERSONA, NOMBRE_PERSONA, AP_PATERNO, AP_MATERNO,CURP, SEXO)
            VALUES   (vlIdPersona, UPPER(peNombre), UPPER(peApellidoP), UPPER(peApellidoM), peCURP,peSexo);


            INSERT INTO RUG_SECU_USUARIOS (CVE_INSTITUCION, CVE_USUARIO, ID_PERSONA, PASSWORD, F_ASIGNA_PSW, PREG_RECUPERA_PSW, RESP_RECUPERA_PSW, 
                                           FH_REGISTRO, SIT_USUARIO, CVE_USUARIO_PADRE, CVE_ACREEDOR, ID_GRUPO, B_FIRMADO)
            VALUES (peCveInstitucion, LOWER(peCveUsuario), vlIdPersona, LOWER (FNDPSWENCRYPT(pePassword)), SYSDATE, pePregRecupera , peRespRecupera, SYSDATE, 
                    'IN', LOWER(peCveUsuarioPadre), vlCveAcreedor, peIdGrupo, vlFirmado);


            INSERT INTO RUG_SECU_PERFILES_USUARIO (CVE_INSTITUCION, CVE_USUARIO, CVE_PERFIL, CVE_APLICACION, ID_PERSONA, B_BLOQUEADO)
            VALUES   (peCveInstitucion, LOWER(peCveUsuario), peCvePerfil,  peCveAplicacion, vlIdPersona, 'F');


            IF  peTelefono IS NOT NULL THEN

                INSERT INTO RUG_TELEFONOS
                VALUES(vlIdPersona, NULL, peTelefono, peExtension, SYSDATE, 'AC');

            END IF;

            COMMIT;

            psResult  := 0;
            psTxResult := 'Alta Exitosa';                       
        END;
    END IF;

    IF(peOperacion = 'U') THEN
       BEGIN

            IF(vlContador = 0) THEN
                BEGIN
                    psResult   := 1;
                    psTxResult :='El usuario no existe en el sistema';
                    RAISE Ex_ErrParametro;          
                END;
            ELSIF (vlContador > 1) THEN
                BEGIN
                    psResult   := 2;
                    psTxResult :='Existe mas de un usuario con esa clave en el sistema';
                    RAISE Ex_ErrParametro;
                END;
            END IF;      


           UPDATE RUG_SECU_USUARIOS
           SET SIT_USUARIO = 'AC'
           WHERE LOWER(CVE_USUARIO) = LOWER(peCveUsuario)
           AND SIT_USUARIO = 'IN';

           psResult  := 0;
           psTxResult := 'Activacion Exitosa'; 

       END;
    END IF;

    UPDATE RUG.RUG_SECU_USUARIOS
    SET ID_GRUPO = 4, SIT_USUARIO = 'AC'
    WHERE LOWER(CVE_USUARIO) = LOWER(peCveUsuario);

    UPDATE RUG.RUG_SECU_USUARIOS
    SET CVE_ACREEDOR = LOWER(peCveUsuario)
    WHERE LOWER(CVE_USUARIO) = LOWER(peCveUsuario);

    UPDATE RUG.RUG_SECU_PERFILES_USUARIO
    SET CVE_PERFIL = 'AUTORIDAD', CVE_APLICACION = 'RugPortal'
    WHERE LOWER(CVE_USUARIO) = LOWER(peCveUsuario);   

    COMMIT;     

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION
  WHEN Ex_ErrParametro THEN
      rollback;
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'psTxResult', psTxResult, 'OUT');    


   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= 'Error en el proceso ' || SQLERRM;
      rollback;
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REGISTRO_USUARIO_RUG', 'psTxResult', psTxResult, 'OUT');    


END SP_ALTA_USUARIO_DOMICILIO;
/

