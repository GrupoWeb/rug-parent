create PROCEDURE         SP_ALTA_GRUPO
(
    peIdPersonaPadre    IN    NUMBER,
    peIdUsuario         IN    NUMBER,
    peDescGrupo         IN    VARCHAR2,
    pePrivilegios       IN    VARCHAR2,
    psResult           OUT    INTEGER,
    psTxResult         OUT    VARCHAR2
 )
IS


vlGrupo         NUMBER;
vlRelGrupoPriv  NUMBER;
vlIdPrivilegio  NUMBER;
vlCount         NUMBER;
vlPerfil        VARCHAR2(50);
vlPerfilAux     VARCHAR2(50);
vlCveAcreedor   VARCHAR2(256);
vlIdPerAcreedor NUMBER;
vlPrivilegio    VARCHAR2(100);


Ex_ErrParametro EXCEPTION;

vlPrivilegios   INSTITUCIONAL.PKGSE_COMUN.T_PALABRAS;

BEGIN

Dbms_output.put_line(1000);

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GRUPO', 'peIdPersonaPadre', peIdPersonaPadre, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GRUPO', 'peIdUsuario', peIdUsuario, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GRUPO', 'peDescGrupo', peDescGrupo, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GRUPO', 'pePrivilegios', pePrivilegios, 'IN');

Dbms_output.put_line(0);


        SELECT COUNT(*)
          INTO vlCount
          FROM RUG_REL_GRUPO_ACREEDOR RRGA,
               RUG_SECU_USUARIOS RSU,
               RUG_PRIVILEGIOS RP,
               RUG_REL_GRUPO_PRIVILEGIO RRGP
         WHERE RRGA.ID_SUB_USUARIO = RSU.ID_PERSONA
           AND RRGP.ID_GRUPO = RRGA.ID_GRUPO
           AND RRGP.ID_PRIVILEGIO = RP.ID_PRIVILEGIO
           AND RP.ID_PRIVILEGIO = 16
           AND RRGA.ID_ACREEDOR = peIdPersonaPadre
           AND RRGA.ID_SUB_USUARIO = peIdUsuario
           AND RRGP.SIT_RELACION = 'AC';

Dbms_output.put_line('peIdPersonaPadre ' || peIdPersonaPadre || 'peIdUsuario ' || peIdUsuario || ' CONTADOR ' ||vlCount );

Dbms_output.put_line(1);

    IF(vlCount = 0) THEN
        BEGIN
            psResult:= -1;
            psTxResult := 'El usuario no cuenta con el perfil para crear grupos.';
            RAISE Ex_ErrParametro;
        END;
    END IF;

    vlCount := 0;

Dbms_output.put_line(6);

    SELECT COUNT(*)
      INTO vlCount
      FROM RUG_GRUPOS
     WHERE ID_ACREEDOR = peIdPersonaPadre
       AND UPPER(DESC_GRUPO) = UPPER(peDescGrupo)
       AND SIT_GRUPO = 'AC';

Dbms_output.put_line(7);

    IF(vlCount > 0) THEN
        BEGIN
            psResult:= -1;
            psTxResult := 'Ya existe un grupo con el mismo nombre';
            RAISE Ex_ErrParametro;
        END;
    END IF;
Dbms_output.put_line(8);
    vlGrupo := SEQ_GRUPOS.NEXTVAL;

    INSERT INTO RUG_GRUPOS(ID_GRUPO, ID_ACREEDOR, DESC_GRUPO , ID_PERSONA_CREA, FH_CREACION, SIT_GRUPO)
    VALUES(vlGrupo, peIdPersonaPadre, UPPER(peDescGrupo), peIdUsuario, SYSDATE, 'AC');

    dbms_output.put_line(9);
    vlPrivilegio := pePrivilegios || '|11|12|13|15|18|37';
    dbms_output.put_line('vlPrivilegio ' || vlPrivilegio);


    vlPrivilegio := replace(vlPrivilegio, '||','|');


    vlPrivilegios := INSTITUCIONAL.PKGSE_COMUN.SPLITCADENA(vlPrivilegio, '|');
    dbms_output.put_line(10);

    vlCount := 0;

     FOR i IN 1..vlPrivilegios.count loop


        vlRelGrupoPriv := SEQ_REL_GRUPO_PRIVILEGIO.NEXTVAL;
        vlIdPrivilegio := vlPrivilegios(i-1);


        SELECT COUNT(*)
          INTO vlCount
          FROM RUG_REL_GRUPO_PRIVILEGIO
         WHERE ID_GRUPO = vlGrupo
           AND ID_PRIVILEGIO = vlIdPrivilegio
           AND SIT_RELACION = 'AC';


        IF(vlCount > 0) THEN
            BEGIN
                psResult:= -1;
                psTxResult := 'Se repite un privilegio para el grupo, favor de validar';
                RAISE Ex_ErrParametro;
            END;
        END IF;

        vlCount := 0;


        SELECT COUNT(*)
          INTO vlCount
         FROM RUG_REL_GRUPO_PRIVILEGIO
        WHERE ID_GRUPO = vlGrupo
          AND ID_PRIVILEGIO = 23
          AND SIT_RELACION = 'AC';

        IF (vlCount = 0) THEN

            SELECT COUNT(*)
              INTO vlCount
              FROM RUG_PRIVILEGIOS
             WHERE UPPER(DESC_PRIVILEGIO) LIKE '%M?TIPLE%'
               AND ID_PRIVILEGIO = vlIdPrivilegio
             ORDER BY 1;

            IF (vlCount > 0) THEN

                INSERT INTO RUG_REL_GRUPO_PRIVILEGIO
                VALUES(SEQ_REL_GRUPO_PRIVILEGIO.NEXTVAL, vlGrupo,  23, 'AC');

            END IF;

        END IF;

        Dbms_output.put_line('PRIVILEGIOS' || vlRelGrupoPriv || ' - ' || vlIdPrivilegio);


        INSERT INTO RUG_REL_GRUPO_PRIVILEGIO
        VALUES(vlRelGrupoPriv, vlGrupo,  vlIdPrivilegio, 'AC');

     END LOOP;

     psResult := 0;
     psTxResult:= 'ALTA EXITOSA';

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GRUPO', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GRUPO', 'psTxResult', psTxResult, 'OUT');

    COMMIT;



EXCEPTION
  WHEN Ex_ErrParametro  THEN
      ROLLBACK;

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GRUPO', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GRUPO', 'psTxResult', psTxResult, 'OUT');

   WHEN OTHERS THEN
      psResult  := 999;
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GRUPO', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_GRUPO', 'psTxResult', psTxResult, 'OUT');



END;
/

