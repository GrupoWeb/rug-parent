create view V_PRIVILEGIOS as
SELECT   ID_PRIVILEGIO,
            DESC_PRIVILEGIO,
            HTML,
            SIT_PRIVILEGIO,
            ID_RECURSO,
            ORDEN
     FROM   RUG_PRIVILEGIOS
    WHERE   id_privilegio NOT IN
                  (2, 5, 10, 11, 12, 13, 15, 16, 17, 18, 19, 20, 21, 23, 25)
/

