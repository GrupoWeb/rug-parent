create PROCEDURE         SP_CONSULTA_FOLIO_ACREEDOR (
                            peIdTramiteTemp      IN  TRAMITES.ID_TRAMITE_TEMP%TYPE,--  IDENTIFICADOR DEL TRAMITE ASOCIADO A LA GARANTIA
                            psResult            OUT  INTEGER,
                            psTxResult          OUT  VARCHAR2 
)IS  
    V_FOLIO_ELECT_ACREEDOR       NUMBER;  
    V_FOLIO_ELECT_ACREEDOR_AD    NUMBER;

    V_TOTAL_ACREEDOR_AD          NUMBER;
    V_EXISTE_ACREEDOR            NUMBER;  
    V_EXISTE_ACREEDOR_AD         NUMBER;    

    V_ID_TRAMITE_TEMP            NUMBER;
    V_TIPO_GARANTIA_MOB          NUMBER;

    TRAMITE_INVAL_EXC            EXCEPTION;

BEGIN


    psResult:= 0;
     psTxResult :='OK';

    /*** VALIDACI? DE TR?ITE TEMPORAL  ***/
    SELECT COUNT(ID_TRAMITE_TEMP)
      INTO V_ID_TRAMITE_TEMP
      FROM RUG.RUG_BITAC_TRAMITES
     WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;

    IF  V_ID_TRAMITE_TEMP = 0 THEN
        psResult := 16;
        RAISE TRAMITE_INVAL_EXC;       
    END IF;


        /*** VALIDACION DE FOLIO ELECTRONICO ACREEDOR ***/
        SELECT COUNT(*)
          INTO V_EXISTE_ACREEDOR
          FROM RUG.RUG_PERSONAS P
         INNER JOIN RUG_REL_TRAM_inc_PARTES RT
            ON P.ID_PERSONA = RT.ID_PERSONA
           AND ID_PARTE = 4
         WHERE RT.ID_TRAMITE_TEMP = peIdTramiteTemp;

         IF V_EXISTE_ACREEDOR > 0 THEN

           SELECT COUNT(P.FOLIO_MERCANTIL)
             INTO V_FOLIO_ELECT_ACREEDOR
             FROM RUG.RUG_PERSONAS P
            INNER JOIN RUG_REL_TRAM_inc_PARTES RT
               ON P.ID_PERSONA = RT.ID_PERSONA
              AND ID_PARTE = 4
            WHERE RT.ID_TRAMITE_TEMP = peIdTramiteTemp;

             IF V_FOLIO_ELECT_ACREEDOR  = 0 THEN
               psResult   :=1;        
               psTxResult :='El Acreedor no tiene folio electr?o asignado';    
             END IF;

         END IF; 

--         /*** VALIDACION DE FOLIO ELECTRONICO ACREEDOR ADICIONAL ***/
--         SELECT COUNT(*)
--           INTO V_EXISTE_ACREEDOR_AD
--           FROM RUG.RUG_PERSONAS P
--          INNER JOIN RUG_REL_TRAM_inc_PARTES RT
--             ON P.ID_PERSONA = RT.ID_PERSONA
--            AND ID_PARTE = 3
--          WHERE RT.ID_TRAMITE_TEMP = peIdTramiteTemp;
--        
--        IF V_EXISTE_ACREEDOR_AD > 0 THEN 
--        
--            SELECT COUNT(P.FOLIO_MERCANTIL)
--              INTO V_FOLIO_ELECT_ACREEDOR_AD
--              FROM RUG.RUG_PERSONAS P
--             INNER JOIN RUG_REL_TRAM_inc_PARTES RT
--                ON P.ID_PERSONA = RT.ID_PERSONA
--               AND ID_PARTE = 3
--             WHERE RT.ID_TRAMITE_TEMP = peIdTramiteTemp;
--             
--            SELECT COUNT(*)
--              INTO V_TOTAL_ACREEDOR_AD
--              FROM RUG_PERSONAS
--             WHERE ID_PERSONA IN (SELECT ID_PERSONA FROM RUG_REL_TRAM_INC_PARTES
--                                   WHERE ID_PARTE = 3
--                                     AND ID_TRAMITE_TEMP = peIdTramiteTemp);
--                                                        
--                 
--            IF V_FOLIO_ELECT_ACREEDOR_AD != V_TOTAL_ACREEDOR_AD  THEN
--               psResult   := 2;        
--               psTxResult :='El Acreedor adicional no tienen folio electr?o asignado';    
--            END IF; 
--        
--        END IF;
--        
--        IF V_EXISTE_ACREEDOR > 0 AND V_EXISTE_ACREEDOR_AD > 0 THEN
--                      
--            IF (V_FOLIO_ELECT_ACREEDOR_AD != V_TOTAL_ACREEDOR_AD) AND V_FOLIO_ELECT_ACREEDOR  = 0 THEN
--               psResult   := 3;        
--               psTxResult :='El Acreedor representado y el Acreedor adicional no tienen folio electr?o asignado';    
--            END IF;
--        
--        END IF;


EXCEPTION

   WHEN TRAMITE_INVAL_EXC OR NO_DATA_FOUND THEN
        psResult := 127;
        psTxResult := RUG.FN_MENSAJE_ERROR(15);
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_FOLIO_ACREEDOR', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_FOLIO_ACREEDOR', 'psTxResult', psTxResult, 'OUT');


   WHEN OTHERS THEN
        psResult := 999;
        psTxResult := SUBSTR(SQLCODE||':'||SQLERRM,1,250);
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_FOLIO_ACREEDOR', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_FOLIO_ACREEDOR', 'psTxResult', psTxResult, 'OUT');


END;
/

