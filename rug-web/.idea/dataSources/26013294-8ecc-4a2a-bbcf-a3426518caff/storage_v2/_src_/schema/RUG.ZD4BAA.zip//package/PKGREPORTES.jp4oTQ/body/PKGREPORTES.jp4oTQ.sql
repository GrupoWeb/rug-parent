create PACKAGE BODY       "PKGREPORTES" AS
   /******************************************************************************
      NAME:       PKGREPORTES
      PURPOSE:    GUARDAR INFORMACIÓN RELATIVA DE LOS REPORTES
      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        14/Abr/2011             1. Created this package.
   ******************************************************************************/

/******************************************************************************
    NAME        spRegistro
    PROPOSITO   Guarda la evidencia de la ejecución de los procedimientos
******************************************************************************/
PROCEDURE  spRegistro (peCadena  in RUG_REP_CONSULTAS.TX_CONSULTA%TYPE) IS
    vlnumber   number(8);
    BEGIN
       select max(ID_CONSULTA) + 1  into vlNumber from RUG_REP_CONSULTAS;
       insert into rug_rep_consultas (ID_CONSULTA, TX_CONSULTA ) values (vlNumber, peCadena);
       commit;
       exception
       when others then rollback;
    END spRegistro;

/******************************************************************************
   NAME:       SPLITCadena
   PURPOSE:    Procedimiento que separa una cadena de acuerdo al caracter enviado
               y regresa un arreglo dinamico
******************************************************************************/
FUNCTION SPLITCadena(peCADENA   IN VARCHAR2,
                     peCaracter IN varchar2)
 RETURN t_Palabras
 IS
  vlCadena     VARCHAR2(4000);
  vlPosEspacio integer;
  vlIndice     integer;
  vlPalabras   t_Palabras;
 BEGIN

    vlIndice     := 0;
    vlCadena     := peCADENA;
    vlPalabras(0):= vlCadena;
    vlPosEspacio:=INSTR(vlCadena, peCaracter);
    WHILE vlPosEspacio!= 0 LOOP
          vlPalabras(vlIndice) := TRIM(SUBSTR(vlCadena, 1, vlPosEspacio - 1));
          vlCadena := SUBSTR(vlCadena,  vlPosEspacio + 1);
          vlIndice := vlIndice + 1;
          vlPosEspacio := INSTR(vlCadena, peCaracter);
          IF (vlPosEspacio= 0) AND (LENGTH(vlCadena)<> 0) THEN
              vlPosEspacio:=LENGTH(vlCadena)+1;
          END IF;
    END LOOP;

    RETURN  vlPalabras;
 END SPLITCadena;



--*******************************************************************************************************************************
--*Nombre:   funObtenTC    Función para obtener el TC de una moneda y día solicitado
--*Creado:   Alicia Maya    Fecha Elaboracion: 19/Abr/2011
--*******************************************************************************************************************************
Function funObtenTC (peMoneda in rug_rep_tipos_cambio.id_moneda%type,
                     peFecha  in varchar2) --rug_rep_tipos_cambio.f_cambio%type)
return rug_rep_tipos_cambio.TIPO_CAMBIO%type IS
   vlTCambio rug_rep_tipos_cambio.TIPO_CAMBIO%type;
   vlRegistro rug_rep_consultas.TX_CONSULTA%type;
BEGIN
    vlTCambio:=0;
    --Busca Tipo de Cambio del Dolar

    BEGIN
      SELECT TIPO_CAMBIO INTO vlTCambio
      FROM   RUG_REP_TIPOS_CAMBIO
      WHERE  ID_MONEDA = 8 
      AND    F_CAMBIO  = to_date(peFecha,'dd/mm/yyyy');

      EXCEPTION
      WHEN OTHERS THEN 
           spDBMS('funObtenTC- tipo de cambio no encontrado.');
           vlTCambio:=0;
    END;

    return vlTCambio;

    Exception
    When Others then 
         spDBMS('funObtenTC '||substr(sqlerrm,1,2000));
         return null;
END funObtenTC;

--*******************************************************************************************************************************
--*Nombre:   spProcesaTC    Procedimiento que inserta la informacion en RUG_TIPOS_CAMBIOS
--*Creado:   Alicia Maya    Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
PROCEDURE spProcesaTC( peTiposCambio    IN   VARCHAR2,
                       peFCambio        IN   VARCHAR2, --RUG_REP_TIPOS_CAMBIO.F_CAMBIO%TYPE,
                       peUsuario        IN   RUG_REP_TIPOS_CAMBIO.ULT_USU_REG%TYPE,
                       peBcommit        IN   VARCHAR2,
                       psResult         OUT  INTEGER,
                       psTxResult       OUT  VARCHAR2)  IS
    vlTipos     t_Palabras;
    vlCount     number;
    vlIndex     number;
    vlIdGrupo   number;
    vlResult    INTEGER;
    vlTxResult  VARCHAR2(1000);
    vlMoneda    RUG_REP_TIPOS_CAMBIO.ID_MONEDA%type;
    vlTCambio   RUG_REP_TIPOS_CAMBIO.TIPO_CAMBIO%type;
    Ex_Registro EXCEPTION;
BEGIN
   --Inicializa variables y parametros de salida
   vlTipos:=SPLITCadena(peTiposCambio,'|');
   vlCount:=vltipos.count;
   vlIndex:=0;
   vlResult:=999;
   vlTxResult:='Error inesperado';

   loop
       vlMoneda:=vlTipos(vlIndex);
       vlTCambio:=vlTipos(vlIndex+1);

       begin

          UPDATE RUG_REP_TIPOS_CAMBIO
          SET    TIPO_CAMBIO = vlTCambio,
                 ULT_USU_REG = nvl(peUsuario, ULT_USU_REG)
          WHERE  ID_MONEDA   = vlMoneda
          AND    F_CAMBIO    = to_date(peFCambio,'dd/mm/yyyy');

          IF SQL%NOTFOUND THEN
             begin
                INSERT INTO RUG_REP_TIPOS_CAMBIO(ID_MONEDA, F_CAMBIO, TIPO_CAMBIO, ULT_USU_REG)
                VALUES(vlMoneda, to_date(peFCambio,'dd/mm/yyyy'), vlTCambio, peUsuario);
                EXCEPTION
                    WHEN DUP_VAL_ON_INDEX THEN
                    vlResult := 50;
                    vlTxResult := 'Error. Se duplicó el registro. Verificar.';
                    RAISE Ex_Registro;       
             end;
          END IF;
       END;

       vlIndex:=vlIndex+2; 
       exit when vlIndex>=vlCount;
   end loop;

   IF peBCOMMIT = coVerdadero THEN COMMIT; END IF; 

   psResult:=0;
   psTxResult:='';

   exception
   when Ex_Registro then
      psResult  := vlResult;
      psTxResult:= vlTxResult;
      IF peBCOMMIT = coVerdadero THEN ROLLBACK; END IF;   
   WHEN OTHERS THEN
      psResult  := 51;
      psTxResult:= SUBSTR(SQLCODE||':'||SQLERRM,1,1000);
      IF peBCOMMIT = coVerdadero THEN ROLLBACK; END IF;   
END spProcesaTC;


--*******************************************************************************************************************************
--*Nombre:   spDBMS         Procedimiento que utiliza el dbms_output
--*Creado:   Alicia Maya    Fecha Elaboracion: 18/Abr/2011
--*******************************************************************************************************************************
PROCEDURE spDBMS(peMensaje    IN   clob)
IS
   vlIni      number;
BEGIN
   IF vgBanderaMensajes='V' THEN

      vlIni := 1;

      LOOP
         DBMS_OUTPUT.PUT_LINE(SUBSTR(peMensaje,vlIni,8000));
         vlIni:=vlIni+8000;
         EXIT WHEN vlIni >= length(peMensaje) ;
      END LOOP;
   END IF;
   EXCEPTION
   WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('ERR spDBMS->'||SQLERRM);
END spDBMS;


--*******************************************************************************************************************************
--*Nombre:   funObtenQuery  devolver el query base para los reportes
--*Creado:   Alicia Maya    Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION funObtenQuery( peIdConsulta    IN   RUG_REP_CONSULTAS.ID_CONSULTA%type)
RETURN   RUG_REP_CONSULTAS.TX_CONSULTA%type IS
   vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
BEGIN
   BEGIN
       SELECT TX_CONSULTA INTO vlConsulta
       FROM   RUG_REP_CONSULTAS
       WHERE  ID_CONSULTA=peIdConsulta;
       Exception
       WHEN NO_DATA_FOUND THEN return NULL;
   END;

   return vlConsulta;

   EXCEPTION
     WHEN OTHERS THEN
       return null;
END funObtenQuery;   



--*******************************************************************************************************************************
--*Nombre:   funObtenParam  devolver el valor del parametro
--*Creado:   Alicia Maya    Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION funObtenParam(peCveParametro    IN   RUG_REP_PARAM.CVE_PARAMETRO%type)
RETURN   RUG_REP_PARAM.TX_PARAMETRO%type IS
   vlParametro  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
   BEGIN
       SELECT TX_PARAMETRO INTO vlParametro
       FROM   RUG_REP_PARAM
       WHERE  CVE_PARAMETRO=peCveParametro;
       Exception
       WHEN NO_DATA_FOUND THEN return NULL;
   END;

   return vlParametro;

   EXCEPTION
     WHEN OTHERS THEN
       return null;
END funObtenParam;                          


--*******************************************************************************************************************************
--*Nombre:   FCapTipoCambios  Devuelve los tipos de cambio que se necesitan para los reporte a una fecha dada
--*Creado:   Alicia Maya      Fecha Elaboracion: 06/May/2011
--*******************************************************************************************************************************
FUNCTION FCapTipoCambios(peFecha IN VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor  SYS_REFCURSOR; 
    vlConsulta   RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlConsulta2  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios   RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin   RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax   RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');      

    --Busca Query Base
    vlConsulta := funObtenQuery(5);

    --Edita los parametros en el query base
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);
    vlConsulta2:= vlConsulta;
    vlConsulta2:= replace(vlConsulta2,'@FECHA',to_char(add_months(last_day(to_date(peFecha,'dd/mm/yyyy')),-1),'dd/mm/yyyy'));
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);

    --Arma el query para el reporte
    vlConsulta := 
--' select /*+RULE*/ dat.ID_MONEDA, MONEDA,  tipo_cambio, '''||to_char(peFecha,'dd/mm/yyyy')||''' Fecha  
' select /*+RULE*/ dat.ID_MONEDA, MONEDA,  tipo_cambio, '''||peFecha||''' Fecha
  from ('|| vlConsulta||
' ) dat, rug.rug_rep_tipos_cambio rt
 WHERE dat.id_moneda= rt.id_moneda(+)
 AND   rt.f_cambio(+)=to_date(''' ||peFecha||''',''dd/mm/yyyy'')
 GROUP BY dat.ID_MONEDA, MONEDA,  tipo_cambio 
 union all
 select /*+RULE*/ dat.ID_MONEDA, MONEDA,  tipo_cambio, '''||to_char(add_months(last_day(to_date(peFecha,'dd/mm/yyyy')),-1),'dd/mm/yyyy')||''' Fecha  
  from ('||  vlConsulta2||
' ) dat, rug.rug_rep_tipos_cambio rt
 WHERE dat.id_moneda= rt.id_moneda(+)
 AND   rt.f_cambio(+)=to_date(''' ||to_char(add_months(last_day(to_date(peFecha,'dd/mm/yyyy')),-1),'dd/mm/yyyy')||''',''dd/mm/yyyy'')
 GROUP BY dat.ID_MONEDA, MONEDA,  tipo_cambio 
 ORDER BY FECHA, ID_MONEDA ';

    spDBMS(vlConsulta);
    OPEN vlRefCursor FOR vlConsulta;

    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
          spDBMS('ERR <FCapTipoCambios> NO DATA FOUND'); 
          return NULL;
      WHEN OTHERS THEN  
          spDBMS('ERR <FCapTipoCambios> '||SUBSTR(SQLERRM,1,1500));
          return null;
END FCapTipoCambios;


--*******************************************************************************************************************************
--*Nombre:   FRevTipoCambios  Revisa que los tipos de cambio que se necesitan para los reporte a una fecha dada estén capturados
--*Creado:   Alicia Maya      Fecha Elaboracion: 06/May/2011
--*******************************************************************************************************************************
FUNCTION FRevTipoCambios(peFecha IN VARCHAR2) 
RETURN NUMBER IS
    vlRefCursor  SYS_REFCURSOR; 
    vlConsulta   RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlConsulta2  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios   RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlIdMoneda   RUG_REP_TIPOS_CAMBIO.ID_MONEDA%TYPE;
    vlResult     Number;
    vlMontoMin   RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax   RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');      

    --Busca Query Base
    vlConsulta := funObtenQuery(5);

    --Edita los parametros en el query base
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);
    vlConsulta2:= vlConsulta;
    vlConsulta2:= replace(vlConsulta2,'@FECHA',to_char(add_months(last_day(to_date(peFecha,'dd/mm/yyyy')),-1),'dd/mm/yyyy'));
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);

    --Arma el query para el reporte
-- AND   rt.f_cambio(+)=''' ||to_char(peFecha,'dd/mm/yyyy')||'''

    vlConsulta := 
' select /*+RULE*/ dat.ID_MONEDA  
  from ('|| vlConsulta||
' ) dat, rug.rug_rep_tipos_cambio rt
 WHERE dat.id_moneda= rt.id_moneda(+)
 AND   rt.f_cambio(+)=to_date(''' ||peFecha||''',''dd/mm/yyyy'')
 AND   rt.tipo_cambio is null
 GROUP BY dat.ID_MONEDA, MONEDA,  tipo_cambio 
 union all
 select /*+RULE*/ dat.ID_MONEDA
  from ('||  vlConsulta2||
' ) dat, rug.rug_rep_tipos_cambio rt
 WHERE dat.id_moneda= rt.id_moneda(+)
 AND   rt.f_cambio(+)=to_date(''' ||to_char(add_months(last_day(to_date(peFecha,'dd/mm/yyyy')),-1),'dd/mm/yyyy')||''',''dd/mm/yyyy'')
 AND   rt.tipo_cambio is null
 GROUP BY dat.ID_MONEDA, MONEDA,  tipo_cambio  ';

    spDBMS(vlConsulta);
    vlResult:=99;
    OPEN vlRefCursor FOR vlConsulta;
    FETCH vlRefCursor  INTO vlIdMoneda;
    if vlIdMoneda>0 then
       vlResult:=-99;
    else
       vlResult:=0;
    end if;


    return vlResult;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
          spDBMS('ERR <FRevTipoCambios> NO DATA FOUND'); 
          return 99;
      WHEN OTHERS THEN  
          spDBMS('ERR <FRevTipoCambios> '||SUBSTR(SQLERRM,1,1500));
          return 99;
END FRevTipoCambios;


--*******************************************************************************************************************************
--*Nombre:   FRepTipoBien  devuelve los datos del Reporte de garantías por tipo de bien
--*Creado:   Alicia Maya   Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepTipoBien(peFecha IN VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');      

    --Busca Query Base
    vlConsulta := funObtenQuery(1);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);

    --Arma el query para el reporte
    vlConsulta := 
' select /*+RULE*/  
         nvl(rctbi.DESC_TIPO_BIEN, ''Otros'') tipo_bien,
         sum(1/nvl(numero,1)) porcentaje,
         sum("MONTO GTIA PESOS"/nvl(numero,1)) Monto_Tipo_Bien
   from '||
       vlConsulta||
'   dat
    ,RUG.RUG_REL_GAR_TIPO_BIEN RE
    ,RUG.RUG_CAT_TIPO_BIEN RCTBI
    ,(SELECT /*+RULE*/  RELACION_BIEN, COUNT(*) AS NUMERO FROM RUG.RUG_REL_GAR_TIPO_BIEN GROUP BY RELACION_BIEN) NUMREL
 WHERE DAT.RELACION_BIEN= RE.RELACION_BIEN(+)
 AND   RCTBI.ID_TIPO_BIEN(+)= RE.ID_TIPO_BIEN
 AND   NUMREL.RELACION_BIEN(+) = RE.RELACION_BIEN
 GROUP BY rctbi.DESC_TIPO_BIEN ';

    spDBMS(vlConsulta);
    OPEN vlRefCursor FOR vlConsulta;

    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
          spDBMS('ERR <FRepTipoBien> NO DATA FOUND'); 
          return NULL;
      WHEN OTHERS THEN  
          spDBMS('ERR <FRepTipoBien> '||SUBSTR(SQLERRM,1,1500));
          return null;
END FRepTipoBien;


--*******************************************************************************************************************************
--*Nombre:   FRepRugEstado  devuelve los datos del Reporte de monto garantizado por Estado
--*Creado:   Alicia Maya    Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepRugEstado(peFecha  IN VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');      

    --Busca Query Base
    vlConsulta := funObtenQuery(1);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);

    --Arma el query para el reporte
    vlConsulta := 
' SELECT nvl(cve_estado, ''Extranjero'') cve_estado,
       count(*) num_garantias,
       sum("MONTO GTIA PESOS") total_garantizado
  FROM  '|| vlConsulta||
' group by nvl(cve_estado, ''Extranjero'') 
  order by nvl(cve_estado, ''Extranjero'')';

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepRugEstado> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepRugEstado> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepRugEstado;


--*******************************************************************************************************************************
--*Nombre:   FRepTotalXAcreedor  devuelve los montos garantizados por Acreedor
--*Creado:   Alicia Maya    Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepTotalXAcreedor(peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');   

    --Busca Query Base
    vlConsulta := funObtenQuery(1);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);
    vlConsulta := replace(vlConsulta,'@USUARIOS', vlUsuarios);

    --Arma el query para el reporte
    vlConsulta := 
' SELECT RFC_ACREEDOR "RFC ACREEDOR",
       NOMBRE_ACREEDOR "NOMBRE ACREEDOR",
       COUNT(*) "NUM GARANTIAS X ACREEDOR",
       SUM("MONTO GTIA PESOS") "MONTO TOTAL X ACREEDOR PESOS"
       ,nac.DESC_NACIONALIDAD
  FROM  '|| vlConsulta||
' ACRE, rug.RUG_PERSONAS per, rug.RUG_CAT_NACIONALIDADES nac
  where per.id_persona=acre.ID_ACREEDOR
  and   nac.id_nacionalidad=per.id_nacionalidad
  GROUP BY RFC_ACREEDOR, NOMBRE_ACREEDOR, nac.DESC_NACIONALIDAD
  ORDER BY NVL(RFC_ACREEDOR,''A''), NOMBRE_ACREEDOR';


    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepTotalXAcreedor> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepTotalXAcreedor> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepTotalXAcreedor;


--*******************************************************************************************************************************
--*Nombre:   FRepInsXUsuXMes  devuelve las inscripcones por usuarios x mes
--*Creado:   Alicia Maya      Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepInsXUsuXMes  (peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlWhere     Varchar2(200);
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');     

    --Busca Query Base
    vlConsulta := funObtenQuery(2);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHAINI',to_char(trunc(peFecha,'mm'),'dd/mm/yyyy'));
    --vlWhere    := ' AND   FECHA_STATUS BETWEEN '''||to_char(trunc(peFecha,'mm'),'dd/mm/yyyy')||''' AND '''||to_char(peFecha,'dd/mm/yyyy')||'''';
    vlWhere    := ' AND   FECHA_STATUS BETWEEN to_date('''||TO_CHAR(trunc(TO_DATE(peFecha,'DD/MM/YYYY'),'mm'),'DD/MM/YYYY')||''',''dd/mm/yyyy'') '
              ||' AND to_date('''||peFecha||''',''dd/mm/yyyy'')';              
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);
    vlConsulta := replace(vlConsulta,'@FECHASWHERE',vlWhere);
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);

    vlConsulta:=
' SELECT TO_CHAR(fecha,''mm-yyyy'') fecha, id_persona, cve_perfil, nombre, 
         SUM (INSCRIPCIONES)       INSCRIPCIONES,
         SUM (CERTIFICACIONES)    CERTIFICACIONES,
         SUM (MODIFICACIONES)     MODIFICACIONES,
         SUM (TRANSMISIONES)      TRANSMISIONES,
         SUM (RECTIFICACION)      RECTIFICACION,
         SUM (RENOVACIONES)       RENOVACIONES,
         SUM (CANCELACIONES)      CANCELACIONES, 
         SUM (ANOTACIONES)        ANOTACIONES,
         SUM (AVISOS_PREVENTIVOS) AVISOS_PREVENTIVOS,
         SUM (TOTAL)-SUM(ALTA_ACREEDORES) TOTAL 
  FROM ('
||vlConsulta||
' ) group by TO_CHAR(fecha,''mm-yyyy''), id_persona, cve_perfil, Nombre
    HAVING SUM (TOTAL)-SUM(ALTA_ACREEDORES)>0
    ORDER BY TO_CHAR(to_date(FECHA,''mm-yyyy''),''YYYY''), TO_CHAR(to_date(FECHA,''mm-yyyy''),''MM'') ';     

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepInsXUsuXMes> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepInsXUsuXMes> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepInsXUsuXMes;


--*******************************************************************************************************************************
--*Nombre:   FRepCifrasTotal  Devuelve los datos del Reporte de cifras totales de los montos garantizados por moneda
--*Creado:   Alicia Maya      Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepCifrasTotal  (peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');     

    --Busca Query Base
    vlConsulta := funObtenQuery(1);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);

   --Arma el query para el reporte
    vlConsulta := 
' SELECT ID_MONEDA ID, 
         MONEDA DIVISA,
         COUNT(*) "NUM GARANTIAS",
         SUM(NVL ("MONTO MAX GARANTIZADO", 0)) "MONTO MAX GARANTIZADO", 
         TC, 
         SUM( NVL ("MONTO MAX GARANTIZADO", 0) * TC ) "MONTO GTIA PESOS" 
  FROM '|| vlConsulta||
' GROUP BY ID_MONEDA, MONEDA, TC
  ORDER BY ID_MONEDA '; 


    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepCifrasTotal> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepCifrasTotal> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepCifrasTotal;


--*******************************************************************************************************************************
--*Nombre:   FRepDesgGarant   Devuelve el Desglose de las garantias
--*Creado:   Alicia Maya      Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepDesgGarant  (peFecha  IN    VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlTCambio   RUG_REP_TIPOS_CAMBIO.TIPO_CAMBIO%TYPE;

    vlRevisa    RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;

    ERR_TCAMBIO EXCEPTION;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');
    vlTCambio  := funObtenTC(8,peFecha);

    vlRevisa:=vlRevisa||'=> '||vlTCambio||'*/';
    if vlTCambio IS NULL or vlTCambio=0 then 
       spRegistro('FRepDesgGarant. obtuvo el tipo de cambio NULO O CERO');--raise ERR_TCAMBIO; 
       vlTCambio:=2;
    end if;

    --Busca Query Base
    vlConsulta := funObtenQuery(1);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);


   --Arma el query para el reporte
    vlConsulta := 
' SELECT  /*+RULE*/  rfc_acreedor "RFC ACREEDOR", NOMBRE_ACREEDOR "NOMBRE ACREEDOR", 
       "MONTO MAX GARANTIZADO" AS "MONTO GARANTIZADO ORI",  TC,  "MONTO GTIA PESOS", '|| 
       vlTCambio||' as TC_Dolar,  "MONTO GTIA PESOS" / '|| vlTCambio||' as "MONTO DOLARES",
       GARANTIA, id_tipo_garantia,  "DESC GTIA", 
       id_tipo_bien,  desc_tipo_bien AS "DESC_1ER_BIEN_CAPT",  ID_MONEDA,  MONEDA,  "FECHA CREACION",
       "DD",  "MM",  "YYYY", USUARIO, PERFIL, garantia_status,
       nombre_otorgante "NOMBRE OTORGANTE" , per_juridica , folio_mercantil "FOLIO MERCANTIL",
       id_nacionalidad, DESC_NACIONALIDAD "NACIONALIDA OTORGANTE"    
  FROM'|| vlConsulta||
' order by nvl(rfc_acreedor,''A''), NOMBRE_ACREEDOR, "MONTO GTIA PESOS"  '; 

    vlRevisa:=vlRevisa||vlConsulta;

    spRegistro(vlRevisa);

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN ERR_TCAMBIO THEN
           spDBMS('ERR <FRepDesgGarant> NO EXISTE EL TIPO DE CAMBIO DEL DOLAR');
           return NULL;
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepDesgGarant> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepDesgGarant> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepDesgGarant;



--*******************************************************************************************************************************
--*Nombre:   FRepGtiasAum     Devuelve los datos de las garantias que aumentaron en el mes solicitado
--*Creado:   Alicia Maya      Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepGtiasAum  (peFecha  IN    VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlConsult2  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');     

    --Busca Query Base
    vlConsulta := funObtenQuery(1);
    vlConsult2 := funObtenQuery(1);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);

    --Edita los parametros en el query base
    vlConsult2 := replace(vlConsult2,'@FECHA',to_char(last_day(ADD_MONTHS(to_date(peFecha,'dd/mm/yyyy'),-1)),'dd/mm/yyyy'));
    vlConsult2 := replace(vlConsult2,'@USUARIOS',vlUsuarios);
    vlConsult2 := replace(vlConsult2,'@MONTO_MIN',vlMontoMin);
    vlConsult2 := replace(vlConsult2,'@MONTO_MAX',vlMontoMax);

   --Arma el query para el reporte
    vlConsulta := 
' SELECT  /*+RULE*/  
       GARANTIA, "DESC GTIA", MONEDA, "MONTO MAX GARANTIZADO",
       TC, "MONTO GTIA PESOS", "FECHA CREACION", "STATUS", USUARIO,
       PERFIL,  NOMBRE_ACREEDOR "NOMBRE ACREEDOR", RFC_ACREEDOR "RFC ACREEDOR",
       GARANTIA_STATUS,ID_MONEDA 
  FROM '|| vlConsulta||
' MINUS '||
' SELECT  /*+RULE*/  
       GARANTIA, "DESC GTIA", MONEDA, "MONTO MAX GARANTIZADO",
       TC, "MONTO GTIA PESOS", "FECHA CREACION", "STATUS", USUARIO,
       PERFIL,  NOMBRE_ACREEDOR "NOMBRE ACREEDOR", RFC_ACREEDOR "RFC ACREEDOR",
       GARANTIA_STATUS,ID_MONEDA 
  FROM'|| vlConsult2;


    spDBMS(vlConsulta);
    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepGtiasAum> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepGtiasAum> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepGtiasAum;


--*******************************************************************************************************************************
--*Nombre:   FRepGtiasDis      Devuelve los datos de las garantias que se reportaron el mes anterior y no en el mes solicitado
--*Creado:   Alicia Maya      Fecha Elaboracion: 15/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepGtiasDis  (peFecha  IN    VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlConsult2  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');     

    --Busca Query Base
    vlConsulta := funObtenQuery(1);
    vlConsult2 := funObtenQuery(1);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);

    --Edita los parametros en el query base
    vlConsult2 := replace(vlConsult2,'@FECHA',to_char(last_day(ADD_MONTHS(to_date(peFecha,'dd/mm/yyyy'),-1)),'dd/mm/yyyy'));
    vlConsult2 := replace(vlConsult2,'@USUARIOS',vlUsuarios);
    vlConsult2 := replace(vlConsult2,'@MONTO_MIN',vlMontoMin);
    vlConsult2 := replace(vlConsult2,'@MONTO_MAX',vlMontoMax);

   --Arma el query para el reporte
    vlConsulta := 
' SELECT  /*+RULE*/  
       GARANTIA, "DESC GTIA", MONEDA, "MONTO MAX GARANTIZADO",
       TC, "MONTO GTIA PESOS", "FECHA CREACION", "STATUS", USUARIO,
       PERFIL,  NOMBRE_ACREEDOR "NOMBRE ACREEDOR", RFC_ACREEDOR "RFC ACREEDOR",
       GARANTIA_STATUS,ID_MONEDA 
  FROM '|| vlConsult2||
' MINUS '||
' SELECT  /*+RULE*/  
       GARANTIA, "DESC GTIA", MONEDA, "MONTO MAX GARANTIZADO",
       TC, "MONTO GTIA PESOS", "FECHA CREACION", "STATUS", USUARIO,
       PERFIL,  NOMBRE_ACREEDOR "NOMBRE ACREEDOR", RFC_ACREEDOR "RFC ACREEDOR",
       GARANTIA_STATUS,ID_MONEDA 
  FROM '|| vlConsulta;


    spDBMS(vlConsulta);
    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepGtiasDis> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepGtiasDis> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepGtiasDis;



--*******************************************************************************************************************************
--*Nombre:   FRepAnalisisDif  Devuelve el analisis de las diferencias de un mes respecto del anterior
--*Creado:   Alicia Maya      Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepAnalisisDif  (peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlConsult2  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlConPrinc  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlCon1      RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlCon2      RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlCon3      RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlCon4      RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlDate      VARCHAR2(10);

BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');
    vlDate     := TO_CHAR(last_day(ADD_MONTHS(to_date(peFecha,'dd/mm/yyyy'),-1)),'DD/MM/YYYY');

    --Busca Query Base
    vlConsulta := funObtenQuery(1);

    --Edita los parametros en el query base
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);

    vlConsult2 := vlConsulta;

    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    --vlConsult2 := replace(vlConsult2,'@FECHA',to_char(vlDate, 'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);
    vlConsult2 := replace(vlConsult2,'@FECHA',vlDate);

    --DBMS_OUTPUT.PUT_LINE(vlConsult2);--'1==========================================');
    --Arma el query para el reporte
    vlCon1 := 
-- CALCULA EL MONTO DEL MES ANTERIOR
' SELECT  /*+RULE*/  
        ''GTIAS EN ''||to_char(TO_DATE('''||vlDate||''',''dd/mm/yyyy''),''MONTH/YY'')AS MES_DATO,  
        NVL(SUM("MONTO GTIA PESOS"),0) CIFRA
  FROM'|| vlConsult2||
' UNION ALL ';

-- CALCULA EL MONTO DE LAS GARANTIAS AUMENTADAS
    vlCon2 := 
'SELECT ''GTIAS INCRM ''||to_char(TO_DATE('''||peFecha||''',''DD/MM/YYYY''),''MONTH/YY'') AS MES_DATO,
        NVL(SUM("MONTO GTIA PESOS"),0)  cifra
 FROM (
     SELECT  /*+RULE*/  
           GARANTIA, "DESC GTIA", MONEDA, "MONTO MAX GARANTIZADO",
           TC, "MONTO GTIA PESOS", "FECHA CREACION", "STATUS", USUARIO,
           PERFIL,  NOMBRE_ACREEDOR "NOMBRE ACREEDOR", RFC_ACREEDOR "RFC ACREEDOR",
           GARANTIA_STATUS,ID_MONEDA 
      FROM '|| vlConsulta||
    ' MINUS '||
    ' SELECT  /*+RULE*/  
           GARANTIA, "DESC GTIA", MONEDA, "MONTO MAX GARANTIZADO",
           TC, "MONTO GTIA PESOS", "FECHA CREACION", "STATUS", USUARIO,
           PERFIL,  NOMBRE_ACREEDOR "NOMBRE ACREEDOR", RFC_ACREEDOR "RFC ACREEDOR",
           GARANTIA_STATUS,ID_MONEDA 
      FROM'|| vlConsult2||')'||
' UNION ALL ';

-- CALCULA EL MONTO DE LAS GARANTIAS DISMINUIDAS
    vlCon3 := 
'SELECT ''MOVTOS MES ANT-ACT'' AS MES_DATO,
        NVL(SUM("MONTO GTIA PESOS"),0) CIFRAS 
 FROM (
      SELECT  /*+RULE*/
           GARANTIA, "DESC GTIA", MONEDA, "MONTO MAX GARANTIZADO",
           TC, "MONTO GTIA PESOS", "FECHA CREACION", "STATUS", USUARIO,
           PERFIL,  NOMBRE_ACREEDOR "NOMBRE ACREEDOR", RFC_ACREEDOR "RFC ACREEDOR",
           GARANTIA_STATUS,ID_MONEDA 
      FROM'|| vlConsult2||
    ' MINUS '||
    ' SELECT  /*+RULE*/ 
           GARANTIA, "DESC GTIA", MONEDA, "MONTO MAX GARANTIZADO",
           TC, "MONTO GTIA PESOS", "FECHA CREACION", "STATUS", USUARIO,
           PERFIL,  NOMBRE_ACREEDOR "NOMBRE ACREEDOR", RFC_ACREEDOR "RFC ACREEDOR",
           GARANTIA_STATUS,ID_MONEDA 
      FROM'|| vlConsulta||')'||
' UNION ALL ';

--CALCULA MES ACTUAL
    vlCon4 := 
' SELECT  /*+RULE*/
        ''GTIAS EN ''|| '''||TO_CHAR(TO_DATE(peFecha,'DD/MM/YYYY'),'MONTH/YY')||''' AS MES_DATO, 
        NVL(SUM("MONTO GTIA PESOS"),0)  CIFRA
  FROM'|| vlConsulta;


    spDBMS(vlCon1);
    spDBMS(vlCon2);
    spDBMS(vlCon3);
    spDBMS(vlCon4);

    vlConPrinc:=vlCon1||vlCon2||vlCon3||vlCon4;

    OPEN vlRefCursor FOR vlConPrinc;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepAnalisisDif> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepAnalisisDif> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepAnalisisDif;



--*******************************************************************************************************************************
--*Nombre:   FRepCifRelevantes  Devuelve las cifras relevantes de las garantias
--*Creado:   Alicia Maya        Fecha Elaboracion: 15/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepCifRelevantes  (peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlCostoIns  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlTCambio   RUG_REP_TIPOS_CAMBIO.TIPO_CAMBIO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    ERR_TCAMBIO EXCEPTION;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');
    vlCostoIns := funObtenParam('COSTOINSCR');

    vlTCambio := funObtenTC(8,peFecha);
    if vlTCambio IS NULL or vlTCambio=0 then raise ERR_TCAMBIO; end if;

    --Busca Query Base
    vlConsulta := funObtenQuery(1);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);
    vlConsulta := replace(vlConsulta,'--NVL (RGH.MONTO_MAXIMO_GARANTIZADO','NVL (RGH.MONTO_MAXIMO_GARANTIZADO');

   --Arma el query para el reporte
    vlConsulta := 
' select /*+RULE*/   
       TRUNC(sum("MONTO GTIA PESOS"),6) Monto_total_pesos,
       TRUNC(max("MONTO GTIA PESOS"),6) Monto_Maximo_pesos,
       TRUNC(min("MONTO GTIA PESOS"),6) Monto_Minimo_pesos,
       TRUNC(sum("MONTO GTIA PESOS") / COUNT(*),6) Promedio_pesos,
       TRUNC(sum("MONTO GTIA PESOS") *'||vlCostoIns||',6) Ahorro_pesos,
       TRUNC(sum("MONTO GTIA PESOS")/'||vlTCambio||',6) Monto_total_dolares,
       TRUNC(max("MONTO GTIA PESOS")/'||vlTCambio||',6) Monto_Maximo_dolares,
       TRUNC(min("MONTO GTIA PESOS")/'||vlTCambio||',6) Monto_Minimo_dolares,
       TRUNC((sum("MONTO GTIA PESOS") / COUNT(*))/'||vlTCambio||',6) Promedio_dolares,
       TRUNC((sum("MONTO GTIA PESOS") * 0.02)/'||vlTCambio||',6) Ahorro_dolares
  FROM'|| vlConsulta;


    spDBMS(vlConsulta);
    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN ERR_TCAMBIO THEN 
           spDBMS('ERR <FRepCifRelevantes> NO HAY TIPOS DE CAMBIO');
           RETURN NULL;
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepCifRelevantes> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepCifRelevantes> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepCifRelevantes;


--*******************************************************************************************************************************
--*Nombre:   FRepOtorgantes   Devuelve los datos del Reporte de OTORGANTES
--*Creado:   Alicia Maya      Fecha Elaboracion: 18/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepOtorgantes  (peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
    --Busca los parametros para el reporte
    vlUsuarios := funObtenParam('USUARIOS');

    --Busca Query Base
    vlConsulta := funObtenQuery(3);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);

    spDBMS(vlConsulta);
    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepOtorgantes> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepOtorgantes> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepOtorgantes; 

--*******************************************************************************************************************************
--*Nombre:   FRepTotOtorgantes   Devuelve los datos Totales del Reporte de OTORGANTES
--*Creado:   Alicia Maya      Fecha Elaboracion: 18/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepTotOtorgantes  (peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
    --Busca los parametros para el reporte
    vlUsuarios := funObtenParam('USUARIOS');

    --Busca Query Base
    vlConsulta := funObtenQuery(3);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);

    --Prepara el query principal
    vlConsulta:=
    ' SELECT per_juridica, COUNT(*) cantidad FROM ('||vlConsulta||') group by per_juridica
      UNION ALL 
      SELECT ''TOTAL'', COUNT(*) cantidad FROM ('||vlConsulta||') ';

    spDBMS(vlConsulta);
    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepTotOtorgantes> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepTotOtorgantes> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepTotOtorgantes; 


--*******************************************************************************************************************************
--*Nombre:   FRepGtiasExc     Devuelve los datos de las garantías excluidas en el mes solicitado
--*Creado:   Alicia Maya      Fecha Elaboracion: 18/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepGtiasExc  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlFechaAnt  VARCHAR2(10);--DATE;;

BEGIN
    --Busca Query Base
    vlConsulta := funObtenQuery(4);

    --Edita los parametros en el query base
    --vlFechaAnt := last_day(add_months(peFecha,-1));

    --vlConsulta := replace(vlConsulta,'@FMAC', to_char(peFecha,'mm'));

    --vlConsulta := replace(vlConsulta,'@FINI', to_char(trunc(peFecha,'mm'),'dd/mm/yyyy') );
    --vlConsulta := replace(vlConsulta,'@FFIN', to_char(peFecha,'dd/mm/yyyy'));
    --vlConsulta := replace(vlConsulta,'@FMAN', to_char(vlFechaAnt,'dd/mm/yyyy'));

    /*MES ANTERIOR */  vlFechaAnt := to_char(last_day(add_months(to_date(peFecha,'dd/mm/yyyy'),-1)),'dd/mm/yyyy'); 

    /*Mes Actual  */   vlConsulta := replace(vlConsulta,'@FMAC', to_char(to_date(peFecha,'dd/mm/yyyy'),'mm'));

    /*inicio del mes*/ vlConsulta := replace(vlConsulta,'@FINI', to_char(trunc(to_date(peFecha,'dd/mm/yyyy'),'mm'),'dd/mm/yyyy') );
    /*Fecha de corte*/ vlConsulta := replace(vlConsulta,'@FFIN', peFecha);
    /*mes anterior*/   vlConsulta := replace(vlConsulta,'@FMAN', vlFechaAnt);

    --Ejecuta la consulta  
    spDBMS(vlConsulta);
    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepGtiasExc> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepGtiasExc> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepGtiasExc; 



--*******************************************************************************************************************************
--*Nombre:   FRepSegAcreedores      Devuelve los datos de los acreedores, incluye RFC y Personalidad juridica 
--*Creado:   Alicia Maya            Fecha Elaboracion: 19/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepSegAcreedores  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');   
    vlUsuarios := funObtenParam('USUARIOS');

    --Busca Query Base
    vlConsulta := funObtenQuery(5);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',    peFecha);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);
    vlConsulta := replace(vlConsulta,'@USUARIOS', vlUsuarios);

    --Prepara el query principal
    vlConsulta:=
    ' SELECT ID_ACREEDOR, NOMBRE_ACREEDOR , PER_JUR_ACR, TIPO_PERFIL,
             DECODE(TIPO_PERFIL, 1, ''FEDATARIO'', 2, ''ACREEDOR'', 3 ,''CIUDADANO'') DESC_TIPO_PERFIL, RFC_ACREEDOR 
      FROM '||vlConsulta||
    ' GROUP BY ID_ACREEDOR, NOMBRE_ACREEDOR, PER_JUR_ACR, TIPO_PERFIL, RFC_ACREEDOR
      ORDER BY NOMBRE_ACREEDOR ';

    spDBMS(vlConsulta);
    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepSegAcreedores> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepSegAcreedores> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepSegAcreedores; 


--*******************************************************************************************************************************
--*Nombre:   FRepGtiasMontoTope Devuelve los datos de las garantías que exceden 1 mdd
--*Creado:   Alicia Maya        Fecha Elaboracion: 19/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepGtiasMontoTope  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlTope      RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMoneda    RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlTCambio   RUG_REP_TIPOS_CAMBIO.TIPO_CAMBIO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    ERR_TCAMBIO EXCEPTION;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');   
    vlUsuarios := funObtenParam('USUARIOS');
    vlTope     := funObtenParam('MONTOTOPE');
    vlMoneda   := funObtenParam('MONEDTOPE');

    --Busca TC para el reporte
    vlTCambio := funObtenTC(vlMoneda, peFecha);
    if vlTCambio IS NULL or vlTCambio=0 then raise ERR_TCAMBIO; end if;

    --Busca Query Base
    vlConsulta := funObtenQuery(1);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);
    vlConsulta := replace(vlConsulta,'@USUARIOS', vlUsuarios);

    --Prepara el query principal
    vlConsulta:=
' SELECT /*+RULE*/  rfc_acreedor "RFC ACREEDOR", NOMBRE_ACREEDOR "NOMBRE ACREEDOR", "MONTO GTIA PESOS",
         "MONTO MAX GARANTIZADO", trunc("MONTO GTIA PESOS"/'||to_char(vlTCambio)||',6) as MontoDolares,  TC,   GARANTIA,  id_tipo_garantia,   
         "DESC GTIA", id_tipo_bien,  desc_tipo_bien,  ID_MONEDA,  MONEDA,  "FECHA CREACION",
         "DD",  "MM",  "YYYY", "STATUS", USUARIO, PERFIL, garantia_status,
         nombre_otorgante "NOMBRE OTORGANTE" , per_juridica , folio_mercantil "FOLIO MERCANTIL",
         id_nacionalidad, DESC_NACIONALIDAD "NACIONALIDA OTORGANTE"   
  FROM '||vlConsulta||
' WHERE  "MONTO GTIA PESOS" / '||to_char(vlTCambio)||' >= '||to_char(vlTope)|| 
' ORDER BY NOMBRE_ACREEDOR ';

    spDBMS(vlConsulta);
    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN ERR_TCAMBIO THEN 
           spDBMS('ERR <FRepGtiasMontoTope> NO HAY TIPOS DE CAMBIO');
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepGtiasMontoTope> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepGtiasMontoTope> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepGtiasMontoTope; 


--*******************************************************************************************************************************
--*Nombre:   FRepGrafXDia     devuelve la información para las graficas por día
--*Creado:   Alicia Maya      Fecha Elaboracion: 25/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepGrafXDia  (peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlWhere     Varchar2(200);
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');     

    --Busca Query Base
    vlConsulta := funObtenQuery(2);

    --Edita los parametros en el query base
    --vlWhere    := ' AND   FECHA_STATUS BETWEEN '''||to_char(trunc(peFecha,'mm'),'dd/mm/yyyy')||''' AND '''||to_char(peFecha,'dd/mm/yyyy')||'''';
                                       --' AND to_date('''||to_char(to_date(peFecha,'dd/mm/yyyy'),'dd/mm/yyyy')||''',''dd/mm/yyyy'')  ';
    vlWhere    := ' AND   FECHA_STATUS BETWEEN to_date('''||to_char(trunc(to_date(peFecha,'dd/mm/yyyy'),'mm'),'dd/mm/yyyy')||''',''dd/mm/yyyy'') '||
                                         ' AND to_date('''||peFecha||''',''dd/mm/yyyy'')  ';
    --vlConsulta := replace(vlConsulta,'@FECHAINI',to_char(trunc(peFecha,'mm'),'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHASWHERE',vlWhere);
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);


    vlConsulta:=
' SELECT fecha,  
         SUM(NVL(TOTAL,0)) TOTAL,
         SUM(NVL(INSCRIPCIONES,0)) INSCRIPCIONES,
         SUM(NVL(AVISOS_PREVENTIVOS,0)) AVISOS_PREVENTIVOS,
         SUM(NVL(MODIFICACIONES,0)) MODIFICACIONES,
         SUM(NVL(TRANSMISIONES,0)) TRANSMISIONES,
         SUM(NVL(RECTIFICACION,0)) RECTIFICACION,
         SUM(NVL(RENOVACIONES,0)) RENOVACIONES,
         SUM(NVL(CANCELACIONES,0)) CANCELACIONES,
         SUM(NVL(ANOTACIONES,0)) ANOTACIONES,
         SUM(NVL(CERTIFICACIONES,0)) CERTIFICACIONES,
         SUM(NVL(ALTA_ACREEDORES,0)) ALTA_ACREEDORES  
  FROM ('
||vlConsulta||
' ) group by fecha
    ORDER BY fecha ';     

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepGrafXDia> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepGrafXDia> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepGrafXDia;


--*******************************************************************************************************************************
--*Nombre:   FRepAcredores    Devuelve los datos de los acreedores registrados hasta el momento sin importar la garantia
--*Creado:   Alicia Maya      Fecha Elaboracion: 25/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepAcredores  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');     

    --Busca Query Base
    vlConsulta := funObtenQuery(12);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta, '@FECHA',  peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepAcredores> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepAcredores> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepAcredores;


--*******************************************************************************************************************************
--*Nombre:   FRepAcreeTot     Devuelve el resumen del Reporte de ACreedores
--*Creado:   Alicia Maya      Fecha Elaboracion: 17/May/2011
--*******************************************************************************************************************************
FUNCTION FRepAcreeTot  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');     

    --Busca Query Base
    vlConsulta := funObtenQuery(6);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta, '@FECHA', peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);

    vlConsulta :=
' SELECT  PER_ACREEDOR, DECODE(TIPO_PERFIL, 1, ''FEDATARIO'', 2, ''ACREEDOR'', 3 ,''CIUDADANO'') DESC_TIPO_PERFIL ,COUNT(*) CANTIDAD
  FROM ( '||vlConsulta ||' )
  GROUP BY PER_ACREEDOR, TIPO_PERFIL ';

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepAcreeTot> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepAcreeTot> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepAcreeTot;

--*******************************************************************************************************************************
--*Nombre:   FRepTotXUsu      Devuelve los totales por usuario a una fecha solicitada
--*Creado:   Alicia Maya      Fecha Elaboracion: 25/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepTotXUsu  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlWhere     Varchar2(100);
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');     

    --Busca Query Base
    vlConsulta := funObtenQuery(2);

    --Edita los parametros en el query base
    --vlWhere    := ' AND   FECHA_STATUS <= '''||to_char(peFecha,'dd/mm/yyyy')||'''';
    vlWhere    := ' AND   FECHA_STATUS <= to_date('''||peFecha||''',''dd/mm/yyyy'')  ';
    --vlConsulta := replace(vlConsulta,'@FECHAINI',to_char(trunc(peFecha,'mm'),'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHASWHERE',vlWhere);
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta, '@FECHA', peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);

    vlConsulta:=
' SELECT id_persona, nombre,
         cve_usuario, 
         cve_perfil,
         (  SELECT   MAX(TELEFONO || DECODE (EXTENSION, '''', '''', '' EXT '' || EXTENSION))
            FROM     RUG.RUG_TELEFONOS
            WHERE    ID_PERSONA = DAT.ID_PERSONA
            GROUP BY ID_PERSONA)  TELEFONO,
         desc_grupo,
         SUM(NVL(TOTAL,0))TOTAL,
         SUM(NVL(INSCRIPCIONES,0)) INSCRIPCIONES,
         SUM(NVL(AVISOS_PREVENTIVOS,0)) AVISOS_PREVENTIVOS,
         SUM(NVL(MODIFICACIONES,0)) MODIFICACIONES,
         SUM(NVL(TRANSMISIONES,0)) TRANSMISIONES,
         SUM(NVL(RECTIFICACION,0)) RECTIFICACION,
         SUM(NVL(RENOVACIONES,0)) RENOVACIONES,
         SUM(NVL(CANCELACIONES,0))CANCELACIONES,
         SUM(NVL(ANOTACIONES,0))ANOTACIONES,
         SUM(NVL(CERTIFICACIONES,0))CERTIFICACIONES,
         SUM(NVL(ALTA_ACREEDORES,0))ALTA_ACREEDORES  
  FROM ('
||vlConsulta||
' ) DAT
    group by id_persona, nombre, cve_usuario, cve_perfil, desc_grupo
    ORDER BY id_persona ';     
--SUM(NVL(ALTA_ACREEDOR,0)),

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepTotXUsu> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepTotXUsu> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepTotXUsu;



--*******************************************************************************************************************************
--*Nombre:   FRepTotXUsuXAcre Devuelve los datos del Reporte Seguimiento RUG Usuarios y Acreedores
--*Creado:   Alicia Maya      Fecha Elaboracion: 26/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepTotXUsuXAcre  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlWhere     Varchar2(100);
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');     

    --Busca Query Base
    vlConsulta := funObtenQuery(7);

    --Edita los parametros en el query base
    /*vlWhere    := ' AND   FECHA_STATUS <= '''||to_char(peFecha,'dd/mm/yyyy')||'''';

    vlConsulta := replace(vlConsulta,'@FECHASWHERE',vlWhere);
    vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    */
    vlWhere    := ' AND   FECHA_STATUS <= to_date('''||peFecha||''',''dd/mm/yyyy'')';
    vlConsulta := replace(vlConsulta,'@FECHASWHERE',vlWhere);
    vlConsulta := replace(vlConsulta,  '@FECHA', peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);

 /*SUM(NVL(INSCRIPCIONES,0) + NVL(MODIFICACIONES,0) + NVL(TRANSMISIONES,0) +
             NVL(RECTIFICACION,0)+ NVL(RENOVACIONES,0)   + NVL(CANCELACIONES,0) +
             NVL(ANOTACIONES,0)  + NVL(ALTA_ACREEDORES,0)) TOTAL , (SELECT CVE_USUARIO FROM RUG.RUG_SECU_USUARIOS WHERE ID_PERSONA = DAT.ID_PERSONA)*/
    vlConsulta:=
' SELECT id_persona, nombre,
         CVE_USUARIO "CVE USUARIO",
         cve_perfil "CVE PERFIL",
         DESC_GRUPO,
         (SELECT   MAX(TELEFONO || DECODE (EXTENSION, '''', '''', '' EXT '' || EXTENSION))
          FROM     RUG.RUG_TELEFONOS
          WHERE    ID_PERSONA = DAT.ID_PERSONA
          GROUP BY ID_PERSONA)  TELEFONO,
         NOMBRE_ACREEDOR "NOMBRE ACREEDOR",
         SUM(NVL(TOTAL,0)) TOTAL,
         SUM(NVL(INSCRIPCIONES,0)) INSCRIPCIONES,
         SUM(NVL(AVISOS_PREVENTIVOS,0)) AVISOS_PREVENTIVOS,
         SUM(NVL(MODIFICACIONES,0)) MODIFICACIONES,
         SUM(NVL(TRANSMISIONES,0)) TRANSMISIONES,
         SUM(NVL(RECTIFICACION,0)) RECTIFICACION,
         SUM(NVL(RENOVACIONES,0)) RENOVACIONES,
         SUM(NVL(CANCELACIONES,0)) CANCELACIONES,
         SUM(NVL(ANOTACIONES,0)) ANOTACIONES,
         SUM(NVL(CERTIFICACIONES,0)) CERTIFICACIONES,
         SUM(NVL(ALTA_ACREEDORES,0)) ALTA_ACREEDORES  
  FROM ('
||vlConsulta||
' ) DAT
    group by id_persona, nombre, CVE_USUARIO, cve_perfil, DESC_GRUPO, nombre_acreedor
    ORDER BY id_persona ';   

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepTotXUsuXAcre> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepTotXUsuXAcre> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepTotXUsuXAcre;


--*******************************************************************************************************************************
--*Nombre:   FRepInsDiarias   Devuelve los datos del Reporte de inscripciones diarias
--*Creado:   Alicia Maya      Fecha Elaboracion: 27/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepInsDiarias  (peFechaI  IN  VARCHAR2,
                          peFechaF  IN  VARCHAR2 ) 

RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlWhere     Varchar2(500);
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');     

    --Busca Query Base
    vlConsulta := funObtenQuery(2);

    --Edita los parametros en el query base
    /*vlWhere    := ' AND   FECHA_STATUS BETWEEN '''||to_char(peFechaI,'dd/mm/yyyy')||''' AND '''||to_char(peFechaF,'dd/mm/yyyy')||'''';
    vlConsulta := replace(vlConsulta,'@FECHASWHERE',vlWhere);
    vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFechaF,'dd/mm/yyyy'));
    */
    vlWhere    := ' AND   FECHA_STATUS BETWEEN to_date('''||peFechaI||''',''dd/mm/yyyy'') AND to_date('''||peFechaF||''',''dd/mm/yyyy'')';
    vlConsulta := replace(vlConsulta,'@FECHASWHERE',vlWhere);
    vlConsulta := replace(vlConsulta, '@FECHA',  peFechaF);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);

    vlConsulta:=
' SELECT TO_CHAR(FECHA,''YYYYMMDD'') ANIOMESDIA, 
         MIN(TO_CHAR(FECHA,''MON/YYYY'')) PERIODO, 
         MIN(TO_CHAR(FECHA,''YYYY'')) ANIO, 
         (MIN(TO_CHAR(FECHA,''DY DD/MON/YYYY''))) AS DIA,
         SUM(NVL(INSCRIPCIONES,0)) GARANTIAS_INSCRITAS  
  FROM ('
||vlConsulta||
' ) DAT
    group by TO_CHAR(FECHA,''YYYYMMDD'')
    ORDER BY ANIOMESDIA ASC ';   

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepInsDiarias> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepInsDiarias> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepInsDiarias;



--*******************************************************************************************************************************
--*Nombre:   FRepGrafMen      Devuelve los datos del REPORTE GRAFICO SALDO MENSUAL
--*Creado:   Alicia Maya      Fecha Elaboracion: 27/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepGrafMen  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlWhere     Varchar2(100);
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');     

    --Busca Query Base
    vlConsulta := funObtenQuery(2);

    --Edita los parametros en el query base
/*    vlWhere    := ' AND   FECHA_STATUS <= '''||to_char(peFecha,'dd/mm/yyyy')||''' ';
    vlConsulta := replace(vlConsulta,'@FECHASWHERE',vlWhere);
    vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
*/    
    vlWhere    := ' AND   FECHA_STATUS <= to_date( '''||peFecha||''', ''dd/mm/yyyy'') ';
    vlConsulta := replace(vlConsulta,'@FECHASWHERE',vlWhere);
    vlConsulta := replace(vlConsulta,  '@FECHA', peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);

    vlConsulta:=
' SELECT TO_CHAR(FECHA,''YYYYMM'') ANIOMES, 
         MIN(TO_CHAR(FECHA,''MON/YYYY'')) PERIODO, 
         ( SUM(INSCRIPCIONES) + 
           SUM(CERTIFICACIONES) + 
           SUM(MODIFICACIONES) + 
           SUM(TRANSMISIONES) + 
           SUM(RECTIFICACION) + 
           SUM(RENOVACIONES) + 
           SUM(CANCELACIONES) + 
           SUM(ANOTACIONES) + 
           SUM(AVISOS_PREVENTIVOS)) OPERACIONES,
         SUM(NVL(INSCRIPCIONES,0)) GARANTIAS_INSCRITAS ,
        (SUM(INSCRIPCIONES) + SUM(ANOTACIONES)) SALDO_DIA 
  FROM ( '
||vlConsulta||
' ) DAT
    group by TO_CHAR(FECHA,''YYYYMM'')
    ORDER BY ANIOMES ASC  ';   

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepGrafMen> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepGrafMen> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepGrafMen;



--*******************************************************************************************************************************
--*Nombre:   FRepTotAcre      Devuelve los datos del Reporte de trámites por Acreedor
--*Creado:   Alicia Maya      Fecha Elaboracion: 29/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepTotAcre  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlWhere     Varchar2(100);
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');     

    --Busca Query Base
    vlConsulta := funObtenQuery(7);

    --Edita los parametros en el query base
/*    vlWhere    := ' AND   FECHA_STATUS <= '''||to_char(peFecha,'dd/mm/yyyy')||'''';
    vlConsulta := replace(vlConsulta,'@FECHASWHERE',vlWhere);
    vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
*/
    vlWhere    := ' AND   FECHA_STATUS <= to_date('''||peFecha||''',''dd/mm/yyyy'') ';
    vlConsulta := replace(vlConsulta,'@FECHASWHERE',vlWhere);
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);

    vlConsulta:=
' SELECT NOMBRE_ACREEDOR,
         SUM(NVL(INSCRIPCIONES,0) + NVL(MODIFICACIONES,0) + NVL(TRANSMISIONES,0) +
             NVL(RECTIFICACION,0)+ NVL(RENOVACIONES,0)   + NVL(CANCELACIONES,0) +
             NVL(ANOTACIONES,0)  + NVL(ALTA_ACREEDORES,0)) TOTAL,
         SUM(NVL(INSCRIPCIONES,0)) INSCRIPCIONES,
         SUM(NVL(AVISOS_PREVENTIVOS,0)) AVISOS_PREVENTIVOS,
         SUM(NVL(MODIFICACIONES,0)) MODIFICACIONES,
         SUM(NVL(TRANSMISIONES,0)) TRANSMISIONES,
         SUM(NVL(RECTIFICACION,0)) RECTIFICACION,
         SUM(NVL(RENOVACIONES,0)) RENOVACIONES,
         SUM(NVL(CANCELACIONES,0)) CANCELACIONES,
         SUM(NVL(ANOTACIONES,0)) ANOTACIONES,
         SUM(NVL(CERTIFICACIONES,0)) CERTIFICACIONES,
         SUM(NVL(ALTA_ACREEDORES,0)) ALTA_ACREEDORES  
  FROM ('
||vlConsulta||
' ) DAT
    group by nombre_acreedor ';   

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepTotAcre> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepTotAcre> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepTotAcre;


--*******************************************************************************************************************************
--*Nombre:   FRepUsuGpo       Devuelve los datos del Reporte inscripciones por usuario con grupo de usuario
--*Creado:   Alicia Maya      Fecha Elaboracion: 18/May/2011
--*******************************************************************************************************************************
FUNCTION FRepUsuGpo  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlWhere     Varchar2(100);
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');     

    --Busca Query Base
    vlConsulta := funObtenQuery(7);

    --Edita los parametros en el query base
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);

/*    vlWhere    := ' AND   FECHA_STATUS <= '''||to_char(peFecha,'dd/mm/yyyy')||'''';
    vlConsulta := replace(vlConsulta,'@FECHASWHERE',vlWhere);
    vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
*/
    vlWhere    := ' AND   FECHA_STATUS <= to_date('''||peFecha||''',''dd/mm/yyyy'')';
    vlConsulta := replace(vlConsulta,'@FECHASWHERE',vlWhere);
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);


    vlConsulta:=
' SELECT id_persona, nombre, cve_usuario "CVE USUARIO", cve_perfil "CVE PERFIL", desc_grupo,
         (SELECT   MAX(TELEFONO || DECODE (EXTENSION, '''', '''', '' EXT '' || EXTENSION))
          FROM     RUG.RUG_TELEFONOS
          WHERE    ID_PERSONA = DAT.ID_PERSONA
          GROUP BY ID_PERSONA)  TELEFONO,
         SUM(NVL(TOTAL,0)) TOTAL,
         SUM(NVL(INSCRIPCIONES,0)) INSCRIPCIONES,
         SUM(NVL(AVISOS_PREVENTIVOS,0)) AVISOS_PREVENTIVOS,
         SUM(NVL(MODIFICACIONES,0)) MODIFICACIONES,
         SUM(NVL(TRANSMISIONES,0)) TRANSMISIONES,
         SUM(NVL(RECTIFICACION,0)) RECTIFICACION,
         SUM(NVL(RENOVACIONES,0)) RENOVACIONES,
         SUM(NVL(CANCELACIONES,0)) CANCELACIONES,
         SUM(NVL(ANOTACIONES,0)) ANOTACIONES,
         SUM(NVL(CERTIFICACIONES,0)) CERTIFICACIONES,
         SUM(NVL(ALTA_ACREEDORES,0)) ALTA_ACREEDORES  
  FROM ('
||vlConsulta||
' ) DAT
    group by id_persona, nombre, cve_usuario, cve_perfil, desc_grupo 
    ORDER BY id_persona ';   

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepUsuGpo> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepUsuGpo> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepUsuGpo;


--*******************************************************************************************************************************
--*Nombre:   FRepDiario       Devuelve los datos del Reporte Estadísticos Diario del RUG
--*Creado:   Alicia Maya      Fecha Elaboracion: 03/May/2011
--*******************************************************************************************************************************
FUNCTION FRepDiario  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlConsulta2 RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlWhere     Varchar2(100);
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');     

    --Busca Query Base
    vlConsulta := funObtenQuery(7);

    --Edita los parametros en el query base
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);

/*
    vlConsulta2:=vlConsulta;
    vlWhere    := ' AND   FECHA_STATUS = '''||to_char(peFecha,'dd/mm/yyyy')||'''';
    vlConsulta := replace(vlConsulta,'@FECHASWHERE',vlWhere);
    vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));

    vlWhere    := ' AND   FECHA_STATUS between ''07/10/2010'' AND '''||to_char(peFecha-1,'dd/mm/yyyy')||'''';
    vlConsulta2 := replace(vlConsulta2,'@FECHASWHERE',vlWhere);
    vlConsulta2 := replace(vlConsulta2,'@FECHA',to_char(peFecha-1,'dd/mm/yyyy'));
*/
    vlConsulta2:=vlConsulta;
    vlWhere    := ' AND   FECHA_STATUS = to_date('''||peFecha||''',''dd/mm/yyyy'') ';
    vlConsulta := replace(vlConsulta,'@FECHASWHERE',vlWhere);
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);

    vlWhere    := ' AND   FECHA_STATUS between to_date(''07/10/2010'',''dd/mm/yyyy'') AND to_date('''||to_char(to_date(peFecha,'dd/mm/yyyy')-1,'dd/mm/yyyy')||''',''dd/mm/yyyy'')';
    vlConsulta2 := replace(vlConsulta2,'@FECHASWHERE',vlWhere);
    vlConsulta2 := replace(vlConsulta2,'@FECHA',to_char(to_date(peFecha,'dd/mm/yyyy')-1,'dd/mm/yyyy'));


    vlConsulta:=
' SELECT * FROM( '||
' SELECT TO_CHAR(TO_DATE('''||peFecha||''',''DD/MM/YYYY''), ''YYYYMM'') ANIOMES , 
         TO_CHAR(TO_DATE('''||peFecha||''',''DD/MM/YYYY''), ''DDMonYY'') AS PERIODO,
         SUM(NVL(INSCRIPCIONES,0)) INSCRIPCIONES,
         SUM(NVL(AVISOS_PREVENTIVOS,0)) AVISOS_PREVENTIVOS,
         SUM(NVL(MODIFICACIONES,0))    MODIFICACIONES,
         SUM(NVL(TRANSMISIONES,0))     TRANSMISIONES,
         SUM(NVL(RECTIFICACION,0))     RECTIFICACION,
         SUM(NVL(RENOVACIONES,0))      RENOVACIONES,
         SUM(NVL(CANCELACIONES,0))     CANCELACIONES,
         SUM(NVL(ANOTACIONES,0))       ANOTACIONES,
         SUM(NVL(CERTIFICACIONES,0))   CERTIFICACIONES,
         SUM(NVL(ALTA_ACREEDORES,0))   ALTA_ACREEDORES,
         SUM (TOTAL) TOTAL 
  FROM ('
||vlConsulta||
--     SELECT TO_CHAR(FECHA,'YYYYMM') ANIOMES, ( TO_CHAR(decode(TO_CHAR(MIN(FECHA),'MM'), '10', MIN(TO_CHAR(FECHA,'DD')), '01')) || ' al ' || 
--TO_CHAR(decode(TO_CHAR(MAX(FECHA),'MM'),'" + sMes + "',TO_DATE('2011-05-01', 'YYYY-MM-DD')-1, last_day(MAX(FECHA))),'DD/Mon/YY') ) AS PERIODO, 
' ) DAT group by TO_CHAR(FECHA,''YYYYMM'') 
UNION ALL
SELECT TO_CHAR(Fecha,''YYYYMM'') ANIOMES , 
      ( TO_CHAR(decode(TO_CHAR(MIN(FECHA),''MM''), ''10'', MIN(TO_CHAR(FECHA,''DD'')), ''01'')) || '' al '' || 
TO_CHAR(decode(TO_CHAR(MAX(FECHA),''MM''),''" + sMes + "'',TO_DATE('''||peFecha||''', ''YYYY-MM-DD'')-1, last_day(MAX(FECHA))),''DD/Mon/YY'') ) AS PERIODO,
         SUM(NVL(INSCRIPCIONES,0)) INSCRIPCIONES,
         SUM(NVL(AVISOS_PREVENTIVOS,0)) AVISOS_PREVENTIVOS,
         SUM(NVL(MODIFICACIONES,0))    MODIFICACIONES,
         SUM(NVL(TRANSMISIONES,0))     TRANSMISIONES,
         SUM(NVL(RECTIFICACION,0))     RECTIFICACION,
         SUM(NVL(RENOVACIONES,0))      RENOVACIONES,
         SUM(NVL(CANCELACIONES,0))     CANCELACIONES,
         SUM(NVL(ANOTACIONES,0))       ANOTACIONES,
         SUM(NVL(CERTIFICACIONES,0))   CERTIFICACIONES,
         SUM(NVL(ALTA_ACREEDORES,0))   ALTA_ACREEDORES,
         SUM (TOTAL) TOTAL 
  FROM ( '||vlConsulta2||'
  ) DAT group by TO_CHAR(FECHA,''YYYYMM'')
) ORDER BY ANIOMES DESC';  

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepDiario> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepDiario> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepDiario;


--*******************************************************************************************************************************
--*Nombre:   FRepTotXTipoGar   Devuelve el Reporte de Total por Tipo de Garantia
--*Creado:   Alicia Maya      Fecha Elaboracion: 25/May/2011
--*******************************************************************************************************************************
FUNCTION FRepTotXTipoGar  (peFecha  IN    VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlTCambio   RUG_REP_TIPOS_CAMBIO.TIPO_CAMBIO%TYPE;
    ERR_TCAMBIO EXCEPTION;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');
    vlTCambio  := funObtenTC(8,peFecha);
    if vlTCambio IS NULL or vlTCambio=0 then raise ERR_TCAMBIO; end if;

    --Busca Query Base
    vlConsulta := funObtenQuery(1);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);

   --Arma el query para el reporte
    vlConsulta := 
' SELECT  /*+RULE*/  id_tipo_garantia,  "DESC GTIA",   sum("MONTO GTIA PESOS")"MONTO PESOS", count(*) GARANTIAS   
  FROM'|| vlConsulta||
' group by id_tipo_garantia, "DESC GTIA"
  order by id_tipo_garantia  '; 

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN ERR_TCAMBIO THEN
           spDBMS('ERR <FRepTotXTipoGar> NO EXISTE EL TIPO DE CAMBIO DEL DOLAR');
           return NULL;
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepTotXTipoGar> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepTotXTipoGar> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepTotXTipoGar;



--*******************************************************************************************************************************
--*Nombre:   funObtTotGar     Devuelve el total de garantías del periodo
--*Creado:   Alicia Maya      Fecha Elaboracion: 11/May/2011
--*******************************************************************************************************************************
FUNCTION funObtTotGar(peFecha  IN  VARCHAR2)
RETURN   NUMBER  IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlNumero    Number;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := funObtenParam('MONTO_MIN');
    vlMontoMax := funObtenParam('MONTO_MAX');
    vlUsuarios := funObtenParam('USUARIOS');      

    --Busca Query Base
    vlConsulta := funObtenQuery(1);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',peFecha);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);

    --Arma el query para el reporte
    vlConsulta := 
' select /*+RULE*/  
         COUNT(*) TOTAL
   from '||
       vlConsulta||
'   dat  ';

    spDBMS(vlConsulta);
    OPEN vlRefCursor FOR vlConsulta;
    FETCH vlRefCursor  INTO vlNumero;
    if vlNumero is null then
       vlNumero := 0;
    end if;

    return vlNumero;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
          spDBMS('ERR <funObtTotGar> NO DATA FOUND'); 
          return 0;
      WHEN OTHERS THEN  
          spDBMS('ERR <funObtTotGar> '||SUBSTR(SQLERRM,1,1500));
          return 0;
END funObtTotGar;



--*******************************************************************************************************************************
--*Nombre:   funObtTipFed     Devuelve el tipo de Fedatario del portal a partir de la clave del usuario
--*Creado:   Alicia Maya      Fecha Elaboracion: 24/May/2011
--*******************************************************************************************************************************
FUNCTION funObtTipFed(peCveUsuario  IN  INFRA.secu_usuarios.cve_usuario%type)
RETURN   varchar2  IS
    vlCveUsuario  INFRA.secu_usuarios.cve_usuario%type;
BEGIN

    begin
        select  decode(ID_TIPO_FEDATARIO,1,'NOTARIO',2,'CORREDOR') TIPO 
        into    vlCveUsuario 
        from    INFRA.SECU_USUARIOS su, institucional.v_fedatarios vf 
        where   su.cve_usuario     = peCveUsuario
        and     vf.id_fedatario(+) = su.id_persona;
        exception
        when others then vlCveUsuario:='';
    end;

    return vlCveUsuario;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
          spDBMS('ERR <funObtTipFed> NO DATA FOUND'); 
          return '';
      WHEN OTHERS THEN  
          spDBMS('ERR <funObtTipFed> '||SUBSTR(SQLERRM,1,1500));
          return '';
END funObtTipFed;


--*******************************************************************************************************************************
--*Nombre:   FRepGaraInsXFechaInscr          Devuelve el Reporte de Total de garantias por Fecha de Inscripcion
--*Creado:   Alicia Maya / Gabriela Quevedo  Fecha Elaboracion: 30/May/2011
--*******************************************************************************************************************************
FUNCTION FRepGaraInsXFechaInscr  (peFecha  IN    VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
    --Busca los parametros para el reporte
    vlUsuarios := funObtenParam('USUARIOS');

    --Busca Query Base
    vlConsulta := funObtenQuery(9);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',   to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',   peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@CAMPO',   'rgh.fecha_inscr');
    vlConsulta := replace(vlConsulta,'@GROUPBY', ',rgh.fecha_inscr');

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepGaraInsXFechaInscr> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepGaraInsXFechaInscr> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepGaraInsXFechaInscr;


--*******************************************************************************************************************************
--*Nombre:   FRepGaraInsXFCelebCto           Devuelve el Reporte de Total de garantias por Fecha de celebración de contrato
--*Creado:   Alicia Maya / Gabriela Quevedo  Fecha Elaboracion: 30/May/2011
--*******************************************************************************************************************************
FUNCTION FRepGaraInsXFCelebCto  (peFecha  IN    VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
    --Busca los parametros para el reporte
        vlUsuarios := funObtenParam('USUARIOS');

    --Busca Query Base
    vlConsulta := funObtenQuery(9);

    --Edita los parametros en el query base
    --vlConsulta := replace(vlConsulta,'@FECHA',   to_char(peFecha,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@FECHA',   peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@CAMPO',   'max(vgc.fecha_celeb) fecha_inscr  ');
    vlConsulta := replace(vlConsulta,'@GROUPBY', '');

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepGaraInsXFCelebCto> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepGaraInsXFCelebCto> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepGaraInsXFCelebCto;





--*******************************************************************************************************************************
--*Nombre:   FRepUniversoUsuarios         Devuelve el Reporte de universo de usuarios tomado del RUG y complementado de tuempresa
--*Creado:   Alicia Maya 03 nov 2011
--*******************************************************************************************************************************
FUNCTION FRepUniversoUsuarios  (peFecha  IN    VARCHAR2) 
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG_REP_PARAM.TX_PARAMETRO%TYPE;
BEGIN
    --Busca los parametros para el reporte
    vlUsuarios := funObtenParam('USUARIOS');

    --Busca Query Base
    vlConsulta := funObtenQuery(11);

    --Edita los parametros en el query base
    vlConsulta := replace(vlConsulta,'@FECHA',   peFecha);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);

    spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           spDBMS('ERR <FRepUniversoUsuarios> NO_DATA_FOUND');
           return NULL;
      WHEN OTHERS THEN 
           spDBMS('ERR <FRepUniversoUsuarios> '||SUBSTR(SQLERRM,1,1500));
           return null;
END FRepUniversoUsuarios;



--*******************************************************************************************************************************
--*Nombre:   funObtTotGarRango Total de Garantais por rango de fechas
--*Creado:   Gabriela Quevedo      Fecha Elaboracion: 05/07/2011
--*******************************************************************************************************************************

FUNCTION funObtTotGarRango(peFechaI  IN  Date,
                           peFechaF  IN  Date)
RETURN   NUMBER  IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  rug.RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  rug.RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  rug.RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  rug.RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlNumero    Number;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := rug.pkgreportes.funObtenParam('MONTO_MIN');
    vlMontoMax := rug.pkgreportes.funObtenParam('MONTO_MAX');
    vlUsuarios := rug.pkgreportes.funObtenParam('USUARIOS');      

    --Busca Query Base
    vlConsulta := rug.pkgreportes.funObtenQuery(5);

    --Edita los parametros en el query base
    vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFechaF,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);

    --Arma el query para el reporte
    vlConsulta :=

' select /*+RULE*/  
         COUNT(*) TOTAL
   from '||
       vlConsulta||
'   dat  WHERE "FECHA CREACION">= TO_DATE('''||to_char(peFechai,'dd/mm/yyyy')||''', ''DD/MM/YYYY'')'||  
'    AND "FECHA CREACION"<= TO_DATE('''||to_char(peFechaf,'dd/mm/yyyy')||''', ''DD/MM/YYYY'')';

    rug.pkgreportes.spDBMS(vlConsulta);
    OPEN vlRefCursor FOR vlConsulta;
    FETCH vlRefCursor  INTO vlNumero;
    if vlNumero is null then
       vlNumero := 0;
    end if;

    return vlNumero;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
          rug.pkgreportes.spDBMS('ERR <funObtTotGarRango> NO DATA FOUND'); 
          return 0;
      WHEN OTHERS THEN  
          rug.pkgreportes.spDBMS('ERR <funObtTotGarRango> '||SUBSTR(SQLERRM,1,1500));
          return 0;
END funObtTotGarRango;
--*******************************************************************************************************************************
--*Nombre:   funObtTotMontoRango Devuelve el total del monto  garantizado en pesos de una ranto de fecha determinada
--*Creado:   Gabriela Quevedo      Fecha Elaboracion: 05/07/2011
--*******************************************************************************************************************************

FUNCTION funObtTotMontoRango(peFechaI  IN  Date,
                           peFechaF  IN  Date)
RETURN   NUMBER  IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  rug.RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  rug.RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  rug.RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  rug.RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlNumero    Number;
BEGIN
    --Busca los parametros para el reporte
    vlMontoMin := rug.pkgreportes.funObtenParam('MONTO_MIN');
    vlMontoMax := rug.pkgreportes.funObtenParam('MONTO_MAX');
    vlUsuarios := rug.pkgreportes.funObtenParam('USUARIOS');      

    --Busca Query Base
    vlConsulta := rug.pkgreportes.funObtenQuery(1);

    --Edita los parametros en el query base
    vlConsulta := replace(vlConsulta,'>''@FECHA''','>TRUNC(VTT.FECHA_CREACION)+1');
    vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFechaF,'dd/mm/yyyy'));
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);

    --Arma el query para el reporte
    vlConsulta :=

' select /*+RULE*/  
         SUM("MONTO GTIA PESOS") TOTAL
   from '||
       vlConsulta||
'   dat  WHERE "FECHA CREACION">= TO_DATE('''||to_char(peFechai,'dd/mm/yyyy')||''', ''DD/MM/YYYY'')'||  
'    AND "FECHA CREACION"<= TO_DATE('''||to_char(peFechaf,'dd/mm/yyyy')||''', ''DD/MM/YYYY'')';

    rug.pkgreportes.spDBMS(vlConsulta);
    OPEN vlRefCursor FOR vlConsulta;
    FETCH vlRefCursor  INTO vlNumero;
    if vlNumero is null then
       vlNumero := 0;
    end if;

    return vlNumero;     

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
          rug.pkgreportes.spDBMS('ERR <funObtTotMontoRango> NO DATA FOUND'); 
          return 0;
      WHEN OTHERS THEN  
          rug.pkgreportes.spDBMS('ERR <funObtTotMontoRango> '||SUBSTR(SQLERRM,1,1500));
          return 0;
END funObtTotMontoRango;
--*******************************************************************************************************************************
--*Nombre:   funObtTotRango Devuelve el total de acreedores, usuarios, inscripciones y garantias vigentes en un rango de fechas
--*Creado:   Gabriela Quevedo      Fecha Elaboracion: 05/07/2011
--*******************************************************************************************************************************

function funObtTotRango(peFechaI  IN  Date,
                        peFechaF  IN  Date)
RETURN SYS_REFCURSOR IS
    vlRefCursor SYS_REFCURSOR; 
    vlConsulta  RUG.RUG_REP_CONSULTAS.TX_CONSULTA%TYPE;
    vlUsuarios  RUG.RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMin  RUG.RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlMontoMax  RUG.RUG_REP_PARAM.TX_PARAMETRO%TYPE;
    vlWhere     Varchar2(100);
BEGIN
    RUG.PKGREPORTES.vgBanderaMensajes:='V';
    --Busca los parametros para el reporte
    vlMontoMin := rug.pkgreportes.funObtenParam('MONTO_MIN');
    vlMontoMax := rug.pkgreportes.funObtenParam('MONTO_MAX');
    vlUsuarios := rug.pkgreportes.funObtenParam('USUARIOS');      

    --Busca Query Base
    vlConsulta := rug.pkgreportes.funObtenQuery(2);
    DBMS_OUTPUT.PUT_lINE('AQUI VOY');
    --Edita los parametros en el query base
    vlWhere    := ' AND   FECHA_STATUS BETWEEN '''||to_char(peFechaI,'dd/mm/yyyy')||''' AND '''||to_char(peFechaF,'dd/mm/yyyy')||'''';
    vlConsulta := replace(vlConsulta,'@USUARIOS',vlUsuarios);
    vlConsulta := replace(vlConsulta,'@MONTO_MIN',vlMontoMin);
    vlConsulta := replace(vlConsulta,'@MONTO_MAX',vlMontoMax);
    vlConsulta := replace(vlConsulta,'@FECHASWHERE',vlWhere);    
--    vlConsulta := replace(vlConsulta,'@FECHA',to_char(peFecha,'dd/mm/yyyy'));

    --Arma el query para el reporte
    vlConsulta :=

'SELECT  SUM(ALTA_ACREEDOR) ALTA_ACREEDOR,
         sum(USUARIOS_CIUDADANOS) USUARIOS_CIUDADANOS,
         sum(USUARIOS_AUTORIDADES) USUARIOS_AUTORIDADES,
         SUM(INSCRIPCIONES) INSCRIPCIONES,
         SUM(GARANTIAS_VIGENTES) GARANTIAS_VIGENTES
 FROM (
 select /*+RULE*/  
         sum(ALTA_ACREEDOR) ALTA_ACREEDOR,
         sum(USUARIOS_CIUDADANOS)+ sum(USUARIOS_ACREEDORES) USUARIOS_CIUDADANOS,
         sum(USUARIOS_AUTORIDADES) USUARIOS_AUTORIDADES,
         0 INSCRIPCIONES,
         0 GARANTIAS_VIGENTES
   from rug.V_REP_SOLICITUD_GTIAS '||
'  WHERE FECHA>= TO_DATE('''||to_char(peFechai,'dd/mm/yyyy')||''', ''DD/MM/YYYY'')'||  
'    AND FECHA <= TO_DATE('''||to_char(peFechaf,'dd/mm/yyyy')||''', ''DD/MM/YYYY'')'||
'UNION ALL
  SELECT 0 ALTA_ACREEDOR,
         0 USUARIOS_CIUDADANOS,
         0 USUARIOS_AUTORIDADES,
         SUM(INSCRIPCIONES) INSCRIPCIONES,
         SUM(INSCRIPCIONES- CANCELACIONES + ANOTACIONES) GARANTIAS_VIGENTES
  FROM ( '|| VlConsulta || '))';

    RUG.PKGREPORTES.spDBMS(vlConsulta);

    OPEN vlRefCursor FOR vlConsulta;
    return vlRefCursor;     
    RUG.PKGREPORTES.vgBanderaMensajes:='F';

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
          rug.pkgreportes.spDBMS('ERR <funObtTotRango> NO DATA FOUND'); 
          return NULL;
      WHEN OTHERS THEN  
          rug.pkgreportes.spDBMS('ERR <funObtTotRango> '||SUBSTR(SQLERRM,1,1500));
          return NULL;
END funObtTotRango;
--*******************************************************************************************************************************
--*Nombre:   FNREPESTCOMPRUG Devuelve los datos del reporte 
--*Creado:   Gabriela Quevedo      Fecha Elaboracion: 05/07/2011
--*******************************************************************************************************************************


FUNCTION FNREPESTCOMPRUG(fcorte date) 
RETURN SYS_REFCURSOR
IS

vlRefCursor   SYS_REFCURSOR; 
vlAnioAct     varchar2(6);
VlAnioAnt     varchar2(6);
vlFechaIniAct DATE;
vlFechaFinAct DATE;
vlFechaIniAnt DATE;
vlFechaFinAnt DATE;
vlmes         varchar2(100);
vlmesi        Integer;
vlGarVigAct   Integer;
vlGarVigAnt   Integer;
vlPromGarVigAct    Integer;
vlPromGarVigAnt    Integer;
vlPctGarVig        Integer;
vlGarVigTot        Integer;
vlInscripAct       Integer;
vlInscripAnt       Integer;
vlPromInscripAct   Integer;
vlPromInscripAnt   Integer;
vlPctInscrip       Integer;
vlInscripTot       Integer;
vlMtoGarVigAct     number(20,2);
vlMtoGarVigAnt     number(20,2);
vlMtoGarVigTot     number(20,2);                           
vlPromMtoGarVigAct number(20,2);
vlPromMtoGarVigAnt number(20,2);
vlPctMtoGarVig     Integer;
vlAcreedorAct      Integer;
vlAcreedorAnt      Integer;
vlAcreedorTot      Integer;                           
vlPromAcreedorAct  Integer;
vlPromAcreedorAnt  Integer;
vlPctAcreedor      Integer;
vlUsuAutAct        Integer;
vlUsuAutAnt        Integer;
vlUsuAutTot        Integer;                           
vlPromUsuAutAct    Integer;
vlPromUsuAutAnt    Integer;
vlPctUsuAut        Integer;
vlUsuPartAct       Integer;
vlUsuPartAnt       Integer;
vlUsuPartTot       Integer;                           
vlPromUsuPartAct   Integer;
vlPromUsuPartAnt   Integer;
vlPctUsuPart       Integer;
vlCursor           SYS_REFCURSOR;


BEGIN

RUG.PKGREPORTES.vgBanderaMensajes:='F'; 
vlFechaFinAct :=  TO_DATE(('01/'||TRIM(to_char(fCorte, 'MM/YYYY'))), 'DD/MM/YYYY')-1;
VlAnioACT     := to_char(fCorte, 'YYYY');
vlFechaIniAct := TO_DATE(('01/01/'||TRIM(to_char(vlFechaFinAct, 'YYYY'))), 'DD/MM/YYYY');
VlAnioAnt     := TO_CHAR(vlFechaIniAct-1, 'YYYY');
vlFechaIniAnt := TO_DATE('01/01/'||VlAnioAnt, 'DD/MM/YYYY');
DBMS_OUTPUT.PUT_lINE('AQUI VOY'||VlAnioAnt);
IF (fCorte<TO_DATE('01/12/2011', 'DD/MM/YYYY')) THEN
   vlFechaFinAnt := TO_DATE('31/12/'||VlAnioAnt , 'DD/MM/YYYY');
ELSE   

   vlFechaFinAnt := TO_DATE(to_char(vlFechaFinAct,'dd/mm' )||'/'||VlAnioAnt , 'DD/MM/YYYY');
END IF;      

vlmesi := TO_NUMBER(TO_char(vlFechaFinAct,'MM'));
DBMS_OUTPUT.PUT_lINE('MES'||vlmesi);

select  InitCap(to_char(vlFechaFinAct,'month','NLS_LANGUAGE=SPANISH'))
  into vlmes
 from dual;  

/* Garantias vigentes */
vlCursor:= funObtTotRango(vlFechaIniAct, vlFechaFinAct);
--ACREEDOR, USUARIOS CIUDADANOS, USUARIOS AUTORIDADES, INSCRIPCIONES, GARANTIAS VIGENTES
loop fetch vlCursor into vlAcreedorAct,  vlUsuPartAct, vlUsuAutAct, vlInscripAct, vlGarVigAct;
          exit when vlCursor%notfound;
end loop;

vlCursor:= funObtTotRango(vlFechaIniAnt, vlFechaFinAnt);
loop fetch vlCursor into vlAcreedorAnt, vlUsuPartAnt,  vlUsuAutAnt,vlInscripAnt, vlGarVigAnt;
          exit when vlCursor%notfound;
end loop;

vlCursor:= funObtTotRango(to_date('01/10/2010', 'dd/mm/yyyy'), fCorte);
loop fetch vlCursor into vlAcreedorTot, vlUsuPartTot, vlUsuAutTot, vlInscripTot, vlGarVigTot;
          exit when vlCursor%notfound;
end loop;

DBMS_OUTPUT.PUT_lINE('AQUI VOY');

vlPromGarVigAct:= ROUND(vlGarVigAct/vlmesi);
vlPromGarVigAnt:= ROUND(vlGarVigAnt/vlmesi);
vlPctGarVig:= round((vlPromGarVigAct*100/vlPromGarVigAnt)-100);

vlPromInscripAct:= ROUND(vlInscripAct/vlmesi);
vlPromInscripAnt:= ROUND(vlInscripAnt/vlmesi);
vlPctInscrip  := round((vlPromInscripAct*100/vlPromInscripAnt)-100);

vlPromAcreedorAct:= ROUND(vlAcreedorAct/vlmesi);
vlPromAcreedorAnt:= ROUND(vlAcreedorAnt/vlmesi);
vlPctAcreedor:= round((vlAcreedorAct*100/vlAcreedorAnt)-100);

vlPromUsuAutAct    := ROUND(vlUsuAutAct/vlmesi);
vlPromUsuAutAnt    := ROUND(vlUsuAutAnt/vlmesi);
vlPctUsuAut        := round((vlUsuAutAct*100/vlUsuAutAnt)-100);

vlPromUsuPartAct   := ROUND(vlUsuPartAct/vlmesi);
vlPromUsuPartAnt   := ROUND(vlUsuPartAnt/vlmesi);
vlPctUsuPart       := round((vlUsuPartAct*100/vlUsuPartAnt)-100);

vlMtoGarVigAct:= funObtTotMontoRango(vlFechaIniAct, vlFechaFinAct);
vlMtoGarVigAnt:= funObtTotMontoRango(vlFechaIniAnt, vlFechaFinAnt);
vlMtoGarVigTot:= funObtTotMontoRango(to_date('01/10/2010', 'dd/mm/yyyy'), fCorte);                           
vlPromMtoGarVigAct:= ROUND(vlMtoGarVigAct/vlmesi, 2);
vlPromMtoGarVigAnt:= ROUND(vlMtoGarVigAnt/vlmesi, 2);
vlPctMtoGarVig:= round((vlPromMtoGarVigAct*100/vlPromMtoGarVigAnt)-100);



OPEN vlRefCursor FOR
 select
        vlAnioAct   anio_ant,
        VlAnioAnt   anio_act, 
        vlmes       MES,
        vlGarVigAct GARANTIAS_ACT,        
        vlGarVigAnt GARANTIAS_ANT,
        vlGarVigTot GARANTIAS_TOT,
        vlPromGarVigAct GARANTIAS_PROM_ACT,
        vlPromGarVigAnt GARANTIAS_PROM_ANT,
        vlPctGarVig PCT_GARANTIAS,        
        vlMtoGarVigAct MONTOS_GTIAS_ACT,
        vlMtoGarVigAnt MONTOS_GTIAS_ANT,
        vlMtoGarVigTot MONTOS_GTIAS_TOT,                           
        vlPromMtoGarVigAct MONTOS_GTIAS_PROM_ACT,
        vlPromMtoGarVigAnt MONTOS_GTIAS_PROM_ANT,
        vlPctMtoGarVig PCT_MONTOS_GTIAS,
        vlInscripAct INSCRIPCIONES_ACT,
        vlInscripAnt INSCRIPCIONES_ANT,
        vlInscripTot INSCRIPCIONES_TOT,
        vlPromInscripAct INSCRIPCIONES_PROM_ACT,
        vlPromInscripAnt INSCRIPCIONES_PROM_ANT,
        vlPctInscrip PCT_INSCRIPCIONES,        
        vlAcreedorAct ACREEDORES_ACT,
        vlAcreedorAnt ACREEDORES_ANT,
        vlAcreedorTot ACREEDORES_TOT,                           
        vlPromAcreedorAct ACREEDORES_PROM_ACT,
        vlPromAcreedorAnt ACREEDORES_PROM_ANT,
        vlPctAcreedor PCT_ACREEDORES,        
        vlUsuAutAct USU_AUTORIDAD_ACT,
        vlUsuAutAnt USU_AUTORIDAD_ANT,
        vlUsuAutTot USU_AUTORIDAD_TOT,                           
        vlPromUsuAutAct USU_AUTORIDAD_PROM_ACT,
        vlPromUsuAutAnt USU_AUTORIDAD_PROM_ANT,
        vlPctUsuAut PCT_USU_AUTORIDAD,
        vlUsuPartAct USU_PARTICULAR_ACT,
        vlUsuPartAnt USU_PARTICULAR_ANT,
        vlUsuPartTot USU_PARTICULAR_TOT,                           
        vlPromUsuPartAct USU_PARTICULAR_PROM_ACT,
        vlPromUsuPartAnt USU_PARTICULAR_PROM_ANT,
        vlPctUsuPart PCT_USU_PARTICULAR_PROM       
   from dual;        


dbms_output.put_line('TERMINANDO');
RETURN vlRefCursor;


   EXCEPTION
  when others then
    dbms_output.put_line(sqlerrm);        
    RETURN null;  
END FNREPESTCOMPRUG;


END PKGREPORTES;
/

