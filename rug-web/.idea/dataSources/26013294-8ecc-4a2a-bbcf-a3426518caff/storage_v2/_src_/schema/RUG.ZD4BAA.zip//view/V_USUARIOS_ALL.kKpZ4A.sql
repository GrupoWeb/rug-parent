create view V_USUARIOS_ALL
            (E_MAIL, ID_PERFIL, CVE_PERFIL, PASSWORD, ID_PERSONA, NOMBRE_COMPLETO, NOMBRE_PERSONA, AP_PATERNO,
             AP_MATERNO, RFC, PREG_RECUPERA_PSW, ID_GRUPO, DESC_GRUPO, CVE_USUARIO_PADRE, CVE_ACREEDOR, SIT_USUARIO)
as
SELECT   /*+index(RSU) index(RP) index(RPF) index (RSPU) */
LOWER (RSU.CVE_USUARIO),
            RCP.ID_PERFIL,
            RSPU.CVE_PERFIL,
            RSU.PASSWORD,
            RSU.ID_PERSONA,
               RPF.NOMBRE_PERSONA
            || ' '
            || RPF.AP_PATERNO
            || ' '
            || RPF.AP_MATERNO
               NOMBRE_COMPLETO,
            RPF.NOMBRE_PERSONA,
            RPF.AP_PATERNO,
            RPF.AP_MATERNO,
            RP.RFC,
            RSU.PREG_RECUPERA_PSW,
            RSU.ID_GRUPO,
            RG.DESC_GRUPO,
            RSU.CVE_USUARIO_PADRE,
            RSU.CVE_ACREEDOR,
            RSU.SIT_USUARIO
     FROM   RUG_SECU_USUARIOS RSU,
            RUG_PERSONAS RP,
            RUG_PERSONAS_FISICAS RPF,
            RUG_SECU_PERFILES_USUARIO RSPU,
            RUG_GRUPOS RG,
            RUG_CAT_PERFILES RCP
    WHERE       RSU.ID_PERSONA = RP.ID_PERSONA
            AND RSU.ID_PERSONA = RPF.ID_PERSONA
            AND RSU.CVE_USUARIO = RSPU.CVE_USUARIO
            AND RSPU.CVE_PERFIL = RCP.CVE_PERFIL
            AND RG.ID_GRUPO(+) = RSU.ID_GRUPO
            AND RP.SIT_PERSONA = 'AC'
            AND RSPU.B_BLOQUEADO = 'F'
/

