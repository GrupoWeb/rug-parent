create PROCEDURE         SP_ALTAPARTE
                                                (
                                                    IdTramite IN NUMBER
                                                  , --idTramite al que se asignara la parte
                                                    IdParte IN NUMBER
                                                  , -- ID de tipo de parte, Acreedor, Deudor u Otorgante
                                                    peTipoPersona IN VARCHAR2
                                                  , -- Fisica (PF) o Moral(PM)
                                                    peRazonSocial IN VARCHAR2
                                                  , --Razon social (solo persona moral)
                                                    peNombre IN VARCHAR2
                                                  , --(solo persona fisica)
                                                    peApellidoP IN VARCHAR2
                                                  , --(solo persona fisica)
                                                    peApellidoM IN VARCHAR2
                                                  , --(solo persona fisica)
                                                    peFolioMercantil IN VARCHAR2
                                                  , peRFC            IN VARCHAR2
                                                  , peCURP           IN VARCHAR2
                                                  , peBDomicilio     IN CHAR
                                                  , --BANDERA QUE INDICA SI SE MANDA EL DOMICILIO LOS VALORES SON V o F
                                                    peCalle       IN VARCHAR2
                                                  , peNumExt      IN VARCHAR2
                                                  , peNumInt      IN VARCHAR2
                                                  , peIdColonia   IN NUMBER
                                                  , peIdLocalidad IN NUMBER
                                                  , peIdPersona   IN NUMBER
                                                  , --idPersona Usuario
                                                    peIdNacionalidad IN NUMBER
                                                  , peTelefono       IN VARCHAR2
                                                  , peExtension      IN VARCHAR2
                                                  , peEmail          IN VARCHAR2
                                                  , peDomicilioUno   IN VARCHAR2
                                                  , peDomicilioDos   IN VARCHAR2
                                                  , pePoblacion      IN VARCHAR2
                                                  , peZonaPostal     IN VARCHAR2
                                                  , pePaisResidencia IN NUMBER
                                                  , peInscrita       IN VARCHAR2
                                                  , peFolio          IN VARCHAR2
                                                  , peLibro          IN VARCHAR2
                                                  , peUbicada        IN VARCHAR2
                                                  , peEdad           IN VARCHAR2
                                                  , peEstadoCivil    IN VARCHAR2
                                                  , peProfesion      IN VARCHAR2
                                                  , psIdPersonaAlta OUT NUMBER
                                                  , --ID DE LA PERSONA QUE SE ACABA DE DAR DE ALTA
                                                    psResult OUT   INTEGER
                                                  , psTxResult OUT VARCHAR2
                                                  , peBandera IN   VARCHAR2 DEFAULT 'F'
                                                )
IS
    
    vlIdPersona             NUMBER;
    vlIdDomicilio           NUMBER;
    vlIdTipoTramite         NUMBER;
    vlCountColonias         NUMBER;
    vlCountCURPExiste       NUMBER;
    vlCountLocalidades      NUMBER;
    vlCountNacionalidad     NUMBER;
    vlFolioElectronicoExist VARCHAR(250);

    vlCurp VARCHAR(25);

    --VARIABLES VALIDACION RFC
    vlPsResultValRFC    NUMBER;
    vlPsTxtResultValRFC VARCHAR(4000);

    --VARIABLES VALIDACION DE CURP
    vlPsResultValCURP    NUMBER;
    vlPsTxtResultValCURP VARCHAR(4000);


    --Curp
    vlCountCurpRegExp NUMBER;

    Ex_CurpExistente EXCEPTION;
    Ex_Error         EXCEPTION;

    CURSOR cursPartes
                     (
                         cpeIdTramite IN NUMBER
                     )
    IS
        SELECT
               ID_PARTE
        FROM
               RUG_REL_TRAM_INC_PARTES
        WHERE
               ID_TRAMITE_TEMP = cpeIdTramite
               AND ID_PARTE IN (1
                              , 4)
               AND STATUS_REG = 'AC'
        ;

    cursPartes_Rec cursPartes%ROWTYPE;

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'IdTramite', IdTramite, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'IdParte', IdParte, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peTipoPersona', peTipoPersona, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peRazonSocial', peRazonSocial, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peNombre', peNombre, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peApellidoP', peApellidoP, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peFolioMercantil', peFolioMercantil, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peRFC', peRFC, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peCURP', peCURP, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peBDomicilio', peBDomicilio, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peCalle', peCalle, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peNumExt', peNumExt, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peNumInt', peNumInt, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peIdColonia', peIdColonia, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peIdLocalidad', peIdLocalidad, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peIdPersona', peIdPersona, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peIdNacionalidad', peIdNacionalidad, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peTelefono', peTelefono, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peExtension', peExtension, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peEmail', peEmail, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peDomicilioUno', peDomicilioUno, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peDomicilioDos', peDomicilioDos, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'pePoblacion', pePoblacion, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peZonaPostal', peZonaPostal, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'pePaisResidencia', pePaisResidencia, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peInscrita', peInscrita, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peFolio', peFolio, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peLibro', peLibro, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peUbicada', peUbicada, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peEdad', peEdad, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peEstadoCivil', peEstadoCivil, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peProfesion', peProfesion, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'peBandera', peBandera, 'IN');


    IF IdParte IN (4) THEN --SE MODIFICO PARA PERMITIR MAS DE UN OTORGANTE 18022011
        BEGIN
            FOR cursPartes_Rec IN cursPartes(IdTramite)
            LOOP
                IF cursPartes_Rec.ID_PARTE = IdParte THEN

                    psResult := 29;
                    RAISE Ex_Error;

                END IF;
            END LOOP;
        END;
    END IF;

    --Esta validacion no aplica
    --RUG.SP_VALIDA_RFC(peIdNacionalidad, peRFC, peTipoPersona, vlPsResultValRFC, vlPsTxtResultValRFC);

    --IF vlPsResultValRFC <> 0 THEN

    --psResult:= vlPsResultValRFC;
    --RAISE Ex_Error;

    --END IF;

    --Validaciones
    IF peTipoPersona = 'PF' THEN

        IF(peNombre is null
            OR
            TRIM(penombre) <> '') THEN

            psResult := 79;
            RAISE Ex_Error;

        END IF;

    END IF;

    IF peIdNacionalidad IS NOT NULL THEN

        SELECT
               COUNT(*)
        INTO   vlCountNacionalidad
        FROM
               RUG_CAT_NACIONALIDADES
        WHERE
               ID_NACIONALIDAD = peIdNacionalidad
        ;

        IF vlCountNacionalidad = 0 THEN

            psResult := 19;
            RAISE Ex_Error;

        END IF;

    ELSE

        psResult := 18;
        RAISE Ex_Error;

    END IF;


    vlIdDomicilio := SEQ_RUG_ID_DOMICILIO.NEXTVAL;

    --IF(peBDomicilio = 'V') THEN

        INSERT INTO RUG.RUG_DOMICILIOS_EXT
               (ID_DOMICILIO
                    , ID_PAIS_RESIDENCIA
                    , UBICA_DOMICILIO_1
                    , UBICA_DOMICILIO_2
                    , POBLACION
                    , ZONA_POSTAL
               )
               VALUES
               (vlIdDomicilio
                    , pePaisResidencia
                    , peDomicilioUno
                    , peDomicilioDos
                    , pePoblacion
                    , peZonaPostal
               )
        ;

    --END IF;

    vlIdPersona:= SEQ_RUG_ID_PERSONA.NEXTVAL;

    INSERT INTO RUG_PERSONAS
           (ID_PERSONA
                , RFC
                , ID_NACIONALIDAD
                , PER_JURIDICA
                , FH_REGISTRO
                , PROCEDENCIA
                , SIT_PERSONA
                , CVE_NACIONALIDAD
                , ID_DOMICILIO
                , FOLIO_MERCANTIL
                , FECHA_INSCR_CC
                , REG_TERMINADO
                , E_MAIL
                , CURP_DOC
                , NIFP
           )
           VALUES
           (vlIdPersona
                , peRFC
                , peIdNacionalidad
                , peTipoPersona
                , TRUNC(SYSDATE)
                , 'NAL'
                , 'AC'
                , NULL
                , vlIdDomicilio
                , peFolioMercantil
                , NULL
                , 'N'
                , peEmail
                , peCURP
                , peCURP
           )
    ;

    IF peTelefono IS NOT NULL THEN

        INSERT INTO RUG_TELEFONOS VALUES
               (vlIdPersona
                    , NULL
                    , peTelefono
                    , peExtension
                    , SYSDATE
                    , 'AC'
               )
        ;

    END IF;


    IF(UPPER(peTipoPersona) = 'PM') THEN

        IF(peRazonSocial is null
            OR
            TRIM (peRazonSocial)='' )THEN

            psResult := 77;
            RAISE Ex_Error;


        END IF;

        INSERT INTO RUG_PERSONAS_MORALES
               (ID_PERSONA
                    , RAZON_SOCIAL
					, NUM_INSCRITA
					, FOLIO
					, LIBRO
					, UBICADA
               )
               VALUES
               (vlIdPersona
                    , peRazonSocial
					, peInscrita
					, peFolio
					, peLibro
					, peUbicada
               )
        ;


    ELSIF (UPPER(peTipoPersona) = 'PF') THEN


        INSERT INTO RUG_PERSONAS_FISICAS
               (ID_PERSONA
                    , NOMBRE_PERSONA
                    , AP_PATERNO
                    , AP_MATERNO
                    , CURP
					, ESTADO_CIVIL
					, OCUPACION_ACTUAL
					, EDAD
               )
               VALUES
               (vlIdPersona
                    , peNombre
                    , peApellidoP
                    , peApellidoM
                    , peCURP
					, peEstadoCivil
					, peProfesion
					, peEdad
               )
        ;

    END IF;



    INSERT INTO RUG_REL_TRAM_INC_PARTES
           ( ID_TRAMITE_TEMP
                , ID_PERSONA
                , ID_PARTE
                , PER_JURIDICA
                , STATUS_REG
                , FECHA_REG
           )
           VALUES
           (IdTramite
                , vlIdPersona
                , IdParte
                , peTipoPersona
                , 'AC'
                , SYSDATE
           )
    ;

    COMMIT;


    psIdPersonaAlta := vlIdPersona;
    psResult        := 0;
    psTxResult      := RUG.FN_MENSAJE_ERROR(psResult);

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'psIdPersonaAlta', psIdPersonaAlta, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'psTxResult', psTxResult, 'OUT');


EXCEPTION

WHEN Ex_Error THEN
    psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'psIdPersonaAlta', psIdPersonaAlta, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'psTxResult', psTxResult, 'OUT');
    ROLLBACK;

WHEN Ex_CurpExistente THEN
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'psIdPersonaAlta', psIdPersonaAlta, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'psTxResult', psTxResult, 'OUT');
    ROLLBACK;

WHEN OTHERS THEN
    psResult  := 999;
    psTxResult:= substr(SQLCODE
    ||':'
    ||SQLERRM,1,250);
    ROLLBACK;
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'psIdPersonaAlta', psIdPersonaAlta, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte', 'psTxResult', psTxResult, 'OUT');
    DBMS_OUTPUT.PUT_LINE(psTxResult);
END SP_AltaParte;
/

