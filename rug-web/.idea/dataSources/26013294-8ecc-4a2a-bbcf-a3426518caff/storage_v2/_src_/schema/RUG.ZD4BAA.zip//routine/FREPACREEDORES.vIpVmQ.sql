create FUNCTION           FREPACREEDORES (Fecha Date) 
RETURN SYS_REFCURSOR
IS 
    vlRefCursor SYS_REFCURSOR; 
BEGIN

OPEN vlRefCursor FOR

SELECT ID_ACREEDOR,
       NOMBRE_ACREEDOR ,
       PER_JURIDICA,
       TIPO_PERFIL,
       DECODE(TIPO_PERFIL, 1, 'FEDATARIO', 2, 'ACREEDOR', 3 ,'CIUDADANO') DESC_TIPO_PERFIL,
       RFC_ACREEDOR
FROM ( select t1.id_acreedor,
              per.NOMBRE_ACREEDOR ,
              PER.per_juridica,
              t1.tipo_perfil,
              per.rfc_ACREEDOR
        FROM  (select /*+RULE*/ 
                      Min(id_acreedor) id_acreedor,
                      decode(ID_PERFIL, 4, 1,2,2, 1, 3 ) TIPO_PERFIL,
                      rfc_acreedor
               from V_REP_BASE_ACREEDORES
               WHERE regexp_substr(rfc_acreedor,  '^AAA[0|1]{6}') is null
               and rfc_acreedor is not null
               and trunc(FECHA_STATUS)<= Fecha
               group by rfc_acreedor, decode(ID_PERFIL, 4, 1,2,2, 1, 3 )
               ) T1,
               rug.V_REP_BASE_ACREEDORES per               
       WHERE T1.id_acreedor=per.id_acreedor

       UNION ALL
       SELECT min(ID_ACREEDOR) ID_ACREEDOR,
              TRIM(NOMBRE_ACREEDOR) NOMBRE_PERSONA,
              MAX(per_juridica) per_juridica,
              MIN(decode(ID_PERFIL, 4, 1,2,2, 1, 3 )) TIPO_PERFIL,        
              MAX(rfc_ACREEDOR) rfc_ACREEDOR
       FROM V_REP_BASE_ACREEDORES
       WHERE (regexp_substr(rfc_ACREEDOR,  '^AAA[0|1]{6}') IS NOT NULL
              or rfc_ACREEDOR is null)
              and TRUNC (FECHA_STATUS)<= Fecha
       group by trim(NOMBRE_ACREEDOR)
     );




  return vlRefCursor;     

   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       return NULL;
     WHEN OTHERS THEN
       return null;
END FRepAcreedores;
/

