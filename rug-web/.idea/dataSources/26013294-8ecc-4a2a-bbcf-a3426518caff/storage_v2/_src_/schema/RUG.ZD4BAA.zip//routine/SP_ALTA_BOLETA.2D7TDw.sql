create PROCEDURE               SP_Alta_Boleta (
                            peIdTramite         IN NUMBER,
                            peArchivo           IN  BLOB,
                            peIdPersona         IN NUMBER,
                            peIdKey             IN VARCHAR2,
                            psResult            OUT  INTEGER,
                            psTxResult          OUT  VARCHAR2 
)IS  
  vlIdArchivo     NUMBER;
  vlCantidad      NUMBER;
  vlResult        VARCHAR2(4000);
  Ex_ErrParametro EXCEPTION;

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Boleta', 'peIdTramite', peIdTramite, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Boleta', 'peIdPersona', peIdPersona, 'IN');   

    BEGIN

        vlCantidad := 0;

        SELECT COUNT(*)
          INTO vlCantidad
          FROM RUG_SECU_USUARIOS
         WHERE ID_PERSONA =  peIdPersona
           AND SIT_USUARIO = 'AC';           

        IF vlCantidad < 1 THEN
            vlResult := 'El usuario no esta registrado en el sistema';
            RAISE Ex_ErrParametro;
        END IF;

    END;       

    vlIdArchivo := SEQ_ARCHIVOPDF.NEXTVAL;


    BEGIN

        INSERT INTO RUG_BOLETA_PDF(ID_ARCHIVO, ID_TRAMITE, ID_PERSONA,  ARCHIVO, PDF_KEY, FECHA_REG, STATUS_REG)
        VALUES(vlIdArchivo, peIdTramite, peIdPersona, peArchivo, peIdKey, SYSDATE, 'AC');

    END;

    psResult   :=0;        
    psTxResult :='Alta finalizada satisfactoriamente';

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Boleta', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Boleta', 'psTxResult', psTxResult, 'OUT');


EXCEPTION 
    WHEN Ex_ErrParametro  THEN    
          psResult  := -1;     
          psTxResult:= vlResult;

        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Boleta', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Boleta', 'psTxResult', psTxResult, 'OUT');    


    WHEN OTHERS THEN
        psResult  := 999;   
        psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);

        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Boleta', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Boleta', 'psTxResult', psTxResult, 'OUT');    


END SP_Alta_Boleta;
/

