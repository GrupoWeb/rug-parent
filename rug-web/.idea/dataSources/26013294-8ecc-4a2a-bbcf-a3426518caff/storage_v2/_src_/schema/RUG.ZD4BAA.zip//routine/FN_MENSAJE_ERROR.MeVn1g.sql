create FUNCTION         FN_MENSAJE_ERROR ( peIdMensajeError IN RUG_CAT_MENSAJES_ERRORES.ID_CODIGO%TYPE
                                                   )
RETURN VARCHAR2 

IS

vlDescMensajeError  VARCHAR(4000);

BEGIN

    BEGIN

       SELECT DESC_CODIGO 
       INTO vlDescMensajeError
       FROM RUG_CAT_MENSAJES_ERRORES
       WHERE ID_CODIGO = peIdMensajeError;
    EXCEPTION
       WHEN NO_DATA_FOUND THEN
        vlDescMensajeError := 'CODIGO DE MENSAJE DE ERROR NO ENCONTRADO';
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_MENSAJE_ERROR', 'peIdMensajeError', peIdMensajeError, 'IN');
    END;

   RETURN vlDescMensajeError;

EXCEPTION
   WHEN OTHERS THEN
   vlDescMensajeError := SUBSTR(SQLCODE||'-'||SQLERRM,1,1000);   
   RETURN vlDescMensajeError;

END;
/

