create FUNCTION         FN_DESC_GARANTIA (
                                                   peIdGarantia     RUG_GARANTIAS.ID_GARANTIA%TYPE,
                                                   peLongitud       NUMBER --CANTIDAD  DE CARACTERES A DEVOLVER
                                                   )
RETURN VARCHAR2 

IS
    vlLongitudCadena number;
    vlDescError VARCHAR2(200);

    vlDescGarantia RUG_GARANTIAS.DESC_GARANTIA%TYPE;

BEGIN

	SELECT DISTINCT RGG.DESC_GARANTIA
	INTO vlDescGarantia
    FROM RUG_GARANTIAS RGG
    WHERE RGG.ID_GARANTIA = peIdGarantia;

	IF peLongitud <> 0 THEN

           vlLongitudCadena := LENGTH(vlDescGarantia);

           IF vlLongitudCadena > 85 THEN

           vlDescGarantia := SUBSTR(vlDescGarantia, 0, 85);
           vlDescGarantia := vlDescGarantia || '...';

           END IF;

       END IF;

        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'Desc_Garantia', 'vlDescGarantia', vlDescGarantia, 'OUT');

        RETURN vlDescGarantia;

	EXCEPTION 
        WHEN NO_DATA_FOUND THEN
            vlDescError := 'No se encontro el la garantia solicitada';            
            SP_LOG('DESC_BIEN_GARANTIA',14||' - '||SUBSTR(SQLCODE||'-'||SQLERRM,1,1000));

	    WHEN OTHERS THEN
            SP_LOG('DESC_BIEN_GARANTIA',SUBSTR(SQLCODE||'-'||SQLERRM,1,1000));
            RETURN NULL;

END;
/

