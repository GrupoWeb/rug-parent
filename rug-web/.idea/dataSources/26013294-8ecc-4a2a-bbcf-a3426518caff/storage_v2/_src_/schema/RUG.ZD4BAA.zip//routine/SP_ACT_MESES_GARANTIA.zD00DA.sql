create PROCEDURE           SP_ACT_MESES_GARANTIA 
( peIdTram      IN RUG_REL_TRAM_INC_GARAN.ID_TRAMITE_TEMP%TYPE,
  peIdGarantia  IN RUG_REL_TRAM_INC_GARAN.ID_GARANTIA_PEND%TYPE,
  peMeses       IN RUG_GARANTIAS.MESES_GARANTIA%TYPE,
  psResult      OUT    INTEGER,   
  psTxResult    OUT    VARCHAR2
 )
IS
 vIdGarantia RUG_REL_TRAM_INC_GARAN.ID_GARANTIA_PEND%TYPE;
 vlGarantiaStatus    CHAR(2);
 Ex_GarantiaCancelada  EXCEPTION;

BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ACT_MESES_GARANTIA', 'peIdTram', peIdTram, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ACT_MESES_GARANTIA', 'peIdGarantia', peIdGarantia, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ACT_MESES_GARANTIA', 'peMeses', peMeses, 'IN');

        BEGIN
            SELECT ID_GARANTIA_PEND
            INTO vIdGarantia
            FROM RUG_REL_TRAM_INC_GARAN
            WHERE ID_TRAMITE_TEMP = peIdTram
            AND   ID_GARANTIA_PEND = peIdGarantia;
            EXCEPTION
               WHEN NO_DATA_FOUND THEN
                 DBMS_OUTPUT.PUT_LINE('El tramite No existe');                
        END;

         BEGIN
       --VALIDO QUE LA GARANTIA NO ESTE CANCELADA
       SELECT GARANTIA_STATUS
       INTO vlGarantiaStatus
       FROM RUG_GARANTIAS
       WHERE ID_GARANTIA = peIdGarantia;

       IF vlGarantiaStatus IN ('CA', 'CR', 'CT') THEN
        RAISE Ex_GarantiaCancelada;
       END IF;
       END;

        IF vIdGarantia IS NOT NULL  THEN
           UPDATE RUG_GARANTIAS
           SET MESES_GARANTIA = peMeses
           WHERE ID_GARANTIA = vIdGarantia;        

        END IF;

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ACT_MESES_GARANTIA', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ACT_MESES_GARANTIA', 'psTxResult', psTxResult, 'OUT');        

    COMMIT;

EXCEPTION
WHEN Ex_GarantiaCancelada  THEN        
    psResult := 15;
    SELECT DESC_CODIGO
    INTO psTxResult
    FROM RUG_CAT_MENSAJES_ERRORES
    WHERE ID_CODIGO = psResult;          
   dbms_output.put_line(psTxResult);
   ROLLBACK;
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'psTxResult', psTxResult, 'OUT');

END;
/

