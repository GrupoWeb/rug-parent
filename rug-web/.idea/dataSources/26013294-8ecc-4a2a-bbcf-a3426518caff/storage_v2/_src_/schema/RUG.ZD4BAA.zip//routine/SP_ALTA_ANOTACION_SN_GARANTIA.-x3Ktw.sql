create PROCEDURE         SP_ALTA_ANOTACION_SN_GARANTIA 
                                            (
                                             peIdUsuario          IN  RUG_PERSONAS.ID_PERSONA%TYPE,
                                             peIdTramiteTemp      IN  TRAMITES_RUG_INCOMP.ID_TRAMITE_TEMP%TYPE,
                                             peAutoridadInstruye  IN  RUG_ANOTACIONES_SIN_GARANTIA.AUTORIDAD_AUTORIZA%TYPE,
                                             peAnotacion          IN  RUG_ANOTACIONES_SIN_GARANTIA.ANOTACION%TYPE,
                                             peVigenciaAnotacion  IN  RUG_ANOTACIONES_SIN_GARANTIA.VIGENCIA_ANOTACION%TYPE,
                                             psResult            OUT  INTEGER,   
                                             psTxResult          OUT  VARCHAR2       
                                            )
IS

vlIdAnotacion   NUMBER;
vlNumAnotaciones NUMBER;
vlIdPersonaAnotacion NUMBER;

Ex_Error EXCEPTION;


BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Anotacion_Sn_Garantia', 'peIdUsuario', peIdUsuario, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Anotacion_Sn_Garantia', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Anotacion_Sn_Garantia', 'peAutoridadInstruye', peAutoridadInstruye, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Anotacion_Sn_Garantia', 'peVigenciaAnotacion', peVigenciaAnotacion, 'IN');



    BEGIN
        SELECT ID_PERSONA 
        INTO vlIdPersonaAnotacion
        FROM RUG_REL_TRAM_INC_PARTES
        WHERE ID_TRAMITE_TEMP = peIdTramiteTemp
        AND ID_PARTE = 1 AND STATUS_REG = 'AC';
         exception when no_data_found then

             psResult   := 67;             
             RAISE Ex_Error;
    END;

    IF (peVigenciaAnotacion > 9999) THEN

        psResult := 74;
        RAISE Ex_Error;  

    END IF;

    IF (peAutoridadInstruye IS NULL OR peAutoridadInstruye = '') THEN

        psResult := 73;
        RAISE Ex_Error;  

    END IF;

    IF (peAnotacion IS NULL OR peAnotacion = '') THEN

        psResult := 82;
        RAISE Ex_Error;    

    END IF;



    IF vlIdPersonaAnotacion IS NOT NULL THEN

        SELECT COUNT(*)
        INTO vlNumAnotaciones
        FROM RUG_ANOTACIONES_SIN_GARANTIA
        WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;

        IF vlNumAnotaciones > 0 THEN

             psResult   := 68;             

             RAISE Ex_Error;

        ELSE    

            vlIdAnotacion := SEQ_ANOTACIONES_SIN_GARANTIA.NEXTVAL; 

            INSERT INTO RUG_ANOTACIONES_SIN_GARANTIA
            VALUES(vlIdAnotacion, peAutoridadInstruye, peAnotacion, vlIdPersonaAnotacion, NULL, 
                        SYSDATE, 'AC', peIdTramiteTemp, peIdUsuario, 'AC', peVigenciaAnotacion);     

        END IF;


    ELSE

        RAISE Ex_Error;

    END IF;

  psResult   :=0;        
  psTxResult :='Actualizacion finalizada satisfactoriamente';

  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Anotacion_Sn_Garantia', 'psResult', psResult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Anotacion_Sn_Garantia', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION 
  WHEN Ex_Error  THEN         
      rollback;
      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Anotacion_Sn_Garantia', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Anotacion_Sn_Garantia', 'psTxResult', psTxResult, 'OUT');    


   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Anotacion_Sn_Garantia', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Anotacion_Sn_Garantia', 'psTxResult', psTxResult, 'OUT');

END SP_Alta_Anotacion_Sn_Garantia;
/

