create view V_TRAMITES_INCOMP_PARTES as
SELECT
             RTP.ID_TRAMITE_TEMP ID_TRAMITE
           , RTP.ID_PERSONA
           , RTP.ID_PARTE
           , RGP.DESC_PARTE
           , RTP.PER_JURIDICA
           , DECODE ( RTP.PER_JURIDICA, 'PF', (
                    SELECT
                           NOMBRE_PERSONA
                                  || ' '
                                  || AP_PATERNO
                                  || ' '
                                  || AP_MATERNO
                    FROM
                           RUG_PERSONAS_FISICAS
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , 'PM', (
                    SELECT
                           RAZON_SOCIAL
                    FROM
                           RUG_PERSONAS_MORALES
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             ) AS NOMBRE
           , DECODE (RPP.PER_JURIDICA, 'PF', (
                    SELECT
                           NOMBRE_PERSONA
                    FROM
                           RUG_PERSONAS_FISICAS
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS NOMBRE_PERSONA
           , DECODE (RPP.PER_JURIDICA, 'PF', (
                    SELECT
                           AP_PATERNO
                    FROM
                           RUG_PERSONAS_FISICAS
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS AP_PATERNO_PERSONA
           , DECODE (RPP.PER_JURIDICA, 'PF', (
                    SELECT
                           AP_MATERNO
                    FROM
                           RUG_PERSONAS_FISICAS
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS AP_MATERNO_PERSONA
           , DECODE (RPP.PER_JURIDICA, 'PM', (
                    SELECT
                           RAZON_SOCIAL
                    FROM
                           RUG_PERSONAS_MORALES
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS RAZON_SOCIAL
           , RPP.FOLIO_MERCANTIL
           , RPP.RFC
           , RPP.NIFP AS CURP           
           , RPP.ID_DOMICILIO
           , VD.CALLE
           , VD.NUM_EXTERIOR
           , VD.NUM_INTERIOR
           , VD.ID_COLONIA
           , VD.CVE_COLONIA
           , VD.ID_LOCALIDAD
           , VD.CVE_LOCALIDAD
           , VD.CVE_DELEG_MUNICIP
           , VD.NOM_DELEG_MUNICIP
           , VD.CVE_ESTADO
           , VD.NOM_ESTADO
           , VD.CVE_PAIS
           , VD.NOM_PAIS
           , VD.CODIGO_POSTAL
           , RPP.ID_NACIONALIDAD
           , RCN.DESC_NACIONALIDAD
           , RPP.E_MAIL
           , RTT.TELEFONO
           , RTT.EXTENSION
           , RPP.CURP_DOC
           , VD.LOCALIDAD
           , VD.NOM_COLONIA
           , VD.ID_PAIS_RESIDENCIA
           , VD.UBICA_DOMICILIO_1
           , VD.UBICA_DOMICILIO_2
           , VD.POBLACION
           , VD.ZONA_POSTAL
           , DECODE (RPP.PER_JURIDICA, 'PM', (
                    SELECT
                           TIPO
                    FROM
                           RUG_PERSONAS_MORALES
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS TIPO_SOCIEDAD
           , DECODE (RPP.PER_JURIDICA, 'PM', (
                    SELECT
                           NUM_INSCRITA
                    FROM
                           RUG_PERSONAS_MORALES
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS NUM_INSCRITA
           , DECODE (RPP.PER_JURIDICA, 'PM', (
                    SELECT
                           FOLIO
                    FROM
                           RUG_PERSONAS_MORALES
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS FOLIO
           , DECODE (RPP.PER_JURIDICA, 'PM', (
                    SELECT
                           LIBRO
                    FROM
                           RUG_PERSONAS_MORALES
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS LIBRO
           , DECODE (RPP.PER_JURIDICA, 'PM', (
                    SELECT
                           UBICADA
                    FROM
                           RUG_PERSONAS_MORALES
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS UBICADA
           , DECODE (RPP.PER_JURIDICA, 'PF', (
                    SELECT
                           EDAD
                    FROM
                           RUG_PERSONAS_FISICAS
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS EDAD
           , DECODE (RPP.PER_JURIDICA, 'PF', (
                    SELECT
                           ESTADO_CIVIL
                    FROM
                           RUG_PERSONAS_FISICAS
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS ESTADO_CIVIL
           , DECODE (RPP.PER_JURIDICA, 'PF', (
                    SELECT
                           OCUPACION_ACTUAL
                    FROM
                           RUG_PERSONAS_FISICAS
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS OCUPACION_ACTUAL
  FROM
             RUG_REL_TRAM_INC_PARTES RTP
             INNER JOIN
                        RUG_PARTES RGP
                        ON
                                   RTP.ID_PARTE = RGP.ID_PARTE
             INNER JOIN
                        RUG_PERSONAS RPP
                        ON
                                   RTP.ID_PERSONA = RPP.ID_PERSONA
             LEFT JOIN
                        V_DOMICILIOS VD
                        ON
                                   VD.ID_DOMICILIO = RPP.ID_DOMICILIO
             LEFT JOIN
                        RUG_TELEFONOS RTT
                        ON
                                   RTP.ID_PERSONA = RTT.ID_PERSONA
             INNER JOIN
                        RUG_CAT_NACIONALIDADES RCN
                        ON
                                   RCN.ID_NACIONALIDAD = RPP.ID_NACIONALIDAD
  WHERE
             RTP.STATUS_REG = 'AC'
             AND RGP.ID_PARTE IN (3
                                , 4)
  UNION ALL
  SELECT
             RTP.ID_TRAMITE_TEMP ID_TRAMITE
           , RTP.ID_PERSONA
           , RTP.ID_PARTE
           , RGP.DESC_PARTE
           , RTP.PER_JURIDICA
           , DECODE ( RTP.PER_JURIDICA, 'PF', (
                    SELECT
                           NOMBRE_PERSONA
                                  || ' '
                                  || AP_PATERNO
                                  || ' '
                                  || AP_MATERNO
                    FROM
                           RUG_PERSONAS_FISICAS
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , 'PM', (
                    SELECT
                           RAZON_SOCIAL
                    FROM
                           RUG_PERSONAS_MORALES
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             ) AS NOMBRE
           , DECODE (RPP.PER_JURIDICA, 'PF', (
                    SELECT
                           NOMBRE_PERSONA
                    FROM
                           RUG_PERSONAS_FISICAS
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS NOMBRE_PERSONA
           , DECODE (RPP.PER_JURIDICA, 'PF', (
                    SELECT
                           AP_PATERNO
                    FROM
                           RUG_PERSONAS_FISICAS
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS AP_PATERNO_PERSONA
           , DECODE (RPP.PER_JURIDICA, 'PF', (
                    SELECT
                           AP_MATERNO
                    FROM
                           RUG_PERSONAS_FISICAS
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS AP_MATERNO_PERSONA
           , DECODE (RPP.PER_JURIDICA, 'PM', (
                    SELECT
                           RAZON_SOCIAL
                    FROM
                           RUG_PERSONAS_MORALES
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS RAZON_SOCIAL
           , RPP.FOLIO_MERCANTIL
           , RPP.RFC
           , RPP.NIFP AS CURP           
           , RPP.ID_DOMICILIO
           , VD.CALLE
           , VD.NUM_EXTERIOR
           , VD.NUM_INTERIOR
           , VD.ID_COLONIA
           , VD.CVE_COLONIA
           , VD.ID_LOCALIDAD
           , VD.CVE_LOCALIDAD
           , VD.CVE_DELEG_MUNICIP
           , VD.NOM_DELEG_MUNICIP
           , VD.CVE_ESTADO
           , VD.NOM_ESTADO
           , VD.CVE_PAIS
           , VD.NOM_PAIS
           , VD.CODIGO_POSTAL
           , RPP.ID_NACIONALIDAD
           , RCN.DESC_NACIONALIDAD
           , RPP.E_MAIL
           , RTT.TELEFONO
           , RTT.EXTENSION
           , RPP.CURP_DOC
           , VD.LOCALIDAD
           , VD.NOM_COLONIA
           , VD.ID_PAIS_RESIDENCIA
           , VD.UBICA_DOMICILIO_1
           , VD.UBICA_DOMICILIO_2
           , VD.POBLACION
           , VD.ZONA_POSTAL
           , DECODE (RPP.PER_JURIDICA, 'PM', (
                    SELECT
                           TIPO
                    FROM
                           RUG_PERSONAS_MORALES
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS TIPO_SOCIEDAD
           , DECODE (RPP.PER_JURIDICA, 'PM', (
                    SELECT
                           NUM_INSCRITA
                    FROM
                           RUG_PERSONAS_MORALES
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS NUM_INSCRITA
           , DECODE (RPP.PER_JURIDICA, 'PM', (
                    SELECT
                           FOLIO
                    FROM
                           RUG_PERSONAS_MORALES
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS FOLIO
           , DECODE (RPP.PER_JURIDICA, 'PM', (
                    SELECT
                           LIBRO
                    FROM
                           RUG_PERSONAS_MORALES
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS LIBRO
           , DECODE (RPP.PER_JURIDICA, 'PM', (
                    SELECT
                           UBICADA
                    FROM
                           RUG_PERSONAS_MORALES
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS UBICADA
           , DECODE (RPP.PER_JURIDICA, 'PF', (
                    SELECT
                           EDAD
                    FROM
                           RUG_PERSONAS_FISICAS
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS EDAD
           , DECODE (RPP.PER_JURIDICA, 'PF', (
                    SELECT
                           ESTADO_CIVIL
                    FROM
                           RUG_PERSONAS_FISICAS
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS ESTADO_CIVIL
           , DECODE (RPP.PER_JURIDICA, 'PF', (
                    SELECT
                           OCUPACION_ACTUAL
                    FROM
                           RUG_PERSONAS_FISICAS
                    WHERE
                           ID_PERSONA = RTP.ID_PERSONA
             )
             , NULL) AS OCUPACION_ACTUAL
  FROM
             RUG_REL_TRAM_INC_PARTES RTP
             INNER JOIN
                        RUG_PARTES RGP
                        ON
                                   RTP.ID_PARTE = RGP.ID_PARTE
             INNER JOIN
                        RUG_PERSONAS RPP
                        ON
                                   RTP.ID_PERSONA = RPP.ID_PERSONA
             LEFT JOIN
                        V_DOMICILIOS VD
                        ON
                                   VD.ID_DOMICILIO = RPP.ID_DOMICILIO
             LEFT JOIN
                        RUG_TELEFONOS RTT
                        ON
                                   RTP.ID_PERSONA = RTT.ID_PERSONA
             INNER JOIN
                        RUG_CAT_NACIONALIDADES RCN
                        ON
                                   RCN.ID_NACIONALIDAD = RPP.ID_NACIONALIDAD
  WHERE
             RTP.STATUS_REG = 'AC'
             AND RGP.ID_PARTE IN (1
                                , 2)
/

