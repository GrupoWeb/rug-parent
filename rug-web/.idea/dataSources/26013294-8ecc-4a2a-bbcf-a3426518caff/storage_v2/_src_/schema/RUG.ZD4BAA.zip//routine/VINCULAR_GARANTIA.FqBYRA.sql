create PROCEDURE     VINCULAR_GARANTIA(pNuevoSolicitante IN NUMBER, pNumGarantia IN NUMBER, pCausa IN VARCHAR2, pUsuario IN NUMBER) IS
	v_id_persona_original NUMBER;
	v_garantia_vinculada NUMBER;
	v_homologado_id NUMBER;
	v_id_tramite_ori NUMBER;
	v_id_persona_ori NUMBER;

	old_nombre_persona VARCHAR2(255);
	old_per_juridica VARCHAR2(2);
	old_id_nacionalidad NUMBER;
	old_rfc VARCHAR2(20);
	old_curp VARCHAR2(900);
	old_curp_doc VARCHAR2(500);
	old_cve_usuario VARCHAR2(256);
	old_cve_perfil VARCHAR2(20);

	CURSOR cur_tramites(id_garantia IN NUMBER)
	IS
		SELECT id_tramite, id_persona
		FROM tramites t
		WHERE EXISTS (
			SELECT 1
			FROM rug_rel_tram_garan rtg
			WHERE rtg.id_garantia = pNumGarantia
			AND rtg.id_tramite = t.id_tramite
		);
BEGIN
	-- obtener id_persona de usuario original
	SELECT id_garantia, id_persona
	INTO v_garantia_vinculada, v_id_persona_original
	FROM rug_garantias
	WHERE id_garantia = pNumGarantia;

	IF v_id_persona_original IS NOT NULL THEN
		-- obtener los datos de usuario original
		SELECT cve_perfil, cve_usuario INTO old_cve_perfil, old_cve_usuario FROM rug_secu_perfiles_usuario WHERE id_persona = v_id_persona_original;
		SELECT nombre_persona, curp INTO old_nombre_persona, old_curp FROM rug_personas_fisicas WHERE id_persona = v_id_persona_original;
		SELECT rfc, id_nacionalidad, per_juridica, curp_doc INTO old_rfc, old_id_nacionalidad, old_per_juridica, old_curp_doc FROM rug_personas WHERE id_persona = v_id_persona_original;
	END IF;

	-- registrar bitacora de la vinculacion
	v_homologado_id := SEQ_HOMOLOGADO.NEXTVAL;
	INSERT INTO RUG.HOMOLOGADO(HOMOLOGADO_ID, ID_PERSONA_MIGRACION, ID_PERSONA_RUG, CAUSA, FECHA, ID_GARANTIA, USUARIO_ID)
	VALUES(v_homologado_id, v_id_persona_original, pNuevoSolicitante, pCausa, SYSDATE, pNumGarantia, pUsuario);

	-- registrar bitacora de tramites originales
	FOR tramite_rec IN cur_tramites(pNumGarantia)
		LOOP
			INSERT INTO RUG.HOMOLOGADO_TRAMITE(HOMOLOGADO_ID, ID_TRAMITE, ID_PERSONA)
			VALUES(v_homologado_id, tramite_rec.id_tramite, tramite_rec.id_persona);
		END LOOP;


	UPDATE rug_garantias SET id_persona = pNuevoSolicitante WHERE id_garantia = pNumGarantia;

	UPDATE rug_rel_garantia_partes SET id_persona = pNuevoSolicitante WHERE id_garantia = pNumGarantia AND id_parte = 4;

	UPDATE rug_garantias_pendientes SET id_persona = pNuevoSolicitante WHERE num_garantia = pNumGarantia;

	UPDATE rug_garantias_h SET id_persona = pNuevoSolicitante WHERE id_garantia = pNumGarantia;

	UPDATE tramites_rug_incomp SET id_persona = pNuevoSolicitante WHERE id_tramite_temp = (
		SELECT id_ultimo_tramite
		FROM rug_garantias
		WHERE id_garantia = pNumGarantia
	);

	UPDATE tramites t SET t.id_persona = pNuevoSolicitante WHERE EXISTS (
		SELECT 1
		FROM rug_rel_tram_garan rtg
		WHERE rtg.id_garantia = pNumGarantia
		AND rtg.id_tramite = t.id_tramite
	);

	UPDATE rug_boleta_pdf SET id_persona = pNuevoSolicitante WHERE id_tramite = (
		SELECT id_ultimo_tramite
		FROM rug_garantias
		WHERE id_garantia = pNumGarantia
	);

	UPDATE rug_contrato c SET id_usuario = pNuevoSolicitante WHERE EXISTS (
		SELECT 1
		FROM rug_garantias_pendientes gp
		WHERE gp.num_garantia = pNumGarantia
		AND gp.id_garantia_pend = c.id_garantia_pend
	);

	UPDATE rug_rel_tram_inc_partes tip SET id_persona = pNuevoSolicitante WHERE EXISTS (
		SELECT 1
		FROM tramites_rug_incomp t
		WHERE id_tramite_temp = (
			SELECT id_ultimo_tramite
			FROM rug_garantias
			WHERE id_garantia = pNumGarantia
		)
		AND t.id_tramite_temp = tip.id_tramite_temp
	)
	AND tip.id_parte = 4;

	UPDATE rug_rel_tram_partes tp SET id_persona = pNuevoSolicitante WHERE EXISTS (
		SELECT 1
		FROM tramites t
		WHERE EXISTS (
			SELECT 1
			FROM rug_rel_tram_garan rtg
			WHERE rtg.id_garantia = pNumGarantia
			AND rtg.id_tramite = t.id_tramite
		)
		AND t.id_tramite = tp.id_tramite
	)
	AND id_parte = 4;

	UPDATE rug_personas_h ph
	SET id_persona = pNuevoSolicitante/*,
		nombre_persona = old_nombre_persona,
		per_juridica = old_per_juridica,
		id_nacionalidad = old_id_nacionalidad,
		rfc = old_rfc,
		curp = old_curp,
		curp_doc = old_curp_doc,
		e_mail = old_cve_usuario,
		cve_perfil = old_cve_perfil*/
	WHERE EXISTS (
		SELECT 1
		FROM tramites t
		WHERE EXISTS (
			SELECT 1
			FROM rug_rel_tram_garan rtg
			WHERE rtg.id_garantia = pNumGarantia
			AND rtg.id_tramite = t.id_tramite
		)
		AND t.id_tramite = ph.id_tramite
	)
	AND id_parte = 4
	AND id_persona = v_id_persona_original;

	UPDATE rug_firma_doctos fd SET id_usuario_firmo = pNuevoSolicitante WHERE EXISTS (
		SELECT 1
		FROM tramites_rug_incomp t
		WHERE id_tramite_temp = (
			SELECT id_ultimo_tramite
			FROM rug_garantias
			WHERE id_garantia = pNumGarantia
		)
		AND t.id_tramite_temp = fd.id_tramite_temp
	);

	COMMIT;
EXCEPTION
	WHEN NO_DATA_FOUND THEN
		RAISE_APPLICATION_ERROR(-20301, 'La garantía no está asociada al usuario ingresado.');
END;
/

