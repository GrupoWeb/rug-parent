create view V_ANOTACION_CON_GARANTIA_FIRMA as
SELECT   RA.ID_TRAMITE_TEMP,
            RA.ID_ANOTACION,
            RA.ANOTACION,
            RA.AUTORIDAD_AUTORIZA,
            RG.VIGENCIA,
            RG.ID_TIPO_GARANTIA,
            RCTG.DESC_TIPO_GARANTIA,
            RG.FECHA_REG,
            RG.MONTO_MAXIMO_GARANTIZADO,
            RG.OTROS_TERMINOS_GARANTIA,
            RG.TIPOS_BIENES_MUEBLES,
            RG.DESC_GARANTIA DESC_BIENES_MUEBLES,
            RG.UBICACION_BIENES,
            RG.FECHA_INSCR FECHA_CELEB_ACTO,
            RP.ID_PERSONA,
            RP.RFC,
            RP.FOLIO_MERCANTIL,
            RP.ID_DOMICILIO,
            RP.PER_JURIDICA,
            DECODE (
               RP.PER_JURIDICA,
               'PF',
               (SELECT      F.NOMBRE_PERSONA
                         || ' '
                         || F.AP_PATERNO
                         || ' '
                         || F.AP_MATERNO
                  FROM   RUG_PERSONAS_FISICAS F
                 WHERE   F.ID_PERSONA = RP.ID_PERSONA),
               'PM',
               (SELECT   M.RAZON_SOCIAL
                  FROM   RUG_PERSONAS_MORALES M
                 WHERE   M.ID_PERSONA = RP.ID_PERSONA)
            )
               NOMBRE,
            RRTP.ID_PARTE,
            RPAR.DESC_PARTE,
            RG.ID_MONEDA,
            RCM.DESC_MONEDA
     FROM   RUG_ANOTACIONES RA,
            RUG_REL_TRAM_GARAN RRTG,
            RUG_GARANTIAS RG,
            RUG_REL_TRAM_PARTES RRTP,
            RUG_PERSONAS RP,
            RUG_PARTES RPAR,
            RUG_CAT_TIPO_GARANTIA RCTG,
            TRAMITES_RUG_INCOMP TRI,
            RUG_CAT_MONEDAS RCM
    WHERE       RCTG.ID_TIPO_GARANTIA = RG.ID_TIPO_GARANTIA
            AND RCM.ID_MONEDA = RG.ID_MONEDA
            AND RPAR.ID_PARTE = RRTP.ID_PARTE
            AND RP.ID_PERSONA = RRTP.ID_PERSONA
            AND RRTP.ID_TRAMITE = RRTG.ID_TRAMITE
            AND RRTG.ID_GARANTIA = RA.ID_GARANTIA
            AND RG.ID_GARANTIA = RA.ID_GARANTIA
            AND TRI.ID_TRAMITE_TEMP = RA.ID_TRAMITE_TEMP
            AND TRI.ID_STATUS_TRAM = 5
/

