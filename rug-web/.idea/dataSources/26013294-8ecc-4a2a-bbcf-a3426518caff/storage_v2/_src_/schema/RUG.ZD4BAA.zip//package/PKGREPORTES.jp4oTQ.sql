create PACKAGE           PKGREPORTES AS
/******************************************************************************
  NAME:       PKGREPORTES
  PURPOSE:    GUARDAR INFORMACIÓN RELATIVA DE LOS REPORTES
  REVISIONS:
  Ver        Date        Author           Description
  ---------  ----------  ---------------  ------------------------------------
  1.0        14/Abr/2011             1. Created this package.
******************************************************************************/
   TYPE t_Palabras IS
      TABLE OF VARCHAR2 (2000)
         INDEX BY BINARY_INTEGER;

   vgBanderaMensajes VARCHAR2(1):='F';

   coVerdadero  CONSTANT VARCHAR2(1):='V';

/* procedimiento temporal para validar informacion */
PROCEDURE  spRegistro (peCadena  in RUG_REP_CONSULTAS.TX_CONSULTA%TYPE);

/******************************************************************************
   NAME:       SPLITCadena
   PURPOSE:    Procedimiento que separa una cadena de acuerdo al caracter enviado
               y regresa un arreglo dinamico
******************************************************************************/
FUNCTION SPLITCadena(peCADENA   IN VARCHAR2,
                     peCaracter IN varchar2)
 RETURN t_Palabras;

--*******************************************************************************************************************************
--*Nombre:   funObtenTC    Función para obtener el TC de una moneda y día solicitado
--*Creado:   Alicia Maya    Fecha Elaboracion: 19/Abr/2011
--*******************************************************************************************************************************
Function funObtenTC (peMoneda in rug_rep_tipos_cambio.id_moneda%type,
                     peFecha  in varchar2) --rug_rep_tipos_cambio.f_cambio%type)
return rug_rep_tipos_cambio.TIPO_CAMBIO%type;


--*******************************************************************************************************************************
--*Nombre:   spProcesaTC    Procedimiento que inserta la informacion en RUG_TIPOS_CAMBIOS
--*Creado:   Alicia Maya    Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
PROCEDURE spProcesaTC( peTiposCambio    IN   VARCHAR2,
                       peFCambio        IN   VARCHAR2, --RUG_REP_TIPOS_CAMBIO.F_CAMBIO%TYPE,
                       peUsuario        IN   RUG_REP_TIPOS_CAMBIO.ULT_USU_REG%TYPE,
                       peBcommit        IN   VARCHAR2,
                       psResult         OUT  INTEGER,
                       psTxResult       OUT  VARCHAR2);


--*******************************************************************************************************************************
--*Nombre:   spDBMS         Procedimiento que utiliza el dbms_output
--*Creado:   Alicia Maya    Fecha Elaboracion: 18/Abr/2011
--*******************************************************************************************************************************
PROCEDURE spDBMS(peMensaje    IN   CLOB);


--*******************************************************************************************************************************
--*Nombre:   funObtenQuery  devolver el query base para los reportes
--*Creado:   Alicia Maya    Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION funObtenQuery( peIdConsulta    IN   RUG_REP_CONSULTAS.ID_CONSULTA%type)
RETURN   RUG_REP_CONSULTAS.TX_CONSULTA%type;



--*******************************************************************************************************************************
--*Nombre:   funObtenParam  devolver el valor del parametro
--*Creado:   Alicia Maya    Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION funObtenParam(peCveParametro    IN   RUG_REP_PARAM.CVE_PARAMETRO%type)
RETURN   RUG_REP_PARAM.TX_PARAMETRO%type;


--*******************************************************************************************************************************
--*Nombre:   FCapTipoCambios  Devuelve los tipos de cambio que se necesitan para los reporte a una fecha dada 
--*Creado:   Alicia Maya      Fecha Elaboracion: 06/May/2011
--*******************************************************************************************************************************
FUNCTION FCapTipoCambios  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR; 


--*******************************************************************************************************************************
--*Nombre:   FRevTipoCambios  Revisa que los tipos de cambio que se necesitan para los reporte a una fecha dada estén capturados
--*Creado:   Alicia Maya      Fecha Elaboracion: 06/May/2011
--*******************************************************************************************************************************
FUNCTION FRevTipoCambios(peFecha IN VARCHAR2) 
RETURN NUMBER;


--*******************************************************************************************************************************
--*Nombre:   FRepTipoBien  devuelve los datos del Reporte de garantías por tipo de bien
--*Creado:   Alicia Maya   Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepTipoBien(peFecha  IN VARCHAR2) 
RETURN SYS_REFCURSOR; 



--*******************************************************************************************************************************
--*Nombre:   FRepRugEstado  devuelve los datos del Reporte de monto garantizado por Estado
--*Creado:   Alicia Maya    Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepRugEstado(peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR; 



--*******************************************************************************************************************************
--*Nombre:   FRepTotalXAcreedor  devuelve los montos garantizados por Acreedor
--*Creado:   Alicia Maya    Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepTotalXAcreedor(peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR; 



--*******************************************************************************************************************************
--*Nombre:   FRepInsXUsuXMes  devuelve las inscripcones por usuarios x mes
--*Creado:   Alicia Maya      Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepInsXUsuXMes  (peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR; 



--*******************************************************************************************************************************
--*Nombre:   FRepCifrasTotal  Devuelve los datos del Reporte de cifras totales de los montos garantizados por moneda
--*Creado:   Alicia Maya      Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepCifrasTotal  (peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR; 



--*******************************************************************************************************************************
--*Nombre:   FRepDesgGarant   Devuelve el Desglose de las garantias
--*Creado:   Alicia Maya      Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepDesgGarant  (peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR; 


--*******************************************************************************************************************************
--*Nombre:   FRepGtiasAum     Devuelve los datos de las garantias que aumentaron en el mes solicitado
--*Creado:   Alicia Maya      Fecha Elaboracion: 14/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepGtiasAum  (peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR; 


--*******************************************************************************************************************************
--*Nombre:   FRepGtiasDis      Devuelve los datos de las garantias que se reportaron el mes anterior y no en el mes solicitado
--*Creado:   Alicia Maya      Fecha Elaboracion: 15/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepGtiasDis  (peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR; 


--*******************************************************************************************************************************
--*Nombre:   FRepAnalisisDif  Devuelve el analisis de las diferencias de un mes respecto del anterior
--*Creado:   Alicia Maya      Fecha Elaboracion: 15/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepAnalisisDif  (peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR; 

--*******************************************************************************************************************************
--*Nombre:   FRepCifRelevantes  Devuelve las cifras relevantes de las garantias
--*Creado:   Alicia Maya        Fecha Elaboracion: 15/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepCifRelevantes  (peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR; 

--*******************************************************************************************************************************
--*Nombre:   FRepOtorgantes   Devuelve los datos del Reporte de OTORGANTES
--*Creado:   Alicia Maya      Fecha Elaboracion: 18/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepOtorgantes  (peFecha  IN    VARCHAR2) 
RETURN SYS_REFCURSOR; 


--*******************************************************************************************************************************
--*Nombre:   FRepTotOtorgantes   Devuelve los datos Totales del Reporte de OTORGANTES
--*Creado:   Alicia Maya      Fecha Elaboracion: 18/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepTotOtorgantes  (peFecha  IN    VARCHAR2) 
RETURN SYS_REFCURSOR; 


--*******************************************************************************************************************************
--*Nombre:   FRepGtiasExc     Devuelve los datos de las garantías excluidas en el mes solicitado
--*Creado:   Alicia Maya      Fecha Elaboracion: 18/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepGtiasExc  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR; 


--*******************************************************************************************************************************
--*Nombre:   FRepSegAcreedores      Devuelve los datos de los acreedores, incluye RFC y Personalidad juridica 
--*Creado:   Alicia Maya            Fecha Elaboracion: 19/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepSegAcreedores  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR; 


--*******************************************************************************************************************************
--*Nombre:   FRepGtiasMontoTope      Devuelve los datos de las garantías que exceden 1 mdd
--*Creado:   Alicia Maya      Fecha Elaboracion: 19/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepGtiasMontoTope  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR; 


--*******************************************************************************************************************************
--*Nombre:   FRepGrafXDia     devuelve la información para las graficas por día
--*Creado:   Alicia Maya      Fecha Elaboracion: 25/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepGrafXDia  (peFecha   IN   VARCHAR2) 
RETURN SYS_REFCURSOR; 


--*******************************************************************************************************************************
--*Nombre:   FRepAcredores    Devuelve los datos de los acreedores registrados hasta el momento sin importar la garantia
--*Creado:   Alicia Maya      Fecha Elaboracion: 25/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepAcredores  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR; 

--*******************************************************************************************************************************
--*Nombre:   FRepAcreeTot     Devuelve el resumen del Reporte de ACreedores
--*Creado:   Alicia Maya      Fecha Elaboracion: 17/May/2011
--*******************************************************************************************************************************
FUNCTION FRepAcreeTot  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR; 


--*******************************************************************************************************************************
--*Nombre:   FRepTotXUsu      Devuelve los totales por usuario a una fecha solicitada
--*Creado:   Alicia Maya      Fecha Elaboracion: 25/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepTotXUsu  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR; 


--*******************************************************************************************************************************
--*Nombre:   FRepTotXUsuXAcre   Devuelve los datos del Reporte Seguimiento RUG Usuarios y Acreedores
--*Creado:   Alicia Maya        Fecha Elaboracion: /Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepTotXUsuXAcre  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR; 


--*******************************************************************************************************************************
--*Nombre:   FRepInsDiarias   Devuelve los datos del Reporte de inscripciones diarias
--*Creado:   Alicia Maya      Fecha Elaboracion: 27/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepInsDiarias  (peFechaI  IN  VARCHAR2,
                          peFechaF  IN  VARCHAR2) 
RETURN SYS_REFCURSOR; 

--*******************************************************************************************************************************
--*Nombre:   FRepGrafMen      Devuelve los datos del REPORTE GRAFICO SALDO MENSUAL
--*Creado:   Alicia Maya      Fecha Elaboracion: 27/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepGrafMen  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR; 


--*******************************************************************************************************************************
--*Nombre:   FRepTotAcre      Devuelve los datos del Reporte de trámites por Acreedor
--*Creado:   Alicia Maya      Fecha Elaboracion: 29/Abr/2011
--*******************************************************************************************************************************
FUNCTION FRepTotAcre  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR;

--*******************************************************************************************************************************
--*Nombre:   FRepUsuGpo       Devuelve los datos del Reporte inscripciones por usuario con grupo de usuario
--*Creado:   Alicia Maya      Fecha Elaboracion: 18/May/2011
--*******************************************************************************************************************************
FUNCTION FRepUsuGpo  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR; 


--*******************************************************************************************************************************
--*Nombre:   FRepDiario       Devuelve los datos del Reporte Estadísticos Diario del RUG
--*Creado:   Alicia Maya      Fecha Elaboracion: 03/May/2011
--*******************************************************************************************************************************
FUNCTION FRepDiario  (peFecha  IN  VARCHAR2) 
RETURN SYS_REFCURSOR; 

--*******************************************************************************************************************************
--*Nombre:   FRepTotXTipoGar   Devuelve el Reporte de Total por Tipo de Garantia
--*Creado:   Alicia Maya      Fecha Elaboracion: 25/May/2011
--*******************************************************************************************************************************
FUNCTION FRepTotXTipoGar  (peFecha  IN    VARCHAR2) 
RETURN SYS_REFCURSOR;

--*******************************************************************************************************************************
--*Nombre:   funObtTotGar     Devuelve el total de garantías del periodo
--*Creado:   Alicia Maya      Fecha Elaboracion: 11/May/2011
--*******************************************************************************************************************************
FUNCTION funObtTotGar(peFecha  IN  VARCHAR2)
RETURN   NUMBER;

--*******************************************************************************************************************************
--*Nombre:   funObtTipFed     Devuelve el tipo de Fedatario del portal a partir de la clave del usuario
--*Creado:   Alicia Maya      Fecha Elaboracion: 24/May/2011
--*******************************************************************************************************************************
FUNCTION funObtTipFed(peCveUsuario  IN  INFRA.secu_usuarios.cve_usuario%type)
RETURN   varchar2;

--*******************************************************************************************************************************
--*Nombre:   FRepGaraInsXFechaInscr          Devuelve el Reporte de Total de garantias por Fecha de Inscripcion
--*Creado:   Alicia Maya / Gabriela Quevedo  Fecha Elaboracion: 30/May/2011
--*******************************************************************************************************************************
FUNCTION FRepGaraInsXFechaInscr  (peFecha  IN    VARCHAR2) 
RETURN SYS_REFCURSOR;

--*******************************************************************************************************************************
--*Nombre:   FRepGaraInsXFCelebCto           Devuelve el Reporte de Total de garantias por Fecha de celebración de contrato
--*Creado:   Alicia Maya / Gabriela Quevedo  Fecha Elaboracion: 30/May/2011
--*******************************************************************************************************************************
FUNCTION FRepGaraInsXFCelebCto  (peFecha  IN    VARCHAR2) 
RETURN SYS_REFCURSOR;


--*******************************************************************************************************************************
--*Nombre:   FRepUniversoUsuarios         Devuelve el Reporte de universo de usuarios tomado del RUG y complementado de tuempresa
--*Creado:   Alicia Maya 03 nov 2011
--*******************************************************************************************************************************
FUNCTION FRepUniversoUsuarios  (peFecha  IN    VARCHAR2) 
RETURN SYS_REFCURSOR;



--*******************************************************************************************************************************
--*Nombre:   funObtTotGarRango Total de Garantais por rango de fechas
--*Creado:   Gabriela Quevedo      Fecha Elaboracion: 05/07/2011
--*******************************************************************************************************************************

FUNCTION funObtTotGarRango(peFechaI  IN  Date,
                           peFechaF  IN  Date)
RETURN   NUMBER;
--*******************************************************************************************************************************
--*Nombre:   funObtTotMontoRango Devuelve el total del monto  garantizado en pesos de una ranto de fecha determinada
--*Creado:   Gabriela Quevedo      Fecha Elaboracion: 05/07/2011
--*******************************************************************************************************************************

FUNCTION funObtTotMontoRango(peFechaI  IN  Date,
                           peFechaF  IN  Date)
RETURN   NUMBER;
--*******************************************************************************************************************************
--*Nombre:   funObtTotRango Devuelve el total de acreedores, usuarios, inscripciones y garantias vigentes en un rango de fechas
--*Creado:   Gabriela Quevedo      Fecha Elaboracion: 05/07/2011
--*******************************************************************************************************************************

FUNCTION funObtTotRango(peFechaI  IN  Date,
                        peFechaF  IN  Date)
RETURN SYS_REFCURSOR;
--*******************************************************************************************************************************
--*Nombre:   FNREPESTCOMPRUG Devuelve los datos del reporte 
--*Creado:   Gabriela Quevedo      Fecha Elaboracion: 05/07/2011
--*******************************************************************************************************************************

FUNCTION FNREPESTCOMPRUG(fcorte date) 
RETURN SYS_REFCURSOR;


END PKGREPORTES;
/

