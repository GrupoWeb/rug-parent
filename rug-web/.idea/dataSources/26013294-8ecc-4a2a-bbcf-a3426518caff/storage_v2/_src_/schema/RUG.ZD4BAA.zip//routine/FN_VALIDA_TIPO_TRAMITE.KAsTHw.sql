create FUNCTION         FN_VALIDA_TIPO_TRAMITE ( idTramiteTemporal RUG.RUG_ANOTACIONES_SEG_INC_CSG.ID_ANOTACION_TEMP%TYPE
                                                       ,idTipoTramite     RUG.TRAMITES_RUG_INCOMP.ID_TIPO_TRAMITE%TYPE )
    RETURN BOOLEAN
IS

    T_TRAM      RUG.TRAMITES_RUG_INCOMP.ID_TIPO_TRAMITE%TYPE;
    VALIDO      BOOLEAN;

BEGIN

    VALIDO := TRUE;

    -- Obtener el id de tramite temporal --
    SELECT ID_TIPO_TRAMITE
      INTO T_TRAM
      FROM RUG.TRAMITES_RUG_INCOMP
     WHERE ID_TRAMITE_TEMP = idTramiteTemporal;

    -- Comparar con el id recibido por la funcion --
    IF T_TRAM <> idTipoTramite THEN

       VALIDO := FALSE;

    END IF;

    RETURN VALIDO;

END;
/

