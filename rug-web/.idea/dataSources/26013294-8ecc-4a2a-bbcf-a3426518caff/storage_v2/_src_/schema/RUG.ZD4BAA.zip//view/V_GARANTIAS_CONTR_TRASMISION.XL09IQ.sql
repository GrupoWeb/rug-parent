create view V_GARANTIAS_CONTR_TRASMISION as
SELECT   A.ID_GARANTIA,
            A.ID_TIPO_GARANTIA,
            A.TIPO_GARANTIA,
            A.FECHA_CELEB_ACTO,
            A.MONTO_LIMITE,
            A.OTROS_TERMINOS_GARANTIA,
            A.DESC_BIENES_MUEBLES,
            A.TIPO_CONTRATO,
            A.FECHA_CELEB_CONTRATO,
            A.OTROS_TERMINOS_CONTRATO,
            A.VIGENCIA,
            A.RELACION_BIEN,
            A.ID_TIPO_BIEN,
            A.DESC_TIPO_BIEN,
            A.ID_TRAMITE_TEMP,
            A.ID_MONEDA,
            RCM.DESC_MONEDA
     FROM   V_GARANTIA_CONTR_BASICO A,
            TRAMITES_RUG_INCOMP B,
            RUG_CAT_MONEDAS RCM
    WHERE       A.ID_TRAMITE_TEMP = B.ID_TRAMITE_TEMP
            AND RCM.ID_MONEDA = A.ID_MONEDA
            AND B.ID_TIPO_TRAMITE = 8                         /* TRASMISION */
            AND B.ID_STATUS_TRAM <> 3
/

