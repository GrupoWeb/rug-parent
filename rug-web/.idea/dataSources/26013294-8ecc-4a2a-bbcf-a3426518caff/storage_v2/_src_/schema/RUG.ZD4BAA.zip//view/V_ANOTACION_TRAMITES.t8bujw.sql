create view V_ANOTACION_TRAMITES as
SELECT T."ID_TRAMITE",T."ID_TRAMITE_TEMP",T."ID_ANOTACION_PADRE",T."ID_ANOTACION",T."ID_GARANTIA",T."ID_TIPO_TRAMITE",T."DESCRIPCION",T."ID_STATUS_TRAM",T."DESCRIP_STATUS",T."ID_USUARIO",T."USUARIO",T."ID_PERSONA",T."PER_JURIDICA",T."FOLIO_MERCANTIL",T."RFC",T."CURP",T."ID_NACIONALIDAD",T."NOMBRE_PERSONA",T."AP_PATERNO",T."AP_MATERNO",T."RAZON_SOCIAL",T."AUTORIDAD_AUTORIZA",T."ANOTACION",T."RESOLUCION",T."VIGENCIA_ANOTACION",T."SOLICITANTE_RECTIFICA",T."FECHA_STATUS",T."FECHA_INSCRIPCION"
      FROM  
         ( SELECT   T.ID_TRAMITE,
                    R.ID_ANOTACION_TEMP AS ID_TRAMITE_TEMP,
                    R.ID_TRAMITE_PADRE AS ID_ANOTACION_PADRE,
                    R.ID_ANOTACION_TEMP AS ID_ANOTACION,
                    R.ID_GARANTIA,
                    TI.ID_TIPO_TRAMITE,
                    FN_BORRA_SIN_CON_GARANTIA(TT.DESCRIPCION) AS DESCRIPCION,
                    TI.ID_STATUS_TRAM,
                    ST.DESCRIP_STATUS,
                    USU.ID_PERSONA AS ID_USUARIO,
                    PF.NOMBRE_PERSONA || ' ' || PF.AP_PATERNO || ' ' || PF.AP_MATERNO  AS USUARIO,
                    PA.ID_PERSONA ID_PERSONA,
                    PA.PER_JURIDICA,
                    PP.FOLIO_MERCANTIL,
                    PP.RFC,
                    PFA.CURP,
                    PP.ID_NACIONALIDAD,
                    PFA.NOMBRE_PERSONA,
                    PFA.AP_PATERNO,
                    PFA.AP_MATERNO,
                    PM.RAZON_SOCIAL,
                    R.AUTORIDAD_AUTORIZA,
                    R.ANOTACION,
                    R.RESOLUCION,
                    R.VIGENCIA AS VIGENCIA_ANOTACION,
                    R.SOLICITANTE_RECTIFICA,
                    TO_CHAR(H.FECHA_REG, 'DD/mm/YYYY') AS FECHA_STATUS,
                    TO_CHAR(BT.FECHA_REG, 'DD/mm/YYYY') AS FECHA_INSCRIPCION
             FROM   RUG_ANOTACIONES_SEG_INC_CSG R
            INNER JOIN RUG.TRAMITES_RUG_INCOMP TI
               ON   TI.ID_TRAMITE_TEMP = R.ID_ANOTACION_TEMP
            INNER JOIN RUG.RUG_REL_TRAM_INC_PARTES USU
               ON   USU.ID_TRAMITE_TEMP = R.ID_ANOTACION_TEMP
              AND   USU.ID_PARTE = 5
            INNER JOIN RUG.RUG_PERSONAS_FISICAS PF
               ON   PF.ID_PERSONA = USU.ID_PERSONA
             LEFT JOIN RUG.RUG_REL_TRAM_INC_PARTES PA
               ON   PA.ID_TRAMITE_TEMP = R.ID_ANOTACION_TEMP
              AND   PA.ID_PARTE = 1
             LEFT JOIN RUG.RUG_PERSONAS PP
               ON   PP.ID_PERSONA = PA.ID_PERSONA
             LEFT JOIN RUG.RUG_PERSONAS_FISICAS PFA
               ON   PFA.ID_PERSONA = PA.ID_PERSONA
             LEFT JOIN RUG.RUG_PERSONAS_MORALES PM
               ON   PM.ID_PERSONA = PA.ID_PERSONA
            INNER JOIN RUG.RUG_CAT_TIPO_TRAMITE TT
               ON   TT.ID_TIPO_TRAMITE = TI.ID_TIPO_TRAMITE
            INNER JOIN RUG.STATUS_TRAMITE ST
               ON   ST.ID_STATUS_TRAM = TI.ID_STATUS_TRAM
             LEFT JOIN RUG.TRAMITES T
               ON   T.ID_TRAMITE_TEMP = R.ID_ANOTACION_TEMP 
            INNER JOIN (SELECT MAX(HIS.FECHA_REG) AS FECHA_REG, HIS.ID_ANOTACION_TEMP
                          FROM RUG.RUG_ANOTACIONES_SEG_INC_CSG_H HIS
                         GROUP BY HIS.ID_ANOTACION_TEMP) H
               ON   H.ID_ANOTACION_TEMP = R.ID_ANOTACION_TEMP
            INNER JOIN RUG.RUG_BITAC_TRAMITES BT
               ON   BT.ID_TRAMITE_TEMP = R.ID_ANOTACION_TEMP
              AND   BT.ID_STATUS = 0
            WHERE   TI.ID_TIPO_TRAMITE IN (26, 27, 28, 29
                                          ,22, 23, 24, 25) -- GGR   07/05/13   MMSECN2013-82
              AND   R.STATUS_REG = 'AC' 
           UNION ALL
           SELECT   T.ID_TRAMITE,
                    NULL AS ID_TRAMITE_TEMP,
                    NULL AS ID_ANOTACION_PADRE,
                    NULL AS ID_ANOTACION,
                    NULL AS ID_GARANTIA,
                    T.ID_TIPO_TRAMITE,
                    FN_BORRA_SIN_CON_GARANTIA(TT.DESCRIPCION) AS DESCRIPCION,
                    T.ID_STATUS_TRAM,
                    ST.DESCRIP_STATUS,
                    T.ID_PERSONA AS ID_USUARIO,
                    PF.NOMBRE_PERSONA || ' ' || PF.AP_PATERNO || ' ' || PF.AP_MATERNO  AS USUARIO,
                    PA.ID_PERSONA,
                    PA.PER_JURIDICA,
                    PP.FOLIO_MERCANTIL,
                    PP.RFC,
                    PFA.CURP,
                    PP.ID_NACIONALIDAD,
                    PFA.NOMBRE_PERSONA,
                    PFA.AP_PATERNO,
                    PFA.AP_MATERNO,
                    PM.RAZON_SOCIAL,
                    R.AUTORIDAD_AUTORIZA,
                    R.ANOTACION,
                    NULL AS RESOLUCION,
                    R.VIGENCIA_ANOTACION,
                    NULL AS SOLICITANTE_RECTIFICA,
                    TO_CHAR(T.FECHA_STATUS, 'DD/mm/YYYY') AS FECHA_STATUS,
                    TO_CHAR(BT.FECHA_REG, 'DD/mm/YYYY') AS FECHA_INSCRIPCION
             FROM   TRAMITES T
            INNER JOIN TRAMITES_RUG_INCOMP TI
               ON   TI.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
            INNER JOIN RUG.RUG_ANOTACIONES_SIN_GARANTIA R
               ON   R.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
             LEFT JOIN RUG.RUG_PERSONAS_FISICAS PF
               ON   PF.ID_PERSONA = T.ID_PERSONA
             LEFT JOIN RUG.RUG_REL_TRAM_PARTES PA
               ON   PA.ID_TRAMITE = T.ID_TRAMITE
              AND   PA.ID_PARTE = 1
             LEFT JOIN RUG.RUG_PERSONAS PP
               ON   PP.ID_PERSONA = PA.ID_PERSONA
             LEFT JOIN RUG.RUG_PERSONAS_FISICAS PFA
               ON   PFA.ID_PERSONA = PA.ID_PERSONA
             LEFT JOIN RUG.RUG_PERSONAS_MORALES PM
               ON   PM.ID_PERSONA = PA.ID_PERSONA
            INNER JOIN RUG.RUG_BITAC_TRAMITES BT
               ON   BT.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP 
              AND   BT.ID_STATUS = 0
            INNER JOIN RUG.RUG_CAT_TIPO_TRAMITE TT
               ON   TT.ID_TIPO_TRAMITE = T.ID_TIPO_TRAMITE
            INNER JOIN RUG.STATUS_TRAMITE ST
               ON   ST.ID_STATUS_TRAM = T.ID_STATUS_TRAM
            WHERE   T.ID_TIPO_TRAMITE = 10
              AND   T.STATUS_REG = 'AC'
           UNION ALL
           SELECT   T.ID_TRAMITE,
                    NULL AS ID_TRAMITE_TEMP,
                    NULL AS ID_ANOTACION_PADRE,
                    NULL AS ID_ANOTACION,
                    R.ID_GARANTIA AS ID_GARANTIA,
                    T.ID_TIPO_TRAMITE,
                    FN_BORRA_SIN_CON_GARANTIA(TT.DESCRIPCION) AS DESCRIPCION,
                    T.ID_STATUS_TRAM,
                    ST.DESCRIP_STATUS,
                    T.ID_PERSONA AS ID_USUARIO,
                    PF.NOMBRE_PERSONA || ' ' || PF.AP_PATERNO || ' ' || PF.AP_MATERNO  AS USUARIO,
                    PA.ID_PERSONA,
                    PA.PER_JURIDICA,
                    PP.FOLIO_MERCANTIL,
                    PP.RFC,
                    PFA.CURP,
                    PP.ID_NACIONALIDAD,
                    PFA.NOMBRE_PERSONA,
                    PFA.AP_PATERNO,
                    PFA.AP_MATERNO,
                    PM.RAZON_SOCIAL,
                    R.AUTORIDAD_AUTORIZA,
                    R.ANOTACION,
                    NULL AS RESOLUCION,
                    R.VIGENCIA_ANOTACION,
                    NULL AS SOLICITANTE_RECTIFICA,
                    TO_CHAR(T.FECHA_STATUS, 'DD/mm/YYYY') AS FECHA_STATUS,
                    TO_CHAR(BT.FECHA_REG, 'DD/mm/YYYY') AS FECHA_INSCRIPCION
             FROM   TRAMITES T
            INNER JOIN TRAMITES_RUG_INCOMP TI
               ON   TI.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
            INNER JOIN RUG.RUG_ANOTACIONES R
               ON   R.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP
             LEFT JOIN RUG.RUG_PERSONAS_FISICAS PF
               ON   PF.ID_PERSONA = T.ID_PERSONA
             LEFT JOIN RUG.RUG_REL_TRAM_PARTES PA
               ON   PA.ID_TRAMITE = T.ID_TRAMITE
              AND   PA.ID_PARTE = 1
             LEFT JOIN RUG.RUG_PERSONAS PP
               ON   PP.ID_PERSONA = PA.ID_PERSONA
             LEFT JOIN RUG.RUG_PERSONAS_FISICAS PFA
               ON   PFA.ID_PERSONA = PA.ID_PERSONA
             LEFT JOIN RUG.RUG_PERSONAS_MORALES PM
               ON   PM.ID_PERSONA = PA.ID_PERSONA
            INNER JOIN RUG.RUG_BITAC_TRAMITES BT
               ON   BT.ID_TRAMITE_TEMP = T.ID_TRAMITE_TEMP 
              AND   BT.ID_STATUS = 0
            INNER JOIN RUG.RUG_CAT_TIPO_TRAMITE TT
               ON   TT.ID_TIPO_TRAMITE = T.ID_TIPO_TRAMITE
            INNER JOIN RUG.STATUS_TRAMITE ST
               ON   ST.ID_STATUS_TRAM = T.ID_STATUS_TRAM
            WHERE   T.ID_TIPO_TRAMITE = 2
              AND   T.STATUS_REG = 'AC'
        ) T
   ORDER BY T.ID_TRAMITE_TEMP DESC
/

