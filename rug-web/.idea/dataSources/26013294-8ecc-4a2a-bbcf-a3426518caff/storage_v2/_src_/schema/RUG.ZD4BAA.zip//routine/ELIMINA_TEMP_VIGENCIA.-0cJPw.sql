create PROCEDURE           ELIMINA_TEMP_VIGENCIA
AS
    
    
    CURSOR  CTRAMITES IS
        SELECT
               ID_TRAMITE
        FROM
               TRAMITES
        WHERE
               ID_TIPO_TRAMITE = 21
               AND STATUS_REG  = 'AC'
        ;

    VLTRAMITE       NUMBER;
    VLULTIMOTRAMITE NUMBER;
    VLGARANTIA      NUMBER;
    psTxResult      VARCHAR2(4000);

BEGIN

    OPEN CTRAMITES;
    LOOP

        FETCH CTRAMITES
        INTO  VLTRAMITE
        ;

        EXIT WHEN CTRAMITES%NOTFOUND;

        SELECT
               ID_GARANTIA
        INTO   VLGARANTIA
        FROM
               RUG_REL_TRAM_GARAN
        WHERE
               ID_TRAMITE = VLTRAMITE
        ;

        SELECT
               MAX(ID_ULTIMO_TRAMITE)
        INTO   VLULTIMOTRAMITE
        FROM
               RUG_GARANTIAS_H
        WHERE
               ID_GARANTIA         = VLGARANTIA
               AND GARANTIA_STATUS = 'AC'
        ;


        UPDATE
               RUG_GARANTIAS gar
        SET
               (
                      ID_RELACION
                    , GARANTIA_STATUS
                    , ID_ULTIMO_TRAMITE
                    , FECHA_REG
                    , ID_GARANTIA_PEND
               )
               =
               (
                      SELECT
                             t1.ID_RELACION       col1
                           , t1.GARANTIA_STATUS   col2
                           , t1.ID_ULTIMO_TRAMITE col3
                           , t1.FECHA_REG         col5
                           , t1.ID_GARANTIA_PEND  col6
                      FROM
                             RUG_GARANTIAS_H t1
                      WHERE
                             ID_GARANTIA           = VLGARANTIA
                             AND ID_ULTIMO_TRAMITE = VLULTIMOTRAMITE
               )
        WHERE
               gar.ID_GARANTIA = VLGARANTIA
        ;


        DELETE
               RUG_GARANTIAS_H
        WHERE
               ID_GARANTIA         = VLGARANTIA
               AND GARANTIA_STATUS = 'FV'
        ;

        DELETE
               RUG_REL_TRAM_GARAN
        WHERE
               ID_GARANTIA    = VLGARANTIA
               AND ID_TRAMITE = VLTRAMITE
        ;

        UPDATE
               TRAMITES
        SET    STATUS_REG = 'IN'
        WHERE
               ID_TRAMITE = VLTRAMITE
        ;

    END LOOP;

    CLOSE CTRAMITES;

    COMMIT;

EXCEPTION

WHEN OTHERS THEN
    psTxResult:= substr(SQLCODE
    ||':'
    ||SQLERRM,1,250);
    dbms_output.put_line(psTxResult);
    ROLLBACK;
END;
/

