create PROCEDURE         SP_MODIFICA_GARANTIA 
( 
    peIdTramiteTemp          IN  RUG_REL_TRAM_INC_GARAN.ID_TRAMITE_TEMP%TYPE,  --1  IDENTIFICADOR DEL TRAMITE ASOCIADO A LA GARANTIA
    peIdGarantia             IN  RUG_GARANTIAS_PENDIENTES.ID_GARANTIA_PEND%TYPE,    --2  IDENTIFICADOR DE LA GARANTIA
    peIdTipoGarantia         IN  RUG_GARANTIAS_PENDIENTES.ID_TIPO_GARANTIA%TYPE,  --3 IDENTIFICADOR DEL TIPO DE GARANTIA QUE SE INSCRIBE
    peFechaCelebGarantia     IN  RUG_GARANTIAS_PENDIENTES.FECHA_INSCR %TYPE, --4 Fecha de celebracion del Acto o Contrato, que crea la garantia
    peCambiosBienesMonto     IN  RUG_GARANTIAS_PENDIENTES.CAMBIOS_BIENES_MONTO%TYPE, --5  El Acto o Contrato preve incrementos, reducciones o sustituciones de los bienes muebles o del monto garantizado 
    peIdPerson               IN  RUG_PERSONAS.ID_PERSONA%TYPE, --6   IDENTIFICADOR DE LA PERSONA QUE  HACE LA INSCRIPCION
    peTipoBien               IN  VARCHAR2,  --7 CADENA QUE CONTIENE LOS IDS TIPOS DE BIENES QUE INTEGRA UNA GARANTIA, SEPARADOS POR EL CARACTER |   
    peDescGarantia           IN  RUG_GARANTIAS_PENDIENTES.DESC_GARANTIA%TYPE, --8 Descripci?e los Bienes Muebles objeto de la Garant?Mobiliaria:
    peTipoContratoOb         IN  RUG_CONTRATO.TIPO_CONTRATO%TYPE, --9 Acto o Contrato que crea la Obligaci?arantizada:
    peFechaCelebContOb       IN  RUG_CONTRATO.FECHA_INICIO%TYPE, --10 Fecha de celebraci?el Acto o Contrato: 
    peOtrosTerminosCOb       IN  RUG_CONTRATO.OTROS_TERMINOS_CONTRATO%TYPE, --11 T?inos y Condiciones de la Obligaci?arantizada
    peMontoMaxGarantizado    IN  RUG_GARANTIAS_PENDIENTES.MONTO_MAXIMO_GARANTIZADO%TYPE, --12 Monto M?mo Garantizado
    peOtrosTerminosG         IN  RUG_GARANTIAS_PENDIENTES.OTROS_TERMINOS_GARANTIA%TYPE, --13 T?inos y Condiciones del Acto o Contrato
    peTipoContratoBasa       IN  RUG_CONTRATO.TIPO_CONTRATO%TYPE,  --14 TIPO DE ACTO O CONTRATO EN QUE SE BASA LA MODIFICACION O RECTIFICACION POR ERROR
                                                                   -- Acto o Convenio que da origen a la Modificaci?    
    peFechaCelebBasa         IN  RUG_CONTRATO.FECHA_FIN%TYPE, -- FECHA DE CELEBRACION DEL ACTO O CONVENIO EN QUE SE BASA LA MODIFICACION
    peOtrosTerminosBasa      IN  RUG_CONTRATO.OTROS_TERMINOS_CONTRATO%TYPE, --OTROS TERMINOS Y CONDICIONES DEL ACTO O CONVENIO EN QUE SE BASA LA MODIFICACION, 
                                                                            --"Acto o Convenio que da origen a la Modificaci??inos y Condiciones del Acto o Convenio:"
    peIdMoneda               IN  RUG_CAT_MONEDAS.ID_MONEDA%TYPE, -- Tipo de moneda:
    peFechaFinBasa           IN  RUG_CONTRATO.FECHA_FIN%TYPE, -- Fecha de terminaci?el Acto o Convenio:
    peInstrumentoPublico     IN  RUG_GARANTIAS_PENDIENTES.INSTRUMENTO_PUBLICO%TYPE, -- Datos del Instrumento P?co mediante el cu?se formaliz? Acto o Contrato:
    peFechaFinOb             IN  RUG_CONTRATO.FECHA_FIN%TYPE, -- Fecha de terminaci?el Acto o Contrato:
    peGarantiaPrioritaria    IN RUG_GARANTIAS_PENDIENTES.ES_PRIORITARIA%TYPE, --21
    peOtrosRegistros         IN RUG_GARANTIAS_PENDIENTES.OTROS_REGISTROS%TYPE,--22
    peTxtRegistos            IN RUG_GARANTIAS_PENDIENTES.TXT_REGISTROS%TYPE,--23
    peNoGarantiaPreviaOt     IN RUG_GARANTIAS_PENDIENTES.NO_GARANTIA_PREVIA_OT%TYPE, --24
    psResult                 OUT  INTEGER,   
    psTxResult               OUT  VARCHAR2
)
IS

vIdTram     NUMBER;
vlIdTipoTram    NUMBER;
vIdRegistro NUMBER;
vlRelacion  NUMBER;
vlIdGarantiaPend NUMBER;
vlIdGarantiaPendMod NUMBER;
vlIdGarantiaPendNva NUMBER;
contador number;
vlGarantiaStatus    CHAR(2);
vlGaranTransPend    NUMBER;
vlFechaInicioObAnterior DATE;

vlTipoBien INSTITUCIONAL.PKGSE_COMUN.T_PALABRAS;
vlIdTipoBien VARCHAR2(5);

RegGarantias    RUG_GARANTIAS%ROWTYPE;
RegGarantiasPend RUG_GARANTIAS_PENDIENTES%ROWTYPE;

Ex_Error  EXCEPTION;

fk_exception  EXCEPTION;
PRAGMA EXCEPTION_INIT (fk_exception, -02291);


BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peIdTramiteTemp', CAST(peIdTramiteTemp AS VARCHAR2), 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peIdGarantia', CAST(peIdGarantia AS VARCHAR2), 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peIdTipoGarantia', CAST(peIdTipoGarantia AS VARCHAR2), 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peFechaCelebGarantia', CAST(peFechaCelebGarantia AS VARCHAR2), 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peCambiosBienesMonto', peCambiosBienesMonto, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peIdPerson', CAST(peIdPerson AS VARCHAR2), 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peTipoBien', peTipoBien, 'IN');
--REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peDescGarantia', peDescGarantia, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peTipoContratoOb', peTipoContratoOb, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peFechaCelebContOb', CAST(peFechaCelebContOb AS VARCHAR2), 'IN');
--REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peOtrosTerminosCOb', peOtrosTerminosCOb,'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peMontoMaxGarantizado', peMontoMaxGarantizado ,'IN');
--REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peOtrosTerminosG', peOtrosTerminosG,'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peTipoContratoBasa', peTipoContratoBasa, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peFechaCelebBasa', CAST(peFechaCelebBasa AS VARCHAR2), 'IN');
--REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peOtrosTerminosBasa', peOtrosTerminosBasa, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peIdMoneda', peIdMoneda, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peFechaFinBasa', peFechaFinBasa, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peInstrumentoPublico', peInstrumentoPublico, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peFechaFinOb', peFechaFinOb, 'IN');

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peGarantiaPrioritaria', peGarantiaPrioritaria, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peOtrosRegistros', peOtrosRegistros, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'peTxtRegistos', peTxtRegistos, 'IN');

       BEGIN
         SELECT ID_TRAMITE_TEMP, ID_TIPO_TRAMITE
         INTO vIdTram, vlIdTipoTram
         FROM TRAMITES_RUG_INCOMP
         WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;

         IF vlIdTipoTram NOT IN (6,7,8) THEN
            psResult := 13;
            RAISE Ex_Error;
         END IF;

        Exception 
          WHEN NO_DATA_FOUND THEN
             dbms_output.put_line('No Existe el Tramite a Relacionar'|| vIdTram);             
       END;      


       BEGIN
       --VALIDO QUE LA GARANTIA NO ESTE CANCELADA
       SELECT GARANTIA_STATUS
       INTO vlGarantiaStatus
       FROM RUG_GARANTIAS
       WHERE ID_GARANTIA = peIdGarantia;

       IF vlGarantiaStatus IN ('CA', 'CR', 'CT') THEN
          psResult := 15;
          RAISE Ex_Error;
       END IF;
       END;


      IF vIdTram IS NOT NULL THEN  

        vlIdGarantiaPend := SEQ_GARANTIAS_TEMP.NEXTVAL;

        SELECT ID_TIPO_GARANTIA, DESC_GARANTIA, OTROS_TERMINOS_GARANTIA, FECHA_INSCR,
               MONTO_MAXIMO_GARANTIZADO, ID_MONEDA, INSTRUMENTO_PUBLICO, CAMBIOS_BIENES_MONTO, VIGENCIA, ID_GARANTIA_PEND,
               ES_PRIORITARIA, OTROS_REGISTROS, TXT_REGISTROS, NO_GARANTIA_PREVIA_OT
        INTO RegGarantias.ID_TIPO_GARANTIA, RegGarantias.DESC_GARANTIA, RegGarantias.OTROS_TERMINOS_GARANTIA, RegGarantias.FECHA_INSCR,
             RegGarantias.MONTO_MAXIMO_GARANTIZADO, RegGarantias.ID_MONEDA, RegGarantias.INSTRUMENTO_PUBLICO, RegGarantias.CAMBIOS_BIENES_MONTO,
             RegGarantias.VIGENCIA, RegGarantias.ID_GARANTIA_PEND, RegGarantias.ES_PRIORITARIA, RegGarantias.OTROS_REGISTROS, 
             RegGarantias.TXT_REGISTROS, RegGarantias.NO_GARANTIA_PREVIA_OT
        FROM RUG_GARANTIAS
        WHERE ID_GARANTIA = peIdGarantia; 

        IF vlIdTipoTram = 7 THEN --MODIFICACION

            INSERT INTO RUG_GARANTIAS_PENDIENTES
            VALUES(vlIdGarantiaPend, RegGarantias.ID_TIPO_GARANTIA, NULL, NVL(peDescGarantia,RegGarantias.DESC_GARANTIA), NULL, peIdPerson, 
            NULL, NULL, vlRelacion, NULL, NULL, NULL, NULL, NULL, NVL(peOtrosTerminosG,RegGarantias.OTROS_TERMINOS_GARANTIA), RegGarantias.FECHA_INSCR, 
            NULL, RegGarantias.VIGENCIA, NULL, 'AC', peIdTramiteTemp, NULL, NVL(peMontoMaxGarantizado,RegGarantias.MONTO_MAXIMO_GARANTIZADO), peIdGarantia, 
            NVL(peCambiosBienesMonto,RegGarantias.CAMBIOS_BIENES_MONTO), NVL(peInstrumentoPublico,RegGarantias.INSTRUMENTO_PUBLICO), NVL(peIdMoneda,RegGarantias.ID_MONEDA),
            NVL(peNoGarantiaPreviaOt,RegGarantias.NO_GARANTIA_PREVIA_OT), NVL(peGarantiaPrioritaria,RegGarantias.ES_PRIORITARIA),
            NVL(peOtrosRegistros,RegGarantias.OTROS_REGISTROS), NVL(peTxtRegistos,RegGarantias.TXT_REGISTROS));

            IF peTipoBien IS NOT NULL THEN

--                SELECT RELACION_BIEN + 1
--                INTO vlRelacion
--                FROM( 
--                    SELECT RELACION_BIEN
--                    FROM RUG_REL_GAR_TIPO_BIEN
--                    WHERE RELACION_BIEN IS NOT NULL
--                    ORDER BY 1 DESC    
--                    )
--                WHERE ROWNUM = 1;  

                vlRelacion := RUG.SEQ_BIENES.NEXTVAL;                

                vlTipoBien := INSTITUCIONAL.PKGSE_COMUN.SPLITCADENA('1|','|'); 

                FOR i IN 1..vlTipoBien.count loop

                  BEGIN

                    vlIdTipoBien := vlTipoBien(i-1);    
                    INSERT INTO RUG_REL_GAR_TIPO_BIEN
                    VALUES(vlIdGarantiaPend, vlIdTipoBien, vlRelacion);

                     EXCEPTION
                    WHEN fk_exception THEN
                        BEGIN
                          psResult := 61;
                          RAISE Ex_Error;
                        END;    
                    dbms_output.put_line(vlTipoBien(i - 1));    
                    END;

                END LOOP;

            ELSE

                INSERT INTO RUG_REL_GAR_TIPO_BIEN
                SELECT vlIdGarantiaPend, C.ID_TIPO_BIEN, vlRelacion
                  FROM RUG_GARANTIAS_PENDIENTES A, 
                       RUG_GARANTIAS B,
                       RUG_REL_GAR_TIPO_BIEN C
                WHERE  C.RELACION_BIEN = B.RELACION_BIEN
                AND B.ID_GARANTIA = A.ID_GARANTIA_MODIFICAR
                AND A.ID_ULTIMO_TRAMITE = peIdTramiteTemp;


            END IF;


            UPDATE RUG_GARANTIAS_PENDIENTES
            SET RELACION_BIEN = vlRelacion
            WHERE ID_GARANTIA_PEND = vlIdGarantiaPend;

              SELECT FECHA_INICIO
            INTO vlFechaInicioObAnterior
            FROM   RUG_CONTRATO
            WHERE   ID_GARANTIA_PEND = RegGarantias.ID_GARANTIA_PEND
            AND CLASIF_CONTRATO = 'OB';

            /*
            --INSERTO EL CONTRATO DE LA OBLIGACION QUE NO SE MUEVE PARA ESTA GARANTIA MODIFICADA
            INSERT INTO RUG_CONTRATO(ID_CONTRATO, ID_GARANTIA_PEND, FECHA_INICIO, FECHA_FIN,  TIPO_CONTRATO, OTROS_TERMINOS_CONTRATO, 
                                     ID_TRAMITE_TEMP, FECHA_REG, STATUS_REG, ID_USUARIO, CLASIF_CONTRATO) 
            VALUES(SEQ_CONTRATO.NEXTVAL, vlIdGarantiaPend, vlFechaInicioObAnterior, peFechaFinOb, peTipoContratoOb, peOtrosTerminosCOb, peIdTramiteTemp,
                   SYSDATE, 'AC', peIdPerson, 'OB');
             */

            --INSERTO EL CONTRATO DE LA OBLIGACION QUE NO SE MUEVE PARA ESTA GARANTIA MODIFICADA                   
            INSERT INTO RUG_CONTRATO(ID_CONTRATO, ID_GARANTIA_PEND, FECHA_INICIO, FECHA_FIN,  TIPO_CONTRATO, OTROS_TERMINOS_CONTRATO, 
                                     ID_TRAMITE_TEMP, FECHA_REG, STATUS_REG, ID_USUARIO, CLASIF_CONTRATO, OBSERVACIONES)
            SELECT SEQ_CONTRATO.NEXTVAL, vlIdGarantiaPend, vlFechaInicioObAnterior, NVL(peFechaFinOb,FECHA_FIN), NVL(peTipoContratoOb,TIPO_CONTRATO), 
                   NVL(peOtrosTerminosCOb,OTROS_TERMINOS_CONTRATO), peIdTramiteTemp, SYSDATE, 'AC', peIdPerson, 'OB', NVL(peOtrosTerminosBasa,OBSERVACIONES)
            FROM   RUG_CONTRATO
            WHERE   ID_GARANTIA_PEND = RegGarantias.ID_GARANTIA_PEND
            AND CLASIF_CONTRATO = 'OB';             


            --INSERTO EL CONTRATO EN QUE SE BASA LA MODIFICACION
            INSERT INTO RUG.RUG_CONTRATO
            VALUES(SEQ_CONTRATO.NEXTVAL, vlIdGarantiaPend, NULL, peFechaCelebBasa, peFechaFinBasa,  peOtrosTerminosCOb, NULL, peOtrosTerminosBasa, peTipoContratoBasa, peIdTramiteTemp, SYSDATE, 'AC', peIdPerson, 'FU');

            --INSERTO LA RELACION GARANTIA - TRAMITE PENDIENTES 
            INSERT INTO RUG_REL_TRAM_INC_GARAN
            VALUES(vlIdGarantiaPend, peIdTramiteTemp, 'AC', SYSDATE);


        ELSIF vlIdTipoTram = 6 THEN -- RECTIFICACION POR ERROR

            INSERT INTO RUG_GARANTIAS_PENDIENTES
            VALUES(vlIdGarantiaPend, peIdTipoGarantia, NULL, peDescGarantia, NULL, peIdPerson, 
            NULL, NULL, vlRelacion, NULL, NULL, NULL, NULL, NULL, peOtrosTerminosG, peFechaCelebGarantia, 
            NULL, RegGarantias.VIGENCIA, NULL, 'AC', peIdTramiteTemp, NULL, peMontoMaxGarantizado, peIdGarantia, peCambiosBienesMonto, peInstrumentoPublico, peIdMoneda,NULL,
            NULL, NULL, NULL);


            --INSERTO EL CONTRATO QUE CREA LA OBLIGACION GARANTIZADA
            INSERT INTO RUG.RUG_CONTRATO
            VALUES (SEQ_CONTRATO.NEXTVAL, vlIdGarantiaPend, NULL, peFechaCelebContOb, peFechaFinOb, peOtrosTerminosCOb, NULL, NULL, peTipoContratoOb, peIdTramiteTemp, SYSDATE, 'AC', peIdPerson, 'OB');


             --INSERTO LA RELACION GARANTIA - TRAMITE PENDIENTES 
            INSERT INTO RUG_REL_TRAM_INC_GARAN
            VALUES(vlIdGarantiaPend, peIdTramiteTemp, 'AC', SYSDATE);



        ELSIF vlIdTipoTram = 8 THEN

        -- SE COMENTO POR QUE LA TRANSMISO EN SU  PROCESO NORMAL DUPLICABA LA INSERCION DE GARANTIAS PENDIENTES
--            INSERT INTO RUG_GARANTIAS_PENDIENTES(ID_GARANTIA_PEND, ID_PERSONA, ID_ULTIMO_TRAMITE, ID_GARANTIA_MODIFICAR)
--            VALUES(vlIdGarantiaPend, peIdPerson, peIdTramiteTemp, peIdGarantia);


            SELECT ID_GARANTIA_PEND
            INTO vlGaranTransPend
            FROM RUG_REL_TRAM_INC_GARAN
            WHERE ID_TRAMITE_TEMP = peIdTramiteTemp;

            SELECT RELACION_BIEN
              INTO vlRelacion
              FROM RUG_GARANTIAS
             WHERE ID_GARANTIA = peIdGarantia;

            UPDATE RUG_GARANTIAS_PENDIENTES
            SET RELACION_BIEN = vlRelacion
            WHERE ID_GARANTIA_PEND = vlGaranTransPend;



            /* INI EEE 2017-10-03. 
            INSERTAR en RUG_REL_GAR_TIPO_BIEN 
            Transmisi?e garantias
            */

            SELECT 
                id_garantia_modificar
                into vlIdGarantiaPendNva
            FROM rug_garantias_pendientes
            WHERE id_ultimo_tramite=peIdTramiteTemp;

            SELECT 
            id_garantia_pend
            INTO vlIdGarantiaPendMod
            FROM rug_garantias
            WHERE id_garantia=vlIdGarantiaPendNva;

            INSERT INTO RUG_REL_GAR_TIPO_BIEN
                SELECT 
                distinct(vlGaranTransPend), reltipobien.id_tipo_bien, vlRelacion
                FROM RUG_REL_GAR_TIPO_BIEN reltipobien
                WHERE ID_GARANTIA_PEND = vlIdGarantiaPendMod
                and id_tipo_bien is not null;

            /* FIN EEE 2017-10-03. INSERTAR en RUG_REL_GAR_TIPO_BIEN */

            --INSERTO EL CONTRATO EN QUE SE BASA LA MODIFICACION
            INSERT INTO RUG.RUG_CONTRATO
            VALUES(SEQ_CONTRATO.NEXTVAL, vlGaranTransPend, NULL, peFechaCelebBasa, peFechaFinBasa,  peOtrosTerminosBasa, NULL, NULL, peTipoContratoBasa, peIdTramiteTemp, SYSDATE, 'AC', peIdPerson, 'FU');   

        END IF;


        contador :=0;

        COMMIT;

        psResult := 0; 
        psTxResult := 'ACTUALIZACION EXITOSA';                   
      END IF;

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'psTxResult', psTxResult, 'OUT');    

EXCEPTION 
WHEN Ex_Error  THEN         
    psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
    ROLLBACK;
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'psTxResult', psTxResult, 'OUT');    

WHEN OTHERS THEN
    psResult  := 999;   
    psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);  
    dbms_output.put_line(psTxResult);
    ROLLBACK;
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA', 'psTxResult', psTxResult, 'OUT');    

END ;
/

