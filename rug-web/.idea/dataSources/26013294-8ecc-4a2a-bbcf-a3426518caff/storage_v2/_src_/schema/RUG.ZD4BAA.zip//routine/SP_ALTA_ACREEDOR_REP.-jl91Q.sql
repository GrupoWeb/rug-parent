create PROCEDURE         SP_ALTA_ACREEDOR_REP                            (
                                peIdUsuario          IN  NUMBER,
                                peTipoPersona        IN  VARCHAR2,
                                IdTipo               IN  VARCHAR2, -- Sociedad Mercantil 'SM' o Otros 'OT'
                                peRazonSocial        IN  VARCHAR2,
                                peRFC                IN  VARCHAR2,
                                peCURP               IN  VARCHAR2,
                                peFolioMercantil     IN  VARCHAR2,
                                peCalle              IN  VARCHAR2,
                                peNumExt             IN  VARCHAR2,
                                peNumInt             IN  VARCHAR2,
                                peNombre             IN  VARCHAR2,
                                peApellidoP          IN  VARCHAR2,
                                peApellidoM          IN  VARCHAR2,
                                peIdColonia          IN  NUMBER,           
                                peIdLocalidad        IN  NUMBER,
                                peIdNacionalidad     IN  NUMBER,
                                peFechaInicio        IN  DATE,  -- Fecha Inicio del contrato
                                peFechaFin           IN  DATE,  -- Fecha Fin del contrato
                                peOtrosTerm          IN  VARCHAR2, -- Terminos y condiciones
                                peTipoContrato       IN  NUMBER,
                                peIdTramiteTemp      IN  NUMBER,
                                peTelefono           IN  VARCHAR2,
                                peExtension          IN  VARCHAR2,   
                                peEmail              IN  VARCHAR2,
                                peDomicilioUno       IN  VARCHAR2,
                                peDomicilioDos       IN  VARCHAR2, 
                                pePoblacion          IN  VARCHAR2,
                                peZonaPostal         IN  VARCHAR2,
                                pePaisResidencia     IN  NUMBER, 
                                peBandera            IN  CHAR,  -- TRUE = 1, FALSE = 0
                                peAfolExiste         IN  CHAR,  -- TRUE = 1, FALSE = 0
                                peNIFP               IN  VARCHAR2,  
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2,   
                                psFolioElectronico  OUT  VARCHAR2, 
                                psIdPersonaInsertar OUT  NUMBER --ID DE LA PERSONA QUE SE VA A INSERTAR                                     
                            )
IS

vlExiste                NUMBER;
vlIdPersona             NUMBER;
vlIdDomicilio           NUMBER;
vlIdTramiteRugIncom     NUMBER;
vlIdContrato            NUMBER;
vlNumPartes             NUMBER;
vlGrupo                 NUMBER;
vlIdPerfil              NUMBER;
vlresult                NUMBER;
vlPerfil                VARCHAR(10);
vlTextResult            VARCHAR2(500);

vlCountCURPExiste       NUMBER;
vlCurp                  VARCHAR(25);

--VARIABLES VALIDACION RFC
vlPsResultValRFC        NUMBER;
vlPsTxtResultValRFC     VARCHAR(4000);

vlFolioElectronicoExist RUG_PERSONAS.Folio_Mercantil%TYPE;
vlFolioElecExist        NUMBER;
vlNvoFolioElectronico   VARCHAR(250);

--VARIABLES VALIDACION DE CURP
vlPsResultValCURP       NUMBER;
vlPsTxtResultValCURP    VARCHAR(4000);

--VARIABLES VALIDACION FOLIO ELECTRONICO
vlPsResultValFolio      NUMBER;
vlPsTxtResultValFolio   VARCHAR(4000);

--CURP
vlCountCurpRegExp NUMBER;

Ex_Error            EXCEPTION;
Ex_ErrRFC           EXCEPTION;
Ex_Texto    EXCEPTION;

BEGIN

    BEGIN
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peIdUsuario', peIdUsuario, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peTipoPersona', peTipoPersona, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'IdTipo', IdTipo, 'IN');     
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peRazonSocial', peRazonSocial, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peRFC', peRFC, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peCURP', peCURP, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peFolioMercantil', peFolioMercantil, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peCalle', peCalle, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peNumExt', peNumExt, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peNumInt', peNumInt, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peNombre', peNombre, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peApellidoP', peApellidoP, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peApellidoM', peApellidoM, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peIdColonia', peIdColonia, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peIdLocalidad', peIdLocalidad, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peIdNacionalidad', peIdNacionalidad, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peFechaInicio', peFechaInicio, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peFechaFin', peFechaFin, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peOtrosTerm', peOtrosTerm, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peTipoContrato', peTipoContrato, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peTelefono', peTelefono, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peExtension', peExtension, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peEmail', peEmail, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peDomicilioUno', peDomicilioUno, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peDomicilioDos', peDomicilioDos, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'pePoblacion', pePoblacion, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peZonaPostal', peZonaPostal, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'pePaisResidencia', pePaisResidencia, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peBandera', peBandera, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peAfolExiste', peAfolExiste, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peNIFP', peNIFP, 'IN');
    END;



    SELECT ID_GRUPO, ID_PERFIL, CVE_PERFIL
      INTO vlGrupo, vlIdPerfil, vlPerfil
      FROM V_USUARIO_SESION_RUG
     WHERE ID_PERSONA =  peIdUsuario;

    -- EL GRUPO 1 SE ASIGNA A LA RELACION DEL USUARIO CON EL ACREEDOR
    IF(vlIdPerfil != 4 OR vlGrupo != 15) THEN
        vlGrupo := 1;                        
    END IF;

    IF vlExiste = 1 THEN

        psResult := 115;
        RAISE Ex_Error;   

    END IF;

    --VALIDA QUE LA NACIONALIDAD SEA VALIDA
    SELECT COUNT(*)
      INTO vlresult
      FROM RUG_CAT_NACIONALIDADES
     WHERE ID_NACIONALIDAD = peIdNacionalidad;

    IF vlresult = 0 THEN

        psResult := 19;
        RAISE  Ex_Error;

    END IF;

    -- VALIDA EL PAIS DE RESIDENCIA 
    SELECT COUNT(*)
      INTO vlresult
      FROM RUG_CAT_NACIONALIDADES
     WHERE ID_NACIONALIDAD = pePaisResidencia;


    IF vlresult = 0 THEN

        psResult := 117;
        RAISE  Ex_Error;

    END IF;


    -- VALIDA COLONIA -- NACIONALIDAD MEXICANA 
    IF peIdNacionalidad = 1 THEN

        IF peIdColonia > 0 THEN

            SELECT COUNT(*)
              INTO vlresult
              FROM V_SE_CAT_COLONIAS_RUG
             WHERE ID_COLONIA = peIdColonia;

            IF vlresult = 0 THEN

                psResult := 119;
                RAISE Ex_Error;

            END IF;

        END IF;


        IF peIdLocalidad > 0 THEN

            SELECT COUNT(*)
              INTO vlresult
              FROM V_SE_CAT_LOCALIDADES_RUG
             WHERE ID_LOCALIDAD = peIdLocalidad;

            IF vlresult = 0 THEN

                psResult := 120;
                RAISE Ex_Error;

            END IF;

        END IF;



    END IF;

   -- RFC ES OBLIGATORIO PARA PERSONAS MEXICANAS MENOS PARA SOCIEDAD MERCANTIL, PERSONA MORAL
    IF peIdNacionalidad = 1 AND (peRFC IS NULL OR peRFC = '') AND IdTipo <> 'SM' AND peBandera = 1 THEN

        vlPsResultValRFC := 110;
        vlPsTxtResultValRFC := RUG.FN_MENSAJE_ERROR(vlPsResultValRFC);

        RAISE Ex_ErrRFC;
    ELSIF peIdNacionalidad = 1 AND (peRFC IS NULL OR peRFC = '') AND IdTipo <> 'SM' AND peBandera = 0 THEN
        vlPsResultValRFC := 141;
        vlPsTxtResultValRFC := RUG.FN_MENSAJE_ERROR(vlPsResultValRFC);

        RAISE Ex_ErrRFC;
    END IF;


   --VALIDA RFC
    --RUG.SP_VALIDA_RFC(peIdNacionalidad, peRFC, peTipoPersona, vlPsResultValRFC, vlPsTxtResultValRFC);

    IF vlPsResultValRFC <> 0 THEN
        RAISE Ex_ErrRFC;
    END IF; 


   -- VALIDACIONES
    IF peIdUsuario IS NULL OR peTipoPersona IS NULL THEN

        psResult := 13;
        RAISE  Ex_Error;

    END IF;

    SELECT COUNT(*) 
      INTO vlNumPartes
      FROM RUG_REL_TRAM_INC_PARTES
     WHERE ID_TRAMITE_TEMP = peIdTramiteTemp AND ID_PARTE = 4 AND STATUS_REG = 'AC';

    IF vlNumPartes > 0 THEN

        psResult   :=29;
        RAISE Ex_Error;

    END IF;

    -- VALIDACION DEL FOLIO ELECTRONICOS EN PERSONA MORAL MEXICANA, OT
    IF peTipoPersona = 'PM' AND IdTipo = 'OT' AND  (peRFC IS NOT NULL OR TRIM(peRFC) <> '') AND peIdNacionalidad = 1 AND  peBandera = 1 THEN

      IF peFolioMercantil IS NOT NULL OR TRIM(peFolioMercantil) <> '' THEN 

        SP_VALIDA_FOLIO_DUPLICADO(peTipoPersona, peIdNacionalidad, peNIFP, peRFC, peCURP, peFolioMercantil, vlPsResultValFolio, vlPsTxtResultValFolio);

        IF vlPsResultValFolio <> 0 THEN

            psResult := vlPsResultValFolio;
            psTxResult := vlPsTxtResultValFolio;
            RAISE Ex_Error;

        END IF;

        SELECT COUNT(FOLIO_MERCANTIL)
          INTO vlFolioElecExist
          FROM RUG.RUG_PERSONAS
         WHERE UPPER(RFC) = peRFC
           AND FOLIO_MERCANTIL IS NOT NULL;


                IF vlFolioElecExist > 0 THEN

                SELECT FOLIO_MERCANTIL
                  INTO vlFolioElectronicoExist
                 FROM ( 
                        SELECT FOLIO_MERCANTIL, FH_REGISTRO
                          FROM RUG.RUG_PERSONAS
                         WHERE UPPER(RFC) = peRFC
                           AND ROWNUM < 2
                           AND FOLIO_MERCANTIL IS NOT NULL
                         ORDER BY FH_REGISTRO DESC);

                    IF vlFolioElectronicoExist <> NVL(peFolioMercantil, '-1') THEN

                        IF vlFolioElectronicoExist IS NOT NULL OR TRIM(vlFolioElectronicoExist) = '' THEN

                            DBMS_OUTPUT.PUT_LINE(peFolioMercantil || ' - ' || peRFC);
                            psResult   := 134;
                            psTxResult := RUG.FN_MENSAJE_ERROR(psResult);            
                            psTxResult := REPLACE(psTxResult, '@vlFolioElectronico', vlFolioElectronicoExist);
                            psTxResult := REPLACE(psTxResult, '@vlRFC', peRFC);

                            RAISE Ex_Texto;

                        END IF;

                    END IF;

               --ELSIF peBandera = 1 THEN   
               ELSE 

                SELECT COUNT(FOLIO_MERCANTIL)
                  INTO vlFolioElecExist
                  FROM RUG.RUG_PERSONAS
                 WHERE UPPER(FOLIO_MERCANTIL) = peFolioMercantil
                   AND FOLIO_MERCANTIL IS NOT NULL;

                           IF vlFolioElecExist > 0 THEN

                                psResult   := 128;
                                psTxResult := RUG.FN_MENSAJE_ERROR(psResult);            
                                psTxResult := REPLACE(psTxResult, '@folio', peFolioMercantil);

                                RAISE Ex_Texto;

                           ELSIF peFolioMercantil IS NULL OR TRIM(peFolioMercantil) <> '' THEN 

                                SP_GENERA_FOLIO_ELECTRONICO(vlNvoFolioElectronico, vlPsResultValFolio, vlPsTxtResultValFolio);

                                    IF vlPsResultValFolio <> 0 THEN
                                          psResult := vlPsResultValFolio;
                                          psTxResult := vlPsTxtResultValFolio;
                                          RAISE Ex_Error;
                                    END IF;
                           END IF;

               END IF;

      ELSIF (peFolioMercantil IS NULL OR TRIM(peFolioMercantil) = '') AND peBandera = 1 THEN

            SP_GENERA_FOLIO_ELECTRONICO(vlNvoFolioElectronico, vlPsResultValFolio, vlPsTxtResultValFolio);

            IF vlPsResultValFolio <> 0 THEN
                  psResult := vlPsResultValFolio;
                  psTxResult := vlPsTxtResultValFolio;
                  RAISE Ex_Error;
            END IF;           

      END IF;

    ELSE
         IF (peRFC IS NULL OR TRIM(peRFC) = '') AND (peFolioMercantil IS NOT NULL OR TRIM(peFolioMercantil) <> '') AND  peTipoPersona = 'OT' THEN

                                psResult   := 135;
                                psTxResult := RUG.FN_MENSAJE_ERROR(psResult);            

                                RAISE Ex_Error;

         END IF;
    END IF;

 --VALIDACIONES PARA PERSONA MORAL, SOCIEDAD MERCANTIL Y BANDERA 1
 IF peTipoPersona = 'PM' AND IdTipo = 'SM' AND  (peFolioMercantil IS NULL OR TRIM(peFolioMercantil) = '') AND peIdNacionalidad = 1 AND peBandera = 1 THEN

    psResult   := 142;
    psTxResult := RUG.FN_MENSAJE_ERROR(psResult);            

    RAISE Ex_Error;

 END IF;

 --VALIDACIONES PARA PERSONA FISICA
 IF peTipoPersona = 'PF' THEN

        --Validar Nombre
        --  peNombre, peApellidoP, peApellidoM, peCURP

        IF(peNombre is null OR TRIM(penombre) <> '') THEN

            psResult := 79;    
            RAISE Ex_Error;

        END IF;


        IF(peApellidoP is null OR TRIM(peApellidoP) <> ''
        ) THEN

            psResult := 80;    
            RAISE Ex_Error;

        END IF;


        IF (peIdNacionalidad = 1) THEN

            IF(TRIM(peCURP) <> '' OR peCURP IS NOT NULL) THEN

                RUG.SP_VALIDA_CURP(peCURP, vlPsResultValCURP, vlPsTxtResultValCURP);

                IF vlPsResultValCURP <> 0 THEN

                    psResult := vlPsResultValCURP;                    
                    RAISE Ex_Error;

                END IF;  

                vlCurp := UPPER(peCURP);                                       

                SELECT COUNT(*)
                  INTO vlCountCURPExiste
                  FROM RUG_PERSONAS_FISICAS A , RUG_PERSONAS B
                 WHERE UPPER(A.CURP) = vlCurp
                   AND A.ID_PERSONA = B.ID_PERSONA
                   AND B.SIT_PERSONA != 'BF';


                -- VALIDA QUE EL CURP NO TENGA FOLIO ASOCIADO PARA PERSONA FISICAS
                IF vlPsResultValCURP = 0 THEN

                    SELECT COUNT(A.FOLIO_MERCANTIL)
                      INTO vlFolioElecExist
                      FROM RUG_PERSONAS A,
                           RUG_PERSONAS_FISICAS B
                     WHERE A.ID_PERSONA = B.ID_PERSONA
                       AND A.ID_NACIONALIDAD = 1
                       AND B.CURP = vlCurp
                       AND A.FOLIO_MERCANTIL != DECODE(peFolioMercantil,'','',peFolioMercantil);

                    IF vlFolioElecExist > 0 THEN

                        psResult := 138;
                        psTxResult := RUG.FN_MENSAJE_ERROR(psResult);            
                        psTxResult := REPLACE(psTxResult,  '@vlFolioElectronico', peFolioMercantil);


                        RAISE Ex_Texto;
                    ELSE
                            IF (peFolioMercantil IS NULL OR TRIM (peFolioMercantil) = '') AND peBandera = 1 THEN 

                                SP_GENERA_FOLIO_ELECTRONICO(vlNvoFolioElectronico, vlPsResultValFolio, vlPsTxtResultValFolio);

                                    IF vlPsResultValFolio <> 0 THEN
                                          psResult := vlPsResultValFolio;
                                          psTxResult := vlPsTxtResultValFolio;
                                          RAISE Ex_Error;
                                    END IF;
                            ELSE

                                SP_VALIDA_FOLIO_DUPLICADO(peTipoPersona, peIdNacionalidad, peNIFP, peRFC, peCURP, peFolioMercantil, vlPsResultValFolio, vlPsTxtResultValFolio);


                                IF vlPsResultValFolio <> 0 THEN

                                    psResult := vlPsResultValFolio;
                                    psTxResult := vlPsTxtResultValFolio;
                                    RAISE Ex_Error;

                                END IF; 

                            END IF;

                    END IF;


              END IF;        

            ELSE

              IF (vlPsResultValCURP IS NULL OR TRIM(vlPsResultValCURP) = '') AND (peFolioMercantil is NOT null or trim (peFolioMercantil) <> '') AND peBandera = 0  THEN

                    psResult := 146;
                    psTxResult := RUG.FN_MENSAJE_ERROR(psResult);            

                    RAISE Ex_Error;  

              ELSIF (vlPsResultValCURP IS NULL OR TRIM(vlPsResultValCURP) = '') AND peBandera = 1 THEN

                    psResult := 65;
                    psTxResult := RUG.FN_MENSAJE_ERROR(psResult);            

                    RAISE Ex_Error;                

              END IF;    

            END IF;

        --ELSE
            --SP_GENERA_FOLIO_ELECTRONICO(vlNvoFolioElectronico, vlPsResultValFolio, vlPsTxtResultValFolio);                
        END IF;        

    END IF;      


   -- VALIDACION DEL FOLIO ELECTRONICOS EN PERSONA MORAL Y FISICA EXTRANJERA


     IF ((peRFC IS NOT NULL OR TRIM(peRFC) <> '') OR (peNIFP IS NOT NULL OR TRIM(peNIFP) <> '') )AND peIdNacionalidad <> 1  THEN


        IF peTipoPersona = 'PF' THEN
             SELECT COUNT(FOLIO_MERCANTIL)
              INTO vlFolioElecExist
              FROM RUG.RUG_PERSONAS
             WHERE UPPER(RFC) = peRFC
               AND ID_NACIONALIDAD = peIdNacionalidad
               AND FOLIO_MERCANTIL IS NOT NULL;
        ELSE 
            SELECT COUNT(FOLIO_MERCANTIL)
              INTO vlFolioElecExist
              FROM RUG.RUG_PERSONAS
             WHERE UPPER(NIFP) = peNIFP
               AND ID_NACIONALIDAD = peIdNacionalidad
               AND FOLIO_MERCANTIL IS NOT NULL;
        END IF;               

                IF vlFolioElecExist > 0 THEN

                    IF peTipoPersona = 'PF' THEN
                        SELECT FOLIO_MERCANTIL
                          INTO vlFolioElectronicoExist
                         FROM ( 
                                SELECT FOLIO_MERCANTIL, FH_REGISTRO
                                  FROM RUG.RUG_PERSONAS
                                 WHERE UPPER(RFC) = peRFC
                                   AND ROWNUM < 2
                                   AND FOLIO_MERCANTIL IS NOT NULL
                                 ORDER BY FH_REGISTRO DESC);
                    ELSE
                                SELECT FOLIO_MERCANTIL
                                  INTO vlFolioElectronicoExist
                                 FROM ( 
                                        SELECT FOLIO_MERCANTIL, FH_REGISTRO
                                          FROM RUG.RUG_PERSONAS
                                         WHERE UPPER(NIFP) = peNIFP
                                           AND ROWNUM < 2
                                           AND FOLIO_MERCANTIL IS NOT NULL
                                         ORDER BY FH_REGISTRO DESC);
                     END IF;


                 IF vlFolioElectronicoExist <> NVL(peFolioMercantil, '-1') THEN

                     IF vlFolioElectronicoExist IS NOT NULL OR TRIM(vlFolioElectronicoExist) = '' THEN

      --------------------------------validacion de bandera acreedores extranjeros
                      IF peAfolExiste <> 1 THEN
                                psResult   := 137;
                                psTxResult := RUG.FN_MENSAJE_ERROR(psResult);            
                                psTxResult := REPLACE(psTxResult, '@vlFolioElectronico', vlFolioElectronicoExist);

                                IF  peTipoPersona = 'PF' THEN
                                    psTxResult := REPLACE(psTxResult, '@vlNIF', peRFC);
                                ELSE 
                                    psTxResult := REPLACE(psTxResult, '@vlNIF', peNIFP);
                                END IF;

                                RAISE Ex_Texto;                                          
                        END IF;
                   END IF;
      --------------------------------validacion de bandera acreedores extranjeros                

                  END IF;

               ELSE

                IF (peFolioMercantil IS NULL OR TRIM (peFolioMercantil) = '') AND peBandera = 1 THEN  

                   SP_GENERA_FOLIO_ELECTRONICO(vlNvoFolioElectronico, vlPsResultValFolio, vlPsTxtResultValFolio);

                        IF vlPsResultValFolio <> 0 THEN

                              psResult := vlPsResultValFolio;
                              psTxResult := vlPsTxtResultValFolio;
                              RAISE Ex_Error;
                        END IF; 

                ELSIF peTipoPersona = 'PM' AND (peNIFP IS NOT NULL OR TRIM(peNIFP) <> '') AND (peFolioMercantil IS NOT NULL OR TRIM(peFolioMercantil) <> '') THEN

                    SP_VALIDA_FOLIO_DUPLICADO(peTipoPersona, peIdNacionalidad, peNIFP, peRFC, peCURP, peFolioMercantil, vlPsResultValFolio, vlPsTxtResultValFolio);


                    IF vlPsResultValFolio <> 0 THEN

                            psResult := vlPsResultValFolio;
                            psTxResult := vlPsTxtResultValFolio;
                            RAISE Ex_Error;

                    END IF;
                END IF;  
               END IF;
     ELSE


          IF (peNIFP IS NULL OR TRIM(peNIFP) = '') AND peIdNacionalidad <> 1 AND ((peFolioMercantil IS NULL OR TRIM(peFolioMercantil) ='') OR (peFolioMercantil IS NOT NULL OR TRIM(peFolioMercantil) <> ''))  AND peBandera = 1 AND peTipoPersona = 'PM'   THEN
                psResult   := 140;
                psTxResult := RUG.FN_MENSAJE_ERROR(psResult);            

                RAISE Ex_Error;
          ELSIF  (peNIFP IS NULL OR TRIM(peNIFP) = '') AND peIdNacionalidad <> 1 AND (peFolioMercantil IS NOT NULL OR TRIM(peFolioMercantil) <> '') AND peBandera = 0 AND peTipoPersona = 'PM' THEN
                psResult   := 144;
                psTxResult := RUG.FN_MENSAJE_ERROR(psResult);            

                RAISE Ex_Error;

          --PERSONA FISICA Y EXTRANJERA
          ELSIF peTipoPersona = 'PF' AND peIdNacionalidad <> 1 AND (peFolioMercantil IS NULL OR TRIM(peFolioMercantil) = '')  THEN

               SELECT COUNT(FOLIO_MERCANTIL)
                 INTO vlFolioElecExist
                 FROM RUG.RUG_PERSONAS
                WHERE FOLIO_MERCANTIL = peFolioMercantil
                  AND ID_NACIONALIDAD = peIdNacionalidad;

                   IF vlFolioElecExist = 0 AND peBandera = 1 THEN

                        SP_GENERA_FOLIO_ELECTRONICO(vlNvoFolioElectronico, vlPsResultValFolio, vlPsTxtResultValFolio);

                        IF vlPsResultValFolio <> 0 THEN
                              psResult := vlPsResultValFolio;
                              psTxResult := vlPsTxtResultValFolio;
                              RAISE Ex_Error;
                        END IF; 

                   END IF;

          ELSIF peTipoPersona = 'PF' AND peIdNacionalidad <> 1 AND (peFolioMercantil IS NOT NULL OR TRIM(peFolioMercantil) <> '')  THEN

               SELECT COUNT(FOLIO_MERCANTIL)
                 INTO vlFolioElecExist
                 FROM RUG.RUG_PERSONAS
                WHERE FOLIO_MERCANTIL = peFolioMercantil
                  AND ID_NACIONALIDAD = peIdNacionalidad;

                   IF vlFolioElecExist =  0 THEN
                        psResult := 145;
                        psTxResult := RUG.FN_MENSAJE_ERROR(psResult);            

                        RAISE Ex_Error;   
                   END IF;

          END IF;

     END IF;     


    vlIdDomicilio := SEQ_RUG_ID_DOMICILIO.NEXTVAL;

    IF(pePaisResidencia != 1) THEN

        INSERT INTO RUG.RUG_DOMICILIOS_EXT(ID_DOMICILIO, ID_PAIS_RESIDENCIA,UBICA_DOMICILIO_1, UBICA_DOMICILIO_2, POBLACION, ZONA_POSTAL)
        VALUES(vlIdDomicilio, pePaisResidencia, peDomicilioUno, peDomicilioDos, pePoblacion, peZonaPostal);

    ELSE            

        INSERT INTO RUG_DOMICILIOS (ID_DOMICILIO, CALLE, NUM_EXTERIOR, NUM_INTERIOR, ID_COLONIA, ID_LOCALIDAD)
        VALUES   (vlIdDomicilio, peCalle, peNumExt, peNumInt, DECODE(peIdColonia, -1, 0,peIdColonia), DECODE(peIdLocalidad,-1,0,peIdLocalidad));

    END IF;                


    vlIdPersona:= SEQ_RUG_ID_PERSONA.NEXTVAL;    


    IF(peFolioMercantil = '' OR peFolioMercantil IS NULL) THEN
             IF peAfolExiste <> 1 THEN
                                    psFolioElectronico := vlNvoFolioElectronico;
                            ELSE
                                 psFolioElectronico := vlFolioElectronicoExist;
                      END IF;
         ELSE    
        psFolioElectronico := peFolioMercantil;        
    END IF;






    INSERT INTO RUG_PERSONAS (ID_PERSONA, RFC, ID_NACIONALIDAD, PER_JURIDICA, FH_REGISTRO, PROCEDENCIA, SIT_PERSONA,
                                 CVE_NACIONALIDAD, ID_DOMICILIO, FOLIO_MERCANTIL, FECHA_INSCR_CC, REG_TERMINADO, E_MAIL, CURP_DOC, NIFP)
    VALUES   (vlIdPersona, peRFC, peIdNacionalidad, peTipoPersona, TRUNC(SYSDATE), 'NAL', 'AC', NULL, vlIdDomicilio, psFolioElectronico, NULL, 'N', peEmail, peCURP, peNIFP);

    psIdPersonaInsertar := vlIdPersona; 

    INSERT INTO RUG_TELEFONOS
    VALUES(vlIdPersona, NULL, peTelefono, peExtension, SYSDATE, 'AC'); 


    IF(UPPER(peTipoPersona) = 'PM') THEN


        IF peRazonSocial IS NULL OR peRazonSocial = '' THEN 

            psResult := 77;
            RAISE Ex_Error;

        END IF;


        INSERT INTO RUG_PERSONAS_MORALES (ID_PERSONA, RAZON_SOCIAL, TIPO)
        VALUES   (vlIdPersona, peRazonSocial, IdTipo);


    ELSIF (UPPER(peTipoPersona) = 'PF') THEN


        IF peNombre IS NULL OR peNombre = '' THEN

            psResult := 79;
            RAISE Ex_Error;

        END IF;


        IF peApellidoP IS NULL OR peApellidoP = '' THEN

            psResult := 80;
            RAISE Ex_Error;

        END IF;


        INSERT INTO RUG_PERSONAS_FISICAS (ID_PERSONA, NOMBRE_PERSONA, AP_PATERNO, AP_MATERNO, CURP)
        VALUES   (vlIdPersona, peNombre, peApellidoP, peApellidoM, peCURP);

    END IF;

    --vlIdTramiteRugIncom:= SEQ_TRAM_INCOMP.NEXTVAL;


    INSERT INTO REL_USU_ACREEDOR
    VALUES (peIdUsuario, vlIdPersona, 'N', SYSDATE, 'AC');


    INSERT INTO RUG_REL_GRUPO_ACREEDOR
    VALUES(SEQ_RUG_REL_PRIVILEGIO_ACREEDO.NEXTVAL, vlIdPersona, peIdUsuario, peIdUsuario, 'AC', SYSDATE, vlGrupo) ;


    vlIdContrato := SEQ_CONTRATO.NEXTVAL;


    INSERT INTO RUG_CONTRATO (ID_CONTRATO, FECHA_INICIO, FECHA_FIN, OTROS_TERMINOS_CONTRATO, TIPO_CONTRATO, 
                        ID_TRAMITE_TEMP, FECHA_REG, STATUS_REG, ID_USUARIO)
    VALUES(vlIdContrato, peFechaInicio, peFechaFin, peOtrosTerm, peTipoContrato, peIdTramiteTemp, SYSDATE, 'AC', peIdUsuario);


    INSERT INTO RUG_REL_TRAM_INC_PARTES
    VALUES (peIdTramiteTemp, vlIdPersona, 4, peTipoPersona, 'AC', SYSDATE);


    SP_ALTA_BITACORA_TRAMITE2(peIdTramiteTemp, 5, 0, sysdate, 'F', vlresult, vlTextResult);

    IF vlresult != 0 THEN

        psResult   := vlresult;
        psTxResult := vlTextResult;            

        RAISE Ex_Error;

    END IF;

    COMMIT;


    psResult   :=0;        
    psTxResult :='Actualizacion finalizada satisfactoriamente';

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'psFolioElectronico', psFolioElectronico, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION
WHEN Ex_ErrRFC  THEN
      psResult := vlPsResultValRFC;
      psTxResult := vlPsTxtResultValRFC;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;

WHEN Ex_Texto  THEN
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'peIdUsuario', peIdUsuario, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;

WHEN Ex_Error  THEN

      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;


WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;

END SP_ALTA_ACREEDOR_REP;
/

