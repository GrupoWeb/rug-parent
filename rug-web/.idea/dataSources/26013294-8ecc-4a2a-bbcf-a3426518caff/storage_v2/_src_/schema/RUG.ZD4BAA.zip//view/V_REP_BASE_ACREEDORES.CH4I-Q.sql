create view V_REP_BASE_ACREEDORES as
SELECT
        /*+index(rb.RUG_BITAC_TRAMITES_IDX_01 , rt.RUG_REL_TRAM_PARTES_PK), index (t) , index (PER) */
 rb.id_tramite_temp,
            rb.fecha_status,
            rb.fecha_reg,
            rb.status_reg,
            t.id_tramite,
            t.id_persona id_persona_alta,
            t.fech_pre_inscr,
            t.fecha_inscr,
            t.fecha_creacion,
            rt.id_persona id_acreedor,
            per.nombre_persona nombre_acreedor,
            p.rfc rfc_acreedor,
            vu.e_mail e_mail_persona_alta,
            vu.id_perfil,
            vu.cve_perfil,
            vu.id_grupo,
            vu.desc_grupo,
            p.per_juridica
     FROM   RUG.RUG_BITAC_TRAMITES rb,
            rug.TRAMITES t,
            rug.RUG_REL_TRAM_PARTES rt,
            rug.V_REP_PERSONAS per,
            rug.rug_personas p,
            rug.v_usuarios_all vu
    WHERE   rb.id_tramite_temp = t.id_tramite_temp
            AND rb.ID_STATUS = 3
            AND rb.STATUS_REG = 'AC'
            AND rb.ID_TIPO_TRAMITE = 12
            AND rt.id_tramite = t.id_tramite
            AND rt.id_persona = per.id_persona
            AND rt.id_parte = 4
            AND rt.id_persona = p.id_persona
            AND  t.id_persona = vu.id_persona
            AND UPPER (PER.NOMBRE_PERSONA) NOT LIKE '%PRUEBA%'
            AND NOT (REGEXP_LIKE ( (SELECT   tx_parametro
                                      FROM   RUG_REP_PARAM
                                     WHERE   cve_parametro = 'USUARIOS'),
                                  '''' || vu.e_mail || ''''))
            /*   and vu.e_mail not in ('adminrug','hjimenez@verasoft.mx','isisnatalia.ir@gmail.com','anaid375@hotmail.com'
          ,'jmedellin@verasoft.mx','jcsavage13@hotmail.com', 'lagaq@hotmail.com', 'myg2504@hotmail.com',
         'flaviolmendoza@gmail.com', 'ecastillo12@hotmail.com', 'janboker@gmail.com')*/
            --and regexp_substr(p.rfc,  '^AAA[0-9]+') is null
            -- and p.rfc is not null
            AND rt.id_persona <> 3626                 -- edgar veites;;;;
/

