create PROCEDURE         SP_ALTA_TRAMITE_RASTREO (peIdPersona            IN     NUMBER, -- IDENTIFICADOR DE LA PESONA K SeLOGUEA                                                        
                                                        peIdTipoTramite        IN     NUMBER, --INSCRIPCION , ALTA ACREEDORES, AVISO PREVENTIVO
                                                        peIdAcreedor           IN     NUMBER, --IDENTIFICADOR UNICO DE LA PERSONA ACREEDOR REPRESENTADO
                                                        pePersonaJuridica      IN     VARCHAR2, --IDENTIFICADOR DE LA PERSONA JURIDICA PUEDE SER PF O PM
                                                        peIdPaso               IN     NUMBER,
                                                        peStatusTram           IN     NUMBER,
                                                        peFechaStatus          IN     DATE,
                                                        peCveRastreo           IN     VARCHAR2,
                                                        peIdArchivo            IN     NUMBER, 
                                                        psIdTramiteIncompleto  OUT    NUMBER, --IDENTIFICADOR UNICO DEL REGISTRO
                                                        psResult               OUT    INTEGER,   
                                                        psTxResult             OUT    VARCHAR2)
IS


vlPersonaJuridica       VARCHAR2(2);
vlCantidad              NUMBER;
vlCveRastreo            NUMBER;
vlIdTramiteRugIncom     NUMBER;

Ex_Error                EXCEPTION;
Ex_ErrParametro         EXCEPTION;

BEGIN


    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRAMITE_RASTREO', 'peIdPersona', CAST(peIdPersona AS VARCHAR2),'IN');    
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRAMITE_RASTREO', 'peIdAcreedor', CAST(peIdAcreedor AS VARCHAR2), 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRAMITE_RASTREO', 'pePersonaJuridica', pePersonaJuridica, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRAMITE_RASTREO', 'peIdPaso', CAST(peIdPaso AS VARCHAR2), 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRAMITE_RASTREO', 'peStatusTram', CAST(peStatusTram AS VARCHAR2), 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRAMITE_RASTREO', 'peFechaStatus', CAST(peFechaStatus AS VARCHAR2), 'IN'); 
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRAMITE_RASTREO', 'peCveRastreo', peCveRastreo, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRAMITE_RASTREO', 'peIdTipoTramite', peIdTipoTramite, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRAMITE_RASTREO', 'peIdArchivo', peIdArchivo, 'IN');


    IF (peCveRastreo = '' OR peCveRastreo IS NULL) THEN

        psResult:= 72;
        RAISE Ex_Error;

    END IF;

    SELECT COUNT(*)
      INTO vlCveRastreo
      FROM RUG_TRAMITE_RASTREO
     WHERE CVE_RASTREO = peCveRastreo
       AND ID_ACREEDOR = peIdAcreedor
       AND STATUS_REG = 'AC';


    IF vlCveRastreo = 0 THEN
        BEGIN




            IF (peIdTipoTramite != 10) THEN

                vlPersonaJuridica := pePersonaJuridica;


                SELECT COUNT(*)
                  INTO vlCantidad
                  FROM RUG_PERSONAS
                 WHERE ID_PERSONA = peIdAcreedor; 


                IF (vlPersonaJuridica IS NULL AND vlCantidad > 0) THEN

                    SELECT PER_JURIDICA
                      INTO vlPersonaJuridica
                      FROM RUG_PERSONAS
                     WHERE ID_PERSONA = peIdAcreedor;

                END IF;


                IF vlPersonaJuridica IS NULL THEN
                    RAISE Ex_ErrParametro;
                END IF;


            END IF;


            IF peIdPersona IS NULL OR peIdAcreedor IS NULL OR peIdTipoTramite IS NULL OR peCveRastreo IS NULL THEN
                    RAISE Ex_ErrParametro;
            END IF;

             vlIdTramiteRugIncom:= SEQ_TRAM_INCOMP.NEXTVAL;

            INSERT INTO TRAMITES_RUG_INCOMP VALUES(vlIdTramiteRugIncom,peIdPersona, peIdTipoTramite,SYSDATE,NULL,'AC', peIdPaso, 0, peFechaStatus,0);

            IF (peIdTipoTramite != 10) THEN

                INSERT INTO RUG_REL_TRAM_INC_PARTES VALUES(vlIdTramiteRugIncom, peIdAcreedor, 4,  vlPersonaJuridica, 'AC', SYSDATE);

            END IF;

            INSERT INTO RUG_BITAC_TRAMITES VALUES(vlIdTramiteRugIncom, 0, SYSDATE, 0, peIdTipoTramite, SYSDATE, 'AC');

            INSERT INTO RUG_TRAMITE_RASTREO(ID_TRAM_RAS,ID_ACREEDOR,ID_TRAMITE_TEMP,CVE_RASTREO,FH_REGISTRO,STATUS_REG, ID_ARCHIVO)
            VALUES (SEQ_TRAM_RASTREO.NEXTVAL, peIdAcreedor, vlIdTramiteRugIncom, peCveRastreo, SYSDATE, 'AC', peIdArchivo);   


            COMMIT;

            psIdTramiteIncompleto:=vlIdTramiteRugIncom;
            psResult:=0;   
            psTxResult:= 'ALTA EXITOSA';--pkg_infz_inst_fenx.FunObtMsgErr(psResult);            

        END;
    ELSE

        psIdTramiteIncompleto:=vlIdTramiteRugIncom;
        psResult:=-1;   
        psTxResult:= REPLACE(RUG.FN_MENSAJE_ERROR(58), '@peCveRastreo', peCveRastreo); 

        ROLLBACK;


    END IF;

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRAMITE_RASTREO', 'psIdTramiteIncompleto', CAST(psIdTramiteIncompleto AS VARCHAR2), 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRAMITE_RASTREO', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRAMITE_RASTREO', 'psTxResult', psTxResult, 'OUT');    



EXCEPTION 

WHEN Ex_Error  THEN      
      psTxResult := RUG.FN_MENSAJE_ERROR(psResult); 

      rollback;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRAMITE_RASTREO', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRAMITE_RASTREO', 'psTxResult', psTxResult, 'OUT');

  WHEN Ex_ErrParametro  THEN
      psResult:=13;
      psTxResult := RUG.FN_MENSAJE_ERROR(psResult); 

      rollback;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRAMITE_RASTREO', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_TRAMITE_RASTREO', 'psTxResult', psTxResult, 'OUT');    


   WHEN OTHERS THEN
   ROLLBACK;
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);


END;
/

