create PACKAGE         PKGFIRMATRAMITES_RUG 
AS
   /******************************************************************************
      NAME:       PKGFIRMATRAMITES_RUG
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        28/10/2009             1. Created this package.
   ******************************************************************************/
   -------------------------------------------------------------------------------
   -------------------------------------------------------------------------------
   --                       C O N S T A N T E S                                 --
   -------------------------------------------------------------------------------
   -------------------------------------------------------------------------------

   coVerdadero CONSTANT   VARCHAR2 (1) := 'V';
   coFalso CONSTANT       VARCHAR2 (1) := 'F';

   -------------------------------------------------------------------------------
   -------------------------------------------------------------------------------
   --                       F U N C I O N E S                                   --
   -------------------------------------------------------------------------------
   -------------------------------------------------------------------------------

   -------------------------------------------------------------------------------
   -------------------------------------------------------------------------------
   --                   P R O C E D I M I E N T O S                             --
   -------------------------------------------------------------------------------
   -------------------------------------------------------------------------------


   --******************************************************************************/
   --*Nombre:   IniTramiteXMLFir
   --*Objetivo: Procedimiento que inserta la informacion para generar el tramite del SIGER
   --*Modifico: Ernesto Diaz Sanchez de Tagle
   --*Fecha Elaboracion: 19-JULIO-2010
   --*Ulltima Revision:
   --******************************************************************************/


   PROCEDURE ActDoctoTramFir(  peIdTramiteTemp        IN   DOCTOS_TRAM_FIRMADOS_RUG.ID_TRAMITE_TEMP%TYPE,
                               peCadenaOriginalNoFirmada    IN   DOCTOS_TRAM_FIRMADOS_RUG.CADENA_ORIG_NO_FIRMADA%TYPE,
                               peCadenaOriginalFirmada      IN   DOCTOS_TRAM_FIRMADOS_RUG.CADENA_ORIG_FIRMADA%TYPE,
                               peCadenaOrigFirmadaSE        IN   DOCTOS_TRAM_FIRMADOS_RUG.CADENA_ORIG_FIRMADA_SE%TYPE,
                               peTimeStampSE                IN   DOCTOS_TRAM_FIRMADOS_RUG.TIMESTAMP_SE%TYPE,
                               --peFechaCreacion              IN DOCTOS_TRAM_FIRMADOS_RUG.FH_REGISTRO%TYPE,
                               peBcommit                IN   VARCHAR2,
                               psResult                 OUT  INTEGER,
                               psTxResult               OUT  VARCHAR2);


    PROCEDURE ActDoctoTramFirTsp(  peIdTramiteTemp        IN   DOCTOS_TRAM_FIRMADOS_RUG.ID_TRAMITE_TEMP%TYPE,
                               peCadenaOriginalNoFirmada    IN   DOCTOS_TRAM_FIRMADOS_RUG.CADENA_ORIG_NO_FIRMADA%TYPE,
                               peCadenaOriginalFirmada      IN   DOCTOS_TRAM_FIRMADOS_RUG.CADENA_ORIG_FIRMADA%TYPE,
                               peCadenaOrigFirmadaSE        IN   DOCTOS_TRAM_FIRMADOS_RUG.CADENA_ORIG_FIRMADA_SE%TYPE,
                               peTimeStampSE                IN   DOCTOS_TRAM_FIRMADOS_RUG.TIMESTAMP_SE%TYPE,
                               peFechaCreacion              IN VARCHAR2,
                               peUsuarioFirmo                   IN   DOCTOS_TRAM_FIRMADOS_RUG.ID_USUARIO_FIRMO%TYPE,
                               peBcommit                IN   VARCHAR2,
                               psResult                 OUT  INTEGER,
                               psTxResult               OUT  VARCHAR2);                               
END PKGFIRMATRAMITES_RUG;
/

