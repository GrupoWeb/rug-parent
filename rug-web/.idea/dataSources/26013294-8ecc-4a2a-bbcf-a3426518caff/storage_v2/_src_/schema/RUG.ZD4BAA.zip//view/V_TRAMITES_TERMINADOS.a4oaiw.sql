create view V_TRAMITES_TERMINADOS as
SELECT   TRAM.ID_TRAMITE,
            TRAM.ID_TIPO_TRAMITE,
            GTT.DESCRIPCION,
            TRAM.FECH_PRE_INSCR,
            TRAM.FECHA_INSCR,
            RELT.ID_GARANTIA,
            TRAM.ID_STATUS_TRAM,
            STT.DESCRIP_STATUS,
            FN_PRECIO_REAL(TRAM.ID_PERSONA,TRAM.ID_TIPO_TRAMITE,TRAM.ID_TRAMITE,0) as PRECIO,
            RBB.FECHA_STATUS as FECHA_creacion,
            NULL as url_paso,
            DECODE (TRAM.ID_PERSONA, 0, TT.ID_PERSONA, TRAM.ID_PERSONA)
               AS ID_PERSONA_LOGIN,
            TRAM.ID_TRAMITE_TEMP,
            (SELECT   ID_PERSONA
               FROM   rug.RUG_REL_TRAM_PARTES
              WHERE   ID_TRAMITE = TRAM.ID_TRAMITE AND ID_PARTE = 4)
               ID_ACREEDOR,
            DECODE ( (SELECT   COUNT ( * )
                        FROM   RUG_TRAMITES_REASIGNADOS
                       WHERE   ID_TRAMITE_TEMP = TRAM.ID_TRAMITE_TEMP),
                    0, 'F',
                    'V')
               TRAMITE_REASIGNADO
     FROM   TRAMITES TRAM,
            RUG_CAT_TIPO_TRAMITE GTT,
            RUG_REL_TRAM_GARAN RELT,
            STATUS_TRAMITE STT,
            RUG_BITAC_TRAMITES RBB,
            RUG_REL_TRAM_GARAN RRTG,
            TRAMITES TT
    WHERE       TRAM.ID_TIPO_TRAMITE = GTT.ID_TIPO_TRAMITE
            AND TRAM.ID_TRAMITE = RELT.ID_TRAMITE(+)
            AND STT.ID_STATUS_TRAM = TRAM.ID_STATUS_TRAM
            AND TRAM.ID_TRAMITE_TEMP = RBB.ID_TRAMITE_TEMP
            AND RBB.ID_STATUS = 3
            AND RELT.STATUS_REG = 'AC'
            AND TRAM.STATUS_REG = 'AC'
            AND RRTG.ID_GARANTIA = RELT.ID_GARANTIA
            AND TT.ID_TRAMITE = RRTG.ID_TRAMITE
            AND TT.ID_TIPO_TRAMITE in (1,31)
   UNION ALL
   SELECT   TRAM.ID_TRAMITE,
            TRAM.ID_TIPO_TRAMITE,
            CASE  
                WHEN TRAM.ID_TIPO_TRAMITE IN (26, 27, 28, 29) THEN
                    FN_BORRA_SIN_CON_GARANTIA(GTT.DESCRIPCION)
                ELSE
                    GTT.DESCRIPCION
            END AS TIPO_TRAMITE,
            TRAM.FECH_PRE_INSCR,
            TRAM.FECHA_INSCR,
            0 ID_GARANTIA,
            TRAM.ID_STATUS_TRAM,
            STT.DESCRIP_STATUS,
            FN_PRECIO_REAL(TRAM.ID_PERSONA,TRAM.ID_TIPO_TRAMITE,TRAM.ID_TRAMITE,0),
            RBB.FECHA_STATUS,
            NULL,
            TRAM.ID_PERSONA AS ID_PERSONA_LOGIN,
            TRAM.ID_TRAMITE_TEMP,
            (SELECT   ID_PERSONA
               FROM   rug.RUG_REL_TRAM_PARTES
              WHERE   ID_TRAMITE = TRAM.ID_TRAMITE AND ID_PARTE = 4)
               ID_ACREEDOR,
            DECODE ( (SELECT   COUNT ( * )
                        FROM   RUG_TRAMITES_REASIGNADOS
                       WHERE   ID_TRAMITE_TEMP = TRAM.ID_TRAMITE_TEMP),
                    0, 'F',
                    'V')
               TRAMITE_REASIGNADO
     FROM   TRAMITES TRAM,
            RUG_CAT_TIPO_TRAMITE GTT,
            RUG_REL_TRAM_PARTES RTP,
            STATUS_TRAMITE STT,
            RUG_BITAC_TRAMITES RBB
    WHERE       TRAM.ID_TIPO_TRAMITE = GTT.ID_TIPO_TRAMITE
            AND TRAM.ID_TRAMITE = RTP.ID_TRAMITE(+)
            AND RTP.ID_PARTE = 1
            AND TRAM.ID_STATUS_TRAM IN (3, 10)
            AND STT.ID_STATUS_TRAM = TRAM.ID_STATUS_TRAM
            AND TRAM.ID_TRAMITE_TEMP = RBB.ID_TRAMITE_TEMP
            AND RBB.ID_STATUS = 3
            AND TRAM.STATUS_REG IN ('AC', 'CA')
            AND GTT.ID_TIPO_TRAMITE IN (10, 3, 11, 5
            -- GGR  12.04.2013    MMSECN2013-81
            , 26, 27, 28, 29)
/

