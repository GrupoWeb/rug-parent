create PROCEDURE           SP_UPDATE_PARTES_TRANSMISION (peIdPersona            IN     NUMBER,
                                                             peIdTipoTramite        IN     NUMBER,
                                                             peIdPersonaBorrar      IN     VARCHAR2,
                                                             peIdGarantia           IN     NUMBER,
                                                             psResult              OUT    NUMBER,
                                                             psTxResult            OUT    VARCHAR2)
IS

  vlIdTramiteRugIncom  NUMBER;
  vlCadena INSTITUCIONAL.PKGSE_COMUN.T_PALABRAS;
  vlIdPersonaBorrar VARCHAR2(10);
  vlIdRelacion      NUMBER;
  vlRelacionAux    NUMBER;

BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_UPDATE_PARTES_TRANSMISION', 'peIdPersona', peIdPersona, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_UPDATE_PARTES_TRANSMISION', 'peIdTipoTramite', peIdTipoTramite, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_UPDATE_PARTES_TRANSMISION', 'peIdPersonaBorrar', peIdPersonaBorrar, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_UPDATE_PARTES_TRANSMISION', 'peIdGarantia', peIdGarantia, 'IN');

  vlIdTramiteRugIncom:= SEQ_TRAM_INCOMP.NEXTVAL;

  INSERT INTO TRAMITES_RUG_INCOMP VALUES(vlIdTramiteRugIncom,peIdPersona,peIdTipoTramite,SYSDATE,NULL,'IN', NULL, NULL, NULL,0);

  INSERT INTO RUG_BITAC_TRAMITES VALUES(vlIdTramiteRugIncom, 0, SYSDATE, 0, peIdTipoTramite, SYSDATE, 'AC');

  vlCadena := INSTITUCIONAL.PKGSE_COMUN.SPLITCADENA(peIdPersonaBorrar,'|');

  vlIdRelacion := SEQ_RELACIONES.NEXTVAL;

  SELECT NVL(ID_RELACION,1)
  INTO vlRelacionAux
  FROM (
  Select ID_RELACION from RUG_REL_GARANTIA_PARTES
  Where ID_GARANTIA = peIdGarantia
  ORDER BY  ID_RELACION DESC
  )
  WHERE ROWNUM = 1;


  INSERT INTO RUG_REL_GARANTIA_PARTES
  (SELECT ID_GARANTIA, ID_PERSONA, ID_PARTE, vlIdRelacion, SYSDATE, 'AC'
    FROM RUG_REL_GARANTIA_PARTES
    WHERE ID_GARANTIA = peIdGarantia
      AND ID_RELACION = vlRelacionAux);


  for i in 1..vlCadena.count loop

     DELETE RUG_REL_GARANTIA_PARTES
     WHERE ID_GARANTIA = peIdGarantia
       AND ID_PERSONA =  vlCadena(I-1)
       AND ID_RELACION = vlIdRelacion;

  END LOOP;

  INSERT INTO RUG_REL_TRAM_INC_PARTES
  (SELECT VLIDTRAMITERUGINCOM, RP.ID_PERSONA, RRGP.ID_PARTE, RP.PER_JURIDICA, 'AC', SYSDATE
  FROM RUG_PERSONAS RP,
     RUG_REL_GARANTIA_PARTES RRGP
  WHERE RP.ID_PERSONA = RRGP.ID_PERSONA
    AND RRGP.ID_GARANTIA = peIdGarantia
    AND ID_RELACION = vlIdRelacion);


  UPDATE RUG_GARANTIAS
  SET ID_RELACION = vlIdRelacion
  WHERE ID_GARANTIA = peIdGarantia;

  COMMIT;



  psResult:=0;
  psTxResult:= 'ALTA EXITOSA';

  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_UPDATE_PARTES_TRANSMISION', 'psResult', psResult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_UPDATE_PARTES_TRANSMISION', 'psTxResult', psTxResult, 'OUT');



END;
/

