create PROCEDURE         SP_VALIDA_CURP 
( 
    peCURP       IN  VARCHAR,
    psResult            OUT  INTEGER,   
    psTxResult          OUT  VARCHAR2       
)
IS
vlRegExpCURP       VARCHAR(500) := '^([A-Z]{4})([0-9]{6})([A-Z]{6})([0-9]{2})$';
vlCountCurp        NUMBER;
Ex_ErrorCURP       EXCEPTION;

BEGIN

      psResult := NULL;
      psTxResult := NULL;

      SELECT REGEXP_COUNT(UPPER(peCURP), vlRegExpCURP)
      INTO vlCountCurp
      FROM DUAL;

      IF vlCountCurp = 0 THEN
        RAISE Ex_ErrorCURP;
      ELSIF vlCountCurp > 0 THEN
         psResult := 0;
         psTxResult := 'Validacion de CURP correcta';
      END IF;


  EXCEPTION 
  WHEN Ex_ErrorCURP THEN
      psResult := 28;
      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
  WHEN OTHERS THEN
      psResult := 999; 
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
END SP_VALIDA_CURP;
/

