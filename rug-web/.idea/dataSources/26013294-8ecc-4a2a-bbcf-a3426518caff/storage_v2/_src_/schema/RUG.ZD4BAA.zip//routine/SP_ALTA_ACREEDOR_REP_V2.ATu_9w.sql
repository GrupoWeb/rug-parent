create PROCEDURE             SP_ALTA_ACREEDOR_REP_V2                            (
                                peIdUsuario          IN  NUMBER,
                                peTipoPersona        IN  VARCHAR2,
                                IdTipo               IN  VARCHAR2, -- Sociedad Mercantil 'SM' o Otros 'OT'
                                peRazonSocial        IN  VARCHAR2,
                                peRFC                IN  VARCHAR2,
                                peCURP               IN  VARCHAR2,
                                peFolioMercantil     IN  VARCHAR2,
                                peCalle              IN  VARCHAR2,
                                peNumExt             IN  VARCHAR2,
                                peNumInt             IN  VARCHAR2,
                                peNombre             IN  VARCHAR2,
                                peApellidoP          IN  VARCHAR2,
                                peApellidoM          IN  VARCHAR2,
                                peIdColonia          IN  NUMBER,           
                                peIdLocalidad        IN  NUMBER,
                                peIdNacionalidad     IN  NUMBER,
                                peFechaInicio        IN  DATE,  -- Fecha Inicio del contrato
                                peFechaFin           IN  DATE,  -- Fecha Fin del contrato
                                peOtrosTerm          IN  VARCHAR2, -- Terminos y condiciones
                                peTipoContrato       IN  NUMBER,
                                peIdTramiteTemp      IN  NUMBER,
                                peTelefono           IN  VARCHAR2,
                                peExtension          IN  VARCHAR2,   
                                peEmail              IN  VARCHAR2,
                                peDomicilioUno       IN  VARCHAR2,
                                peDomicilioDos       IN  VARCHAR2, 
                                pePoblacion          IN  VARCHAR2,
                                peZonaPostal         IN  VARCHAR2,
                                pePaisResidencia     IN  NUMBER, 
                                peBandera            IN  CHAR,  -- TRUE = 1, FALSE = 0
                                peAfolExiste         IN  CHAR,  -- TRUE = 1, FALSE = 0
                                peNIFP               IN  VARCHAR2,  
								peInscrita			 IN  VARCHAR2,
								peFolioInscrito		 IN	 VARCHAR2,
								peLibroInscrito		 IN	 VARCHAR2,
								peUbicacionInscrito	 IN	 VARCHAR2,
								peEdad				 IN  VARCHAR2,
								peEstadoCivil		 IN  VARCHAR2,
								peProfesion			 IN	 VARCHAR2,
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2,   
                                psFolioElectronico  OUT  VARCHAR2, 
                                psIdPersonaInsertar OUT  NUMBER --ID DE LA PERSONA QUE SE VA A INSERTAR                                     
                            )
IS

vlExiste                NUMBER;
vlIdPersona             NUMBER;
vlIdDomicilio           NUMBER;
vlIdTramiteRugIncom     NUMBER;
vlIdContrato            NUMBER;
vlNumPartes             NUMBER;
vlGrupo                 NUMBER;
vlIdPerfil              NUMBER;
vlresult                NUMBER;
vlPerfil                VARCHAR(10);
vlTextResult            VARCHAR2(500);

vlCountCURPExiste       NUMBER;
vlCurp                  VARCHAR(25);

--VARIABLES VALIDACION RFC
vlPsResultValRFC        NUMBER;
vlPsTxtResultValRFC     VARCHAR(4000);

vlFolioElectronicoExist RUG_PERSONAS.Folio_Mercantil%TYPE;
vlFolioElecExist        NUMBER;
vlNvoFolioElectronico   VARCHAR(250);

--VARIABLES VALIDACION DE CURP
vlPsResultValCURP       NUMBER;
vlPsTxtResultValCURP    VARCHAR(4000);

--VARIABLES VALIDACION FOLIO ELECTRONICO
vlPsResultValFolio      NUMBER;
vlPsTxtResultValFolio   VARCHAR(4000);

--CURP
vlCountCurpRegExp NUMBER;

Ex_Error            EXCEPTION;
Ex_ErrRFC           EXCEPTION;
Ex_Texto    EXCEPTION;

BEGIN

    BEGIN
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2"', 'peIdUsuario', peIdUsuario, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peTipoPersona', peTipoPersona, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'IdTipo', IdTipo, 'IN');     
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peRazonSocial', peRazonSocial, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peRFC', peRFC, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peCURP', peCURP, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peFolioMercantil', peFolioMercantil, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peCalle', peCalle, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peNumExt', peNumExt, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peNumInt', peNumInt, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peNombre', peNombre, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peApellidoP', peApellidoP, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peApellidoM', peApellidoM, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peIdColonia', peIdColonia, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peIdLocalidad', peIdLocalidad, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peIdNacionalidad', peIdNacionalidad, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peFechaInicio', peFechaInicio, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peFechaFin', peFechaFin, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peOtrosTerm', peOtrosTerm, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peTipoContrato', peTipoContrato, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peTelefono', peTelefono, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peExtension', peExtension, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peEmail', peEmail, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peDomicilioUno', peDomicilioUno, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peDomicilioDos', peDomicilioDos, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'pePoblacion', pePoblacion, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peZonaPostal', peZonaPostal, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'pePaisResidencia', pePaisResidencia, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peBandera', peBandera, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peAfolExiste', peAfolExiste, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peNIFP', peNIFP, 'IN');
		REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peInscrita', peInscrita, 'IN');
		REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peFolioInscrito', peFolioInscrito, 'IN');
		REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peLibroInscrito', peLibroInscrito, 'IN');
		REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peUbicacionInscrito', peUbicacionInscrito, 'IN');
		REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peEdad', peEdad, 'IN');
		REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peEstadoCivil', peEstadoCivil, 'IN');
		REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peProfesion', peProfesion, 'IN');
    END;



    SELECT ID_GRUPO, ID_PERFIL, CVE_PERFIL
      INTO vlGrupo, vlIdPerfil, vlPerfil
      FROM V_USUARIO_SESION_RUG
     WHERE ID_PERSONA =  peIdUsuario;

    -- EL GRUPO 1 SE ASIGNA A LA RELACION DEL USUARIO CON EL ACREEDOR
    IF(vlIdPerfil != 4 OR vlGrupo != 15) THEN
        vlGrupo := 1;                        
    END IF;

    IF vlExiste = 1 THEN

        psResult := 115;
        RAISE Ex_Error;   

    END IF;

    --VALIDA QUE LA NACIONALIDAD SEA VALIDA
    SELECT COUNT(*)
      INTO vlresult
      FROM RUG_CAT_NACIONALIDADES
     WHERE ID_NACIONALIDAD = peIdNacionalidad;

    IF vlresult = 0 THEN

        psResult := 19;
        RAISE  Ex_Error;

    END IF;

    -- VALIDA EL PAIS DE RESIDENCIA 
    SELECT COUNT(*)
      INTO vlresult
      FROM RUG_CAT_NACIONALIDADES
     WHERE ID_NACIONALIDAD = pePaisResidencia;


    IF vlresult = 0 THEN

        psResult := 117;
        RAISE  Ex_Error;

    END IF;

   -- RFC ES OBLIGATORIO PARA PERSONAS MEXICANAS MENOS PARA SOCIEDAD MERCANTIL, PERSONA MORAL
    IF peIdNacionalidad = 1 AND (peRFC IS NULL OR peRFC = '') AND IdTipo <> 'SM' AND peBandera = 1 THEN

        vlPsResultValRFC := 110;
        vlPsTxtResultValRFC := RUG.FN_MENSAJE_ERROR(vlPsResultValRFC);

        RAISE Ex_ErrRFC;
    ELSIF peIdNacionalidad = 1 AND (peRFC IS NULL OR peRFC = '') AND IdTipo <> 'SM' AND peBandera = 0 THEN
        vlPsResultValRFC := 141;
        vlPsTxtResultValRFC := RUG.FN_MENSAJE_ERROR(vlPsResultValRFC);

        RAISE Ex_ErrRFC;
    END IF;


   --VALIDA RFC ACA valida ID?
    --RUG.SP_VALIDA_RFC(peIdNacionalidad, peRFC, peTipoPersona, vlPsResultValRFC, vlPsTxtResultValRFC);

    IF vlPsResultValRFC <> 0 THEN
        RAISE Ex_ErrRFC;
    END IF; 


   -- VALIDACIONES
    IF peIdUsuario IS NULL OR peTipoPersona IS NULL THEN

        psResult := 13;
        RAISE  Ex_Error;

    END IF;

    SELECT COUNT(*) 
      INTO vlNumPartes
      FROM RUG_REL_TRAM_INC_PARTES
     WHERE ID_TRAMITE_TEMP = peIdTramiteTemp AND ID_PARTE = 4 AND STATUS_REG = 'AC';

    IF vlNumPartes > 0 THEN

        psResult   :=29;
        RAISE Ex_Error;

    END IF;


   -- VALIDACION DEL FOLIO ELECTRONICOS EN PERSONA MORAL Y FISICA EXTRANJERA

		IF peTipoPersona = 'PF' AND (peFolioMercantil IS NULL OR TRIM(peFolioMercantil) = '')  THEN

               SELECT COUNT(FOLIO_MERCANTIL)
                 INTO vlFolioElecExist
                 FROM RUG.RUG_PERSONAS
                WHERE FOLIO_MERCANTIL = peFolioMercantil
                  AND ID_NACIONALIDAD = peIdNacionalidad;

                   IF vlFolioElecExist = 0 AND peBandera = 1 THEN

                        SP_GENERA_FOLIO_ELECTRONICO(vlNvoFolioElectronico, vlPsResultValFolio, vlPsTxtResultValFolio);

                        IF vlPsResultValFolio <> 0 THEN
                              psResult := vlPsResultValFolio;
                              psTxResult := vlPsTxtResultValFolio;
                              RAISE Ex_Error;
                        END IF; 

                   END IF;

          ELSIF peTipoPersona = 'PF' AND (peFolioMercantil IS NOT NULL OR TRIM(peFolioMercantil) <> '')  THEN

               SELECT COUNT(FOLIO_MERCANTIL)
                 INTO vlFolioElecExist
                 FROM RUG.RUG_PERSONAS
                WHERE FOLIO_MERCANTIL = peFolioMercantil
                  AND ID_NACIONALIDAD = peIdNacionalidad;

                   IF vlFolioElecExist =  0 THEN
                        psResult := 145;
                        psTxResult := RUG.FN_MENSAJE_ERROR(psResult);            

                        RAISE Ex_Error;   
                   END IF;

          END IF;




    vlIdDomicilio := SEQ_RUG_ID_DOMICILIO.NEXTVAL;

    IF(pePaisResidencia != 1) THEN

        INSERT INTO RUG.RUG_DOMICILIOS_EXT(ID_DOMICILIO, ID_PAIS_RESIDENCIA,UBICA_DOMICILIO_1, UBICA_DOMICILIO_2, POBLACION, ZONA_POSTAL)
        VALUES(vlIdDomicilio, pePaisResidencia, peDomicilioUno, peDomicilioDos, pePoblacion, peZonaPostal);

    ELSE            

        INSERT INTO RUG.RUG_DOMICILIOS_EXT(ID_DOMICILIO, ID_PAIS_RESIDENCIA,UBICA_DOMICILIO_1, UBICA_DOMICILIO_2, POBLACION, ZONA_POSTAL)
        VALUES(vlIdDomicilio, pePaisResidencia, peDomicilioUno, peDomicilioDos, pePoblacion, peZonaPostal);
        --INSERT INTO RUG_DOMICILIOS (ID_DOMICILIO, CALLE, NUM_EXTERIOR, NUM_INTERIOR, ID_COLONIA, ID_LOCALIDAD)
        --VALUES   (vlIdDomicilio, peCalle, peNumExt, peNumInt, DECODE(peIdColonia, -1, 0,peIdColonia), DECODE(peIdLocalidad,-1,0,peIdLocalidad));

    END IF;                


    vlIdPersona:= SEQ_RUG_ID_PERSONA.NEXTVAL;    


    IF(peFolioMercantil = '' OR peFolioMercantil IS NULL) THEN
             IF peAfolExiste <> 1 THEN
                                    psFolioElectronico := vlNvoFolioElectronico;
                            ELSE
                                 psFolioElectronico := vlFolioElectronicoExist;
                      END IF;
         ELSE    
        psFolioElectronico := peFolioMercantil;        
    END IF;






    INSERT INTO RUG_PERSONAS (ID_PERSONA, RFC, ID_NACIONALIDAD, PER_JURIDICA, FH_REGISTRO, PROCEDENCIA, SIT_PERSONA,
                                 CVE_NACIONALIDAD, ID_DOMICILIO, FOLIO_MERCANTIL, FECHA_INSCR_CC, REG_TERMINADO, E_MAIL, CURP_DOC, NIFP)
    VALUES   (vlIdPersona, peRFC, peIdNacionalidad, peTipoPersona, TRUNC(SYSDATE), 'NAL', 'AC', NULL, vlIdDomicilio, psFolioElectronico, NULL, 'N', peEmail, peCURP, peNIFP);

    psIdPersonaInsertar := vlIdPersona; 

    INSERT INTO RUG_TELEFONOS
    VALUES(vlIdPersona, NULL, peTelefono, peExtension, SYSDATE, 'AC'); 


    IF(UPPER(peTipoPersona) = 'PM') THEN


        IF peRazonSocial IS NULL OR peRazonSocial = '' THEN 

            psResult := 77;
            RAISE Ex_Error;

        END IF;


        INSERT INTO RUG_PERSONAS_MORALES (ID_PERSONA, RAZON_SOCIAL, TIPO, NUM_INSCRITA, FOLIO, LIBRO, UBICADA)
        VALUES   (vlIdPersona, peRazonSocial, IdTipo, peInscrita, peFolioInscrito, peLibroInscrito, peUbicacionInscrito);

		--Representante Legal
		INSERT INTO RUG_PERSONAS_FISICAS (ID_PERSONA, NOMBRE_PERSONA, AP_PATERNO, AP_MATERNO, CURP, EDAD, ESTADO_CIVIL, OCUPACION_ACTUAL)
        VALUES   (vlIdPersona, peNombre, peApellidoP, peApellidoM, peCURP, peEdad, peEstadoCivil, peProfesion);


    ELSIF (UPPER(peTipoPersona) = 'PF') THEN


        IF peNombre IS NULL OR peNombre = '' THEN

            psResult := 79;
            RAISE Ex_Error;

        END IF;

        INSERT INTO RUG_PERSONAS_FISICAS (ID_PERSONA, NOMBRE_PERSONA, AP_PATERNO, AP_MATERNO, CURP, EDAD, ESTADO_CIVIL, OCUPACION_ACTUAL)
        VALUES   (vlIdPersona, peNombre, peApellidoP, peApellidoM, peCURP, peEdad, peEstadoCivil, peProfesion);

    END IF;

    --vlIdTramiteRugIncom:= SEQ_TRAM_INCOMP.NEXTVAL;


    INSERT INTO REL_USU_ACREEDOR
    VALUES (peIdUsuario, vlIdPersona, 'N', SYSDATE, 'AC');


    INSERT INTO RUG_REL_GRUPO_ACREEDOR
    VALUES(SEQ_RUG_REL_PRIVILEGIO_ACREEDO.NEXTVAL, vlIdPersona, peIdUsuario, peIdUsuario, 'AC', SYSDATE, vlGrupo) ;


    vlIdContrato := SEQ_CONTRATO.NEXTVAL;


    INSERT INTO RUG_CONTRATO (ID_CONTRATO, FECHA_INICIO, FECHA_FIN, OTROS_TERMINOS_CONTRATO, TIPO_CONTRATO, 
                        ID_TRAMITE_TEMP, FECHA_REG, STATUS_REG, ID_USUARIO)
    VALUES(vlIdContrato, peFechaInicio, peFechaFin, peOtrosTerm, peTipoContrato, peIdTramiteTemp, SYSDATE, 'AC', peIdUsuario);


    INSERT INTO RUG_REL_TRAM_INC_PARTES
    VALUES (peIdTramiteTemp, vlIdPersona, 4, peTipoPersona, 'AC', SYSDATE);


    SP_ALTA_BITACORA_TRAMITE2(peIdTramiteTemp, 5, 0, sysdate, 'F', vlresult, vlTextResult);

    IF vlresult != 0 THEN

        psResult   := vlresult;
        psTxResult := vlTextResult;            

        RAISE Ex_Error;

    END IF;

    COMMIT;


    psResult   :=0;        
    psTxResult :='Actualizacion finalizada satisfactoriamente';

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'psFolioElectronico', psFolioElectronico, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION
WHEN Ex_ErrRFC  THEN
      psResult := vlPsResultValRFC;
      psTxResult := vlPsTxtResultValRFC;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;

WHEN Ex_Texto  THEN
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'peIdUsuario', peIdUsuario, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;

WHEN Ex_Error  THEN

      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;


WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_ACREEDOR_REP_V2', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;

END SP_ALTA_ACREEDOR_REP_V2;
/

