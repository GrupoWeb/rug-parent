create FUNCTION         FN_VALIDA_MISMO_OTORGANTE (peIdTramite NUMBER, 
                                                          peIdPersona NUMBER)
   RETURN VARCHAR2
IS
   vlCountPartes     NUMBER;
   vlIdOtorgante     NUMBER;
   vlCountDeudores   NUMBER;
   vlResultado       CHAR(2);
BEGIN

   BEGIN
      SELECT   COUNT (RRT.ID_PERSONA)
        INTO   vlCountPartes
        FROM   RUG_REL_TRAM_PARTES RRT
       WHERE   ID_TRAMITE = peIdTramite 
         AND   ID_PERSONA = peIdPersona
         AND   ID_PARTE IN (1, 2); 

      IF vlCountPartes < 2
      THEN
         vlResultado := 'NO';
      ELSE

         SELECT   ID_PERSONA
           INTO   vlIdOtorgante
           FROM   RUG_REL_TRAM_PARTES
          WHERE   ID_TRAMITE = peIdTramite
            AND   ID_PERSONA = peIdPersona 
            AND   ID_PARTE = 1;

         SELECT   COUNT(ID_PERSONA)
           INTO   vlCountDeudores
           FROM   RUG_REL_TRAM_PARTES
          WHERE       ID_TRAMITE = peIdTramite
                  AND ID_PARTE = 2
                  AND ID_PERSONA = vlIdOtorgante;

         IF vlCountDeudores = 0
         THEN
            vlResultado := 'NO';
         ELSE
           vlResultado := 'SI';   
         END IF;
      END IF;
   END;

   RETURN vlResultado;
   EXCEPTION

   WHEN OTHERS THEN
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_VALIDA_MISMO_OTORGANTE', 'psResult', 999, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FN_VALIDA_MISMO_OTORGANTE', 'psTxResult', (substr(SQLCODE||':'||SQLERRM,1,250)), 'OUT');
END;
/

