create PROCEDURE     HOMOLOGAR_NUEVO_A_MIGRADO (pEmailNuevo IN VARCHAR2, pEmailMigrado IN VARCHAR2, pCausa IN VARCHAR2) IS
	v_id_persona_nuevo NUMBER;
	v_id_persona_migrado NUMBER;
	old_fecha_reg_rga DATE;
	old_fecha_reg_ua DATE;
	old_cve_institucion_spu VARCHAR2(10);
	old_cve_usuario_spu VARCHAR2(256);
	old_cve_institucion VARCHAR2(10);
	old_cve_usuario VARCHAR2(256);
	old_password VARCHAR2(256);
	old_f_asigna_psw DATE;
	old_preg_recupera_psw VARCHAR2(60);
	old_resp_recupera_psw VARCHAR2(60);
	old_fh_registro_su DATE;
	old_cve_acreedor VARCHAR2(256);
	old_nombre_persona VARCHAR2(255);
	old_curp VARCHAR2(900);
	old_rfc VARCHAR2(20);
	old_per_juridica VARCHAR2(2);
	old_fh_registro DATE;
	old_curp_doc VARCHAR2(500);
	old_codigo_registro NUMBER;
BEGIN
	-- obtener id_persona de usuario nuevo
	SELECT id_persona
	INTO v_id_persona_nuevo
    FROM rug_secu_usuarios
	WHERE LOWER(cve_usuario) = pEmailNuevo;

	-- obtener id_persona de usuario migrado
	SELECT id_persona
	INTO v_id_persona_migrado
    FROM rug_secu_usuarios
	WHERE LOWER(cve_usuario) = pEmailMigrado;

	-- obtener informacion de usuario antiguo
	SELECT fecha_reg INTO old_fecha_reg_rga FROM rug_rel_grupo_acreedor WHERE id_usuario = v_id_persona_migrado;
	SELECT fecha_reg INTO old_fecha_reg_ua FROM rel_usu_acreedor WHERE id_usuario = v_id_persona_migrado;
	SELECT cve_institucion, cve_usuario INTO old_cve_institucion_spu, old_cve_usuario_spu FROM rug_secu_perfiles_usuario WHERE id_persona = v_id_persona_migrado;
	SELECT cve_institucion, cve_usuario, password, f_asigna_psw, preg_recupera_psw, resp_recupera_psw, fh_registro, cve_acreedor INTO old_cve_institucion, old_cve_usuario, old_password, old_f_asigna_psw, old_preg_recupera_psw, old_resp_recupera_psw, old_fh_registro_su, old_cve_acreedor FROM rug_secu_usuarios WHERE id_persona = v_id_persona_migrado;
	SELECT nombre_persona, curp INTO old_nombre_persona, old_curp FROM rug_personas_fisicas WHERE id_persona = v_id_persona_migrado;
	SELECT rfc, per_juridica, fh_registro, curp_doc, codigo_registro INTO old_rfc, old_per_juridica, old_fh_registro, old_curp_doc, old_codigo_registro FROM rug_personas WHERE id_persona = v_id_persona_migrado;

	-- cambiar correo de usuario nuevo por uno temporal
	UPDATE rug_secu_perfiles_usuario
	SET cve_usuario = pEmailNuevo || '_TEMP'
	WHERE id_persona = v_id_persona_nuevo;

	UPDATE rug_secu_usuarios
	SET cve_usuario = pEmailNuevo || '_TEMP'
	WHERE id_persona = v_id_persona_nuevo;

	-- copiar informacion de usuario nuevo a usuario migrado
	UPDATE rug_rel_grupo_acreedor
	SET fecha_reg = (
		SELECT fecha_reg
		FROM rug_rel_grupo_acreedor
		WHERE id_usuario = v_id_persona_nuevo
	)
	WHERE id_usuario = v_id_persona_migrado;

	UPDATE rel_usu_acreedor
	SET fecha_reg = (
		SELECT fecha_reg
		FROM rel_usu_acreedor
		WHERE id_usuario = v_id_persona_nuevo
	)
	WHERE id_usuario = v_id_persona_migrado;

	UPDATE rug_secu_perfiles_usuario
	SET (cve_institucion, cve_usuario) = (
		SELECT cve_institucion, pEmailNuevo
		FROM rug_secu_perfiles_usuario
		WHERE id_persona = v_id_persona_nuevo
	)
	WHERE id_persona = v_id_persona_migrado;

	UPDATE rug_secu_usuarios
	SET (cve_institucion, cve_usuario, password, f_asigna_psw, preg_recupera_psw, resp_recupera_psw, fh_registro, cve_acreedor) = (
		SELECT cve_institucion, pEmailNuevo, password, f_asigna_psw, preg_recupera_psw, resp_recupera_psw, fh_registro, cve_acreedor
		FROM rug_secu_usuarios
		WHERE id_persona = v_id_persona_nuevo
	)
	WHERE id_persona = v_id_persona_migrado;

	UPDATE rug_personas_fisicas
	SET (nombre_persona, curp) = (
		SELECT nombre_persona, curp
		FROM rug_personas_fisicas
		WHERE id_persona = v_id_persona_nuevo
	)
	WHERE id_persona = v_id_persona_migrado;

	UPDATE rug_personas
	SET (rfc, per_juridica, fh_registro, curp_doc, codigo_registro) = (
		SELECT rfc, per_juridica, fh_registro, curp_doc, codigo_registro
		FROM rug_personas
		WHERE id_persona = v_id_persona_nuevo
	)
	WHERE id_persona = v_id_persona_migrado;

	-- copiar informacion de usuario migrado a usuario nuevo
	UPDATE rug_rel_grupo_acreedor
	SET fecha_reg = old_fecha_reg_rga
	WHERE id_usuario = v_id_persona_nuevo;

	UPDATE rel_usu_acreedor
	SET fecha_reg = old_fecha_reg_ua
	WHERE id_usuario = v_id_persona_nuevo;

	UPDATE rug_secu_perfiles_usuario
	SET cve_institucion = old_cve_institucion_spu,
		cve_usuario = old_cve_usuario_spu
	WHERE id_persona = v_id_persona_nuevo;

	UPDATE rug_secu_usuarios
	SET cve_institucion = old_cve_institucion, 
		cve_usuario = old_cve_usuario, 
		password = old_password, 
		f_asigna_psw = old_f_asigna_psw, 
		preg_recupera_psw = old_preg_recupera_psw, 
		resp_recupera_psw = old_resp_recupera_psw, 
		fh_registro = old_fh_registro_su, 
		cve_acreedor = old_cve_acreedor
	WHERE id_persona = v_id_persona_nuevo;

	UPDATE rug_personas_fisicas
	SET nombre_persona = old_nombre_persona, 
		curp = old_curp
	WHERE id_persona = v_id_persona_nuevo;

	UPDATE rug_personas
	SET rfc = old_rfc, 
		per_juridica = old_per_juridica, 
		fh_registro = old_fh_registro, 
		curp_doc = old_curp_doc, 
		codigo_registro = old_codigo_registro
	WHERE id_persona = v_id_persona_nuevo;

	-- actualizar rechazo_cuenta
	UPDATE rechazo_cuenta SET id_persona = v_id_persona_migrado WHERE id_persona = v_id_persona_nuevo;

	INSERT INTO RUG.HOMOLOGADO(HOMOLOGADO_ID, ID_PERSONA_MIGRACION, ID_PERSONA_RUG, CAUSA, FECHA)
	VALUES(SEQ_HOMOLOGADO.NEXTVAL, v_id_persona_migrado, v_id_persona_nuevo, pCausa, SYSDATE);

	-- inactivar usuario nuevo
	UPDATE rug_rel_grupo_acreedor SET status_reg = 'HO' WHERE id_usuario = v_id_persona_nuevo;
	UPDATE rel_usu_acreedor SET status_reg = 'HO' WHERE id_usuario = v_id_persona_nuevo;
	UPDATE rug_secu_usuarios SET sit_usuario = 'HO' WHERE id_persona = v_id_persona_nuevo;
	UPDATE rug_personas SET sit_persona = 'HO' WHERE id_persona = v_id_persona_nuevo;

	COMMIT;

END;
/

