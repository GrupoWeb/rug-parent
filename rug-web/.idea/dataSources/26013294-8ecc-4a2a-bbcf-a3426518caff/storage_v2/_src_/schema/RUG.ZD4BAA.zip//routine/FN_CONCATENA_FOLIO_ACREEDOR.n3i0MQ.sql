create FUNCTION         FN_CONCATENA_FOLIO_ACREEDOR (peIdFirmaMasiva NUMBER)
   RETURN VARCHAR2
IS
   vlFolio1         VARCHAR2(100);
   vlFolio2         VARCHAR2(100);
   vlCantidad       NUMBER;
   vlIdTipoTramite  NUMBER;

BEGIN


    SELECT COUNT(*)
      INTO vlCantidad
      FROM RUG_FIRMA_MASIVA
     WHERE ID_FIRMA_MASIVA = peIdFirmaMasiva;



    SELECT DISTINCT B.ID_TIPO_TRAMITE
      INTO vlIdTipoTramite    
      FROM RUG_FIRMA_MASIVA A,
           TRAMITES_RUG_INCOMP B
     WHERE A.ID_TRAMITE_TEMP = B.ID_TRAMITE_TEMP;



    IF vlIdTipoTramite = 12 THEN

            SELECT FOLIO_MERCANTIL 
              INTO vlFolio1
              FROM (
                    SELECT RFM.ID_TRAMITE_TEMP, RP.FOLIO_MERCANTIL
                      FROM RUG_FIRMA_MASIVA RFM,
                           RUG_REL_TRAM_INC_PARTES RTP,
                           RUG_PERSONAS RP
                     WHERE 1 = 1
                       AND RTP.ID_PARTE = 4
                       AND RP.ID_PERSONA = RTP.ID_PERSONA
                       AND RTP.ID_TRAMITE_TEMP = RFM.ID_TRAMITE_TEMP
                       AND RFM.ID_FIRMA_MASIVA = peIdFirmaMasiva
                       ORDER BY 1
                   ) WHERE ROWNUM = 1;


            IF vlCantidad > 1 THEN


                 SELECT FOLIO_MERCANTIL
                   INTO vlFolio2
                   FROM (
                            SELECT RFM.ID_TRAMITE_TEMP, RP.FOLIO_MERCANTIL
                              FROM RUG_FIRMA_MASIVA RFM,
                                   RUG_REL_TRAM_INC_PARTES RTP,
                                   RUG_PERSONAS RP
                             WHERE 1 = 1
                               AND RTP.ID_PARTE = 4
                               AND RP.ID_PERSONA = RTP.ID_PERSONA
                               AND RTP.ID_TRAMITE_TEMP = RFM.ID_TRAMITE_TEMP
                               AND RFM.ID_FIRMA_MASIVA = peIdFirmaMasiva
                               ORDER BY 1
                         ) WHERE ROWNUM = 1;                

                IF vlFolio1 = '' OR vlFolio1 IS NULL THEN

                    vlFolio1 := vlFolio2;

                ELSIF vlFolio2 = '' OR vlFolio2 IS NULL THEN

                    vlFolio1 := vlFolio1;

                ELSE

                    vlFolio1 := vlFolio1 || ' ... ' || vlFolio2;

                END IF;         



            END IF;


    ELSE


         SELECT CVE_RASTREO 
           INTO vlFolio1
           FROM (
                  SELECT B.CVE_RASTREO
                    FROM RUG_FIRMA_MASIVA A,
                         RUG_TRAMITE_RASTREO B
                   WHERE A.ID_TRAMITE_TEMP = B.ID_TRAMITE_TEMP
                     AND ID_FIRMA_MASIVA = 364151
                       ORDER BY A.ID_TRAMITE_TEMP
                )WHERE ROWNUM < 2;

         IF vlCantidad > 1 THEN       

             SELECT CVE_RASTREO
               INTO vlFolio2
               FROM (
                      SELECT B.CVE_RASTREO
                        FROM RUG_FIRMA_MASIVA A,
                             RUG_TRAMITE_RASTREO B
                       WHERE A.ID_TRAMITE_TEMP = B.ID_TRAMITE_TEMP
                         AND ID_FIRMA_MASIVA = 364151
                           ORDER BY A.ID_TRAMITE_TEMP DESC
                    )WHERE ROWNUM < 2;

            vlFolio1 := vlFolio1 || ' ... ' || vlFolio2;              

         END IF;




    END IF;


    RETURN vlFolio1;

END;
/

