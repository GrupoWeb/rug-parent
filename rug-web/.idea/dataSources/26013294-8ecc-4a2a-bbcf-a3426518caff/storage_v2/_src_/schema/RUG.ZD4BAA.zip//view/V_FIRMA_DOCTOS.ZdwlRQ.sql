create view V_FIRMA_DOCTOS as
SELECT FD."ID_FIRMA",
          FM."ID_TRAMITE_TEMP",
          FD."ID_USUARIO_FIRMO",
          FD."XML_CO",
          FD."CO_USUAIRO",
          FD."CERTIFICADO_USUARIO_B64",
          FD."FIRMA_USUARIO_B64",
          FD."CO_SELLO",
          FD."SELLO_TS_B64",
          FD."CO_FIRMA_RUG",
          FD."FIRMA_RUG_B64",
          FD."FECHA_REG",
          FD."STATUS_REG",
          FD."CERTIFICADO_CENTRAL_B64",
          FD."PROCESADO"
     FROM    RUG.RUG_FIRMA_DOCTOS FD
          INNER JOIN
             RUG.RUG_FIRMA_MASIVA FM
          ON FD.ID_TRAMITE_TEMP = FM.ID_TRAMITE_TEMP          
   UNION ALL
   SELECT "ID_FIRMA",
          "ID_TRAMITE_TEMP",
          "ID_USUARIO_FIRMO",
          "XML_CO",
          "CO_USUAIRO",
          "CERTIFICADO_USUARIO_B64",
          "FIRMA_USUARIO_B64",
          "CO_SELLO",
          "SELLO_TS_B64",
          "CO_FIRMA_RUG",
          "FIRMA_RUG_B64",
          "FECHA_REG",
          "STATUS_REG",
          "CERTIFICADO_CENTRAL_B64",
          "PROCESADO"
     FROM RUG.RUG_FIRMA_DOCTOS FD
    WHERE FD.ID_TRAMITE_TEMP NOT IN
             (SELECT ID_TRAMITE_TEMP FROM RUG.RUG_FIRMA_MASIVA)
/

