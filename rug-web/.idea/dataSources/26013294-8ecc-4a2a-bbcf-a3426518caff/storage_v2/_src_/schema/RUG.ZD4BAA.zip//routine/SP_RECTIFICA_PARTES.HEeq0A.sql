create PROCEDURE           SP_RECTIFICA_PARTES (
                                                    peIdGarantia        IN  NUMBER,
                                                    peIdPersona         IN  NUMBER,
                                                    peIdParte           IN  NUMBER,
                                                    psResult           OUT  NUMBER,
                                                    psTxResult         OUT  VARCHAR2                                                                                                        
                                               )
IS

vlCantidad NUMBER;
vlRelacion NUMBER;  

BEGIN

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RECTIFICA_PARTES', 'peIdGarantia', peIdGarantia, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RECTIFICA_PARTES', 'peIdPersona', peIdPersona, 'IN');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RECTIFICA_PARTES', 'peIdParte', peIdParte, 'IN');

  BEGIN
      SELECT COUNT(*) 
      INTO vlCantidad
      FROM RUG_REL_GARANTIA_PARTES
      WHERE ID_GARANTIA = peIdGarantia
      AND ID_PARTE = peIdParte
      AND ID_PERSONA = peIdPersona;
      EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                     DBMS_OUTPUT.PUT_LINE('La garantia no existe');
  END;               


  IF (vlCantidad > 0 ) THEN  

      vlRelacion := SEQ_RELACIONES.NEXTVAL;


      INSERT INTO RUG_REL_GARANTIA_PARTES
      VALUES (peIdGarantia, peIdPersona, peIdParte, vlRelacion, SYSDATE, 'AC');


      UPDATE RUG_GARANTIAS
      SET ID_RELACION = vlRelacion
      WHERE ID_GARANTIA = peIdGarantia
      AND ID_PERSONA = peIdPersona;


      COMMIT;

      psResult:=0;   
      psTxResult:= 'ACTUALIZACION EXITOSA';   


  END IF;


REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RECTIFICA_PARTES', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_RECTIFICA_PARTES', 'psTxResult', psTxResult, 'OUT');  

END;
/

