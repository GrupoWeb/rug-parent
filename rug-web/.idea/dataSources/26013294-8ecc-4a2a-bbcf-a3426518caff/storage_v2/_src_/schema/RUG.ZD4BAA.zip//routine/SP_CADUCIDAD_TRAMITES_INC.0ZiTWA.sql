create PROCEDURE         SP_CADUCIDAD_TRAMITES_INC
                            (
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )
IS
                        
vlIdTramiteTemp NUMBER;
vlResult        Number; 
vlTxResult      Varchar2(2000 Byte);

CURSOR cursTramitesTemp IS
SELECT ID_TRAMITE_TEMP
FROM V_TRAMITES_PENDIENTES
WHERE ID_STATUS = 1            
AND   FECHA_STATUS < (SYSDATE - 4)
AND   TRAMITE_REASIGNADO = 'F'
;

BEGIN

    BEGIN

        OPEN cursTramitesTemp;
            LOOP
                FETCH cursTramitesTemp INTO vlIdTramiteTemp;
                EXIT WHEN cursTramitesTemp%NOTFOUND;

                SP_BAJA_TRAMITE_INCOMP(vlIdTramiteTemp,vlResult,vlTxResult);

                COMMIT;
            END LOOP;

        CLOSE cursTramitesTemp;

        psResult:= 0;
        psTxResult:= 'Finalizo exitosamente el proceso';
    EXCEPTION
    WHEN NO_DATA_FOUND THEN           
            REG_PARAM_PLS (RUG.SEQ_RUG_PARAM_PLS.NEXTVAL,'SP_CADUCIDAD_TRAMITES_INC', 'psResult',777, 'OUT');  
            REG_PARAM_PLS (RUG.SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CADUCIDAD_TRAMITES_INC','psTxResult', 'NO HAY TRAMITES INCOMPLETOS VENCIDOS', 'OUT');         
    END;


EXCEPTION
   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CADUCIDAD_TRAMITES_INC', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CADUCIDAD_TRAMITES_INC', 'psTxResult', psTxResult, 'OUT');
END SP_CADUCIDAD_TRAMITES_INC;
/

