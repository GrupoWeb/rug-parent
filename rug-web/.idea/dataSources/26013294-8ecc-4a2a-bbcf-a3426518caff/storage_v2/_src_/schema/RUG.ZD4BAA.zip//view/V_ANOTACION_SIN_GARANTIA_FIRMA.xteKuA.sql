create view V_ANOTACION_SIN_GARANTIA_FIRMA as
SELECT   RBT.ID_TRAMITE_TEMP,
            RASG.ID_PERSONA,
            DECODE (
               RP.PER_JURIDICA,
               'PF',
               (SELECT      F.NOMBRE_PERSONA
                         || ' '
                         || F.AP_PATERNO
                         || ' '
                         || F.AP_MATERNO
                  FROM   RUG_PERSONAS_FISICAS F
                 WHERE   F.ID_PERSONA = RP.ID_PERSONA),
               'PM',
               (SELECT   M.RAZON_SOCIAL
                  FROM   RUG_PERSONAS_MORALES M
                 WHERE   M.ID_PERSONA = RP.ID_PERSONA)
            )
               NOMBRE,
            RP.PER_JURIDICA,
            RP.RFC,
            RASG.ID_ANOTACION,
            RASG.ANOTACION,
            RASG.AUTORIDAD_AUTORIZA,
            (RD.CALLE || ' ' || RD.NUM_EXTERIOR || ' ' || RD.NUM_INTERIOR)
               DOMICILIO,
            VD.ID_COLONIA,
            VD.NOM_COLONIA,
            VD.ID_LOCALIDAD,
            VD.LOCALIDAD,
            VD.NOM_DELEG_MUNICIP,
            VD.CVE_ESTADO,
            VD.NOM_ESTADO,
            VD.CODIGO_POSTAL,
            VD.CVE_PAIS,
            VD.NOM_PAIS
     FROM   RUG_BITAC_TRAMITES RBT,
            RUG_ANOTACIONES_SIN_GARANTIA RASG,
            TRAMITES_RUG_INCOMP TRI,
            RUG_PERSONAS RP,
            RUG_DOMICILIOS RD,
            V_DOMICILIOS VD
    WHERE       RBT.ID_TRAMITE_TEMP = RASG.ID_TRAMITE_TEMP
            AND TRI.ID_TRAMITE_TEMP = RASG.ID_TRAMITE_TEMP
            AND TRI.ID_PERSONA = RASG.ID_PERSONA
            AND RP.ID_PERSONA = RASG.ID_PERSONA
            AND RD.ID_DOMICILIO = RP.ID_DOMICILIO
            AND VD.ID_DOMICILIO = RP.ID_DOMICILIO
            AND RBT.ID_STATUS = 5
            AND RASG.ID_TRAMITE_TEMP NOT IN
                     (SELECT   ID_TRAMITE_TEMP
                        FROM   TRAMITES
                       WHERE   ID_TRAMITE_TEMP = RASG.ID_TRAMITE_TEMP)
/

