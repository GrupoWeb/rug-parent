create view V_REP_SOLICITUD_GTIAS as
SELECT   FECHA,
              SUM (DECODE (TIPO, 1, 1, 0)) SOLICITUDES,
              SUM (DECODE (TIPO, 2, 1, 0)) GARANTIAS_INSCRITAS,
              SUM (DECODE (TIPO, 3, 1, 0)) AVISOS_PREVENTIVOS,
              SUM (DECODE (TIPO, 4, 1, 0)) MODIFICACIONES,
              SUM (DECODE (TIPO, 5, 1, 0)) TRANSMISIONES,
              SUM (DECODE (TIPO, 6, 1, 0)) RECTIFICACION_POR_ERROR,
              SUM (DECODE (TIPO, 7, 1, 0)) RENOVACIONES,
              SUM (DECODE (TIPO, 8, 1, 0)) CANCELACIONES,
              SUM (DECODE (TIPO, 9, 1, 0)) ANOTACIONES,
              SUM (DECODE (TIPO, 10, 1, 0)) ALTA_ACREEDOR, --Gabriela quevedo 10032011
              SUM (DECODE (TIPO, 11, 1, 0)) CERTIFICACIONES,
              SUM (DECODE (TIPO, 12, 1, 0)) USUARIOS_CIUDADANOS,
              SUM (DECODE (TIPO, 14, 1, 0)) USUARIOS_ACREEDORES,
              SUM (DECODE (TIPO, 13, 1, 0)) USUARIOS_AUTORIDADES,
              SUM (DECODE (TIPO, 2, 1, 8, -1, 0)) INSCRIPCIONES_ACTIVAS
       FROM   (SELECT   1 TIPO, TRUNC (FECHA_STATUS) FECHA, 0 total -- SOLICITUDES
                 FROM   RUG.RUG_BITAC_TRAMITES
                WHERE   ID_TIPO_TRAMITE IN (1, 3, 7, 8, 6, 9, 4, 2, 10, 12, 5) -- Gabriela Quevedo 06122010
                        AND ID_STATUS = 3         -- Gabriela Quevedo 06122010
                        AND STATUS_REG = 'AC'     -- Gabriela Quevedo 06122010
               UNION ALL
               SELECT   2 TIPO, TRUNC (FECHA_STATUS), 0 total      --GARANTIAS
                 FROM   RUG.RUG_BITAC_TRAMITES
                WHERE       ID_TIPO_TRAMITE = 1
                        AND STATUS_REG = 'AC'
                        AND ID_STATUS = 3
               UNION ALL
               SELECT   3 TIPO, TRUNC (FECHA_STATUS), 0 total --AVISOS PREVENTIVOS
                 FROM   RUG.RUG_BITAC_TRAMITES
                WHERE       ID_TIPO_TRAMITE = 3
                        AND STATUS_REG = 'AC'
                        AND ID_STATUS = 3
               UNION ALL
               SELECT   4 TIPO, TRUNC (FECHA_STATUS), 0 total -- MODIFICACIONES
                 FROM   RUG.RUG_BITAC_TRAMITES
                WHERE       ID_TIPO_TRAMITE = 7
                        AND STATUS_REG = 'AC'
                        AND ID_STATUS = 3
               UNION ALL
               SELECT   5 TIPO, TRUNC (FECHA_STATUS), 0 total -- TRANSMISIONES,
                 FROM   RUG.RUG_BITAC_TRAMITES
                WHERE       ID_TIPO_TRAMITE = 8
                        AND STATUS_REG = 'AC'
                        AND ID_STATUS = 3
               UNION ALL
               SELECT   6 TIPO, TRUNC (FECHA_STATUS), 0 total -- RECTIFICACION_POR_ERROR,
                 FROM   RUG.RUG_BITAC_TRAMITES
                WHERE       ID_TIPO_TRAMITE = 6
                        AND STATUS_REG = 'AC'
                        AND ID_STATUS = 3
               UNION ALL
               SELECT   7 TIPO, TRUNC (FECHA_STATUS), 0 total -- RENOVACIONES,
                 FROM   RUG.RUG_BITAC_TRAMITES
                WHERE       ID_TIPO_TRAMITE = 9
                        AND STATUS_REG = 'AC'
                        AND ID_STATUS = 3
               UNION ALL
               SELECT   8 TIPO, TRUNC (FECHA_STATUS), 0 total -- CANCELACIONES
                 FROM   RUG.RUG_BITAC_TRAMITES
                WHERE       ID_TIPO_TRAMITE = 4
                        AND STATUS_REG = 'AC'
                        AND ID_STATUS = 3
               UNION ALL
               SELECT   9 TIPO, TRUNC (FECHA_STATUS), 0 total   -- ANOTACIONES
                 FROM   RUG.RUG_BITAC_TRAMITES
                WHERE       ID_TIPO_TRAMITE IN (2, 10)
                        AND STATUS_REG = 'AC'
                        AND ID_STATUS = 3
               UNION ALL
                 --  --Gabriela quevedo 10032011
                 SELECT   10 tipo, TRUNC (MIN (FECHA_STATUS)) FECHA, 0 total
                   FROM   V_REP_BASE_ACREEDORES
                  WHERE   REGEXP_SUBSTR (RFC_ACREEDOR, '^AAA[0|1]{6}') IS NULL
                          AND RFC_ACREEDOR IS NOT NULL
               GROUP BY   RFC_ACREEDOR
               UNION ALL
                 SELECT   10 tipo, TRUNC (MIN (FECHA_STATUS)) FECHA, 0 total
                   FROM   V_REP_BASE_ACREEDORES
                  WHERE   (REGEXP_SUBSTR (RFC_ACREEDOR, '^AAA[0|1]{6}') IS NOT NULL
                           OR RFC_ACREEDOR IS NULL)
               GROUP BY   TRIM (NOMBRE_ACREEDOR)
               UNION ALL
               -- Gabriela Quevedo 06122010
               SELECT   11 TIPO, TRUNC (FECHA_STATUS) FECHA, 0 total -- certificaciones
                 FROM   RUG.RUG_BITAC_TRAMITES
                WHERE       ID_TIPO_TRAMITE = 5
                        AND ID_STATUS = 3
                        AND STATUS_REG = 'AC'
               /*
               SELECT   11 TIPO, TRUNC (FECHA_CERT)    -- CIIUDADANOS  COUNT (
                 FROM   RUG.RUG_CERTIFICACIONES
                 */
               UNION ALL
               SELECT   12 TIPO, TRUNC (RSU.FH_REGISTRO), 0 total -- CIIUDADANOS
                 FROM   RUG.RUG_SECU_PERFILES_USUARIO RSP,
                        RUG.RUG_SECU_USUARIOS RSU
                WHERE   RSP.ID_PERSONA = RSU.ID_PERSONA
                        AND RSP.CVE_PERFIL = 'CIUDADANO'
                        AND RSU.FH_REGISTRO >=
                              TO_DATE ('07/10/2010', 'DD/MM/YYYY')
               UNION ALL
               SELECT   13 TIPO, TRUNC (RSU.FH_REGISTRO), 0 total -- AUTORIDADES
                 FROM   RUG.RUG_SECU_PERFILES_USUARIO RSP,
                        RUG.RUG_SECU_USUARIOS RSU
                WHERE   RSP.ID_PERSONA = RSU.ID_PERSONA
                        AND RSP.CVE_PERFIL = 'AUTORIDAD'
                        AND RSU.FH_REGISTRO >=
                              TO_DATE ('07/10/2010', 'DD/MM/YYYY')
               UNION ALL
               SELECT   14 TIPO, TRUNC (RSU.FH_REGISTRO), 0 total -- ACREEDORES
                 FROM   RUG.RUG_SECU_PERFILES_USUARIO RSP,
                        RUG.RUG_SECU_USUARIOS RSU
                WHERE   RSP.ID_PERSONA = RSU.ID_PERSONA
                        AND RSP.CVE_PERFIL = 'ACREEDOR'
                        AND RSU.FH_REGISTRO >=
                              TO_DATE ('07/10/2010', 'DD/MM/YYYY'))
   GROUP BY   FECHA
/

