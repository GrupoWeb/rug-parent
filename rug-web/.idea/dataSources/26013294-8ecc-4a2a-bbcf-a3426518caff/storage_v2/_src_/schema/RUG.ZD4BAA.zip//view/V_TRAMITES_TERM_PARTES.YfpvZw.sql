create view V_TRAMITES_TERM_PARTES as
SELECT RTP.ID_TRAMITE ID_TRAMITE,
          RTP.ID_PERSONA,
          RTP.ID_PARTE,
          RGP.DESC_PARTE,
          RTP.PER_JURIDICA,
          DECODE (
             RTP.PER_JURIDICA,
             'PF', (SELECT    NOMBRE_PERSONA
                           || ' '
                           || AP_PATERNO
                           || ' '
                           || AP_MATERNO
                      FROM RUG_PERSONAS_FISICAS
                     WHERE ID_PERSONA = RTP.ID_PERSONA),
             'PM', (SELECT RAZON_SOCIAL
                      FROM RUG_PERSONAS_MORALES
                     WHERE ID_PERSONA = RTP.ID_PERSONA))
             AS NOMBRE,
          RPP.FOLIO_MERCANTIL,
          RPP.RFC,
          RPP.CURP_DOC CURP
     FROM RUG_REL_TRAM_PARTES RTP
          INNER JOIN RUG_PARTES RGP
             ON RTP.ID_PARTE = RGP.ID_PARTE
          INNER JOIN RUG_PERSONAS RPP
             ON RTP.ID_PERSONA = RPP.ID_PERSONA
    WHERE RTP.STATUS_REG = 'AC'
/

