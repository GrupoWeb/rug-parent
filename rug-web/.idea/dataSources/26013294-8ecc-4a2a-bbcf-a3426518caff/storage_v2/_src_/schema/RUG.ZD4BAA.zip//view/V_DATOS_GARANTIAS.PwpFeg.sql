create view V_DATOS_GARANTIAS as
SELECT   RGG.ID_GARANTIA_PEND AS ID_GARANTIA,
            RCT.DESC_TIPO_GARANTIA AS TIPO_GARANTIA,
            CASE
               WHEN TTR.ID_TIPO_TRAMITE IN (4, 9, 8)
               THEN
                  (SELECT   FECHA_INSCR
                     FROM   RUG_GARANTIAS
                    WHERE   ID_GARANTIA = RGG.ID_GARANTIA_MODIFICAR)
               ELSE
                  RGG.FECHA_INSCR
            END
               AS FECHA_CELEB_ACTO,
            CASE
               WHEN TTR.ID_TIPO_TRAMITE IN (4, 9, 8)
               THEN
                  (SELECT   MONTO_MAXIMO_GARANTIZADO
                     FROM   RUG_GARANTIAS
                    WHERE   ID_GARANTIA = RGG.ID_GARANTIA_MODIFICAR)
               ELSE
                  RGG.MONTO_MAXIMO_GARANTIZADO
            END
               AS MONTO_MAXIMO_GARANTIZADO,
            CASE
               WHEN TTR.ID_TIPO_TRAMITE IN (4, 9, 8)
               THEN
                  (SELECT   OTROS_TERMINOS_GARANTIA
                     FROM   RUG_GARANTIAS
                    WHERE   ID_GARANTIA = RGG.ID_GARANTIA_MODIFICAR)
               ELSE
                  RGG.OTROS_TERMINOS_GARANTIA
            END
               AS OTROS_TERMINOS,
            CASE
               WHEN TTR.ID_TIPO_TRAMITE IN (4, 9, 8)
               THEN
                  (SELECT   DESC_GARANTIA
                     FROM   RUG_GARANTIAS
                    WHERE   ID_GARANTIA = RGG.ID_GARANTIA_MODIFICAR)
               ELSE
                  RGG.DESC_GARANTIA
            END
               AS DESC_BIENES_MUEBLES,
            RRI.ID_TRAMITE_TEMP,
            RTM.DESCRIPCION AS DESC_TRAMITE_TEMP,
            CASE
               WHEN TTR.ID_TIPO_TRAMITE IN (4, 8)
               THEN
                  (SELECT   VIGENCIA
                     FROM   RUG_GARANTIAS
                    WHERE   ID_GARANTIA = RGG.ID_GARANTIA_MODIFICAR)
               ELSE
                  RGG.VIGENCIA
            END
               AS VIGENCIA,
            RGG.ID_MONEDA,
            RCM.DESC_MONEDA
     FROM                  RUG_GARANTIAS_PENDIENTES RGG
                        LEFT JOIN
                           RUG_CAT_TIPO_GARANTIA RCT
                        ON RGG.ID_TIPO_GARANTIA = RCT.ID_TIPO_GARANTIA
                     LEFT JOIN
                        RUG_CAT_MONEDAS RCM
                     ON RCM.ID_MONEDA = RGG.ID_MONEDA
                  LEFT JOIN
                     RUG_REL_TRAM_INC_GARAN RRI
                  ON RGG.ID_GARANTIA_PEND = RRI.ID_GARANTIA_PEND
               LEFT JOIN
                  TRAMITES_RUG_INCOMP TTR
               ON TTR.ID_TRAMITE_TEMP = RRI.ID_TRAMITE_TEMP
            LEFT JOIN
               RUG_CAT_TIPO_TRAMITE RTM
            ON TTR.ID_TIPO_TRAMITE = RTM.ID_TIPO_TRAMITE
    WHERE   RGG.ID_GARANTIA_PEND NOT IN
                  (SELECT   ID_GARANTIA_PEND
                     FROM   RUG_GARANTIAS
                    WHERE   ID_GARANTIA_PEND IS NOT NULL)
            AND TTR.STATUS_REG = 'AC'
            AND TTR.ID_STATUS_TRAM = 5
/

