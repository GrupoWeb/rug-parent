create PROCEDURE         SP_REL_TRAM_INC_PARTES_UPD 
(
/********

SP que actualiza la persona correspondiente al tr?te y la parte. 
Por lo tanto no funciona cuando se pueden dar de alta n partes iguales. 

********/
        P_ID_TRAMITE_TEMP       IN RUG_REL_TRAM_INC_PARTES.ID_TRAMITE_TEMP%TYPE
      , P_ID_PERSONA            IN RUG_REL_TRAM_INC_PARTES.ID_PERSONA%TYPE
      , P_ID_PARTE              IN RUG_REL_TRAM_INC_PARTES.ID_PARTE%TYPE
      , P_PER_JURIDICA          IN RUG_REL_TRAM_INC_PARTES.PER_JURIDICA%TYPE
      , psResult                OUT   NUMBER
      , psTxResult              OUT   VARCHAR2
)
AS
BEGIN

    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_TRAM_INC_PARTES_UPD','P_ID_TRAMITE_TEMP', P_ID_TRAMITE_TEMP,  'IN');
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_TRAM_INC_PARTES_UPD','P_ID_PERSONA',      P_ID_PERSONA,  'IN');
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_TRAM_INC_PARTES_UPD','P_ID_PARTE',        P_ID_PARTE,  'IN');
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_TRAM_INC_PARTES_UPD','P_PER_JURIDICA',    P_PER_JURIDICA,  'IN');


    UPDATE  RUG_REL_TRAM_INC_PARTES  
       SET  PER_JURIDICA     = P_PER_JURIDICA
         ,  ID_PERSONA       = P_ID_PERSONA
         ,  FECHA_REG        = SYSDATE
     WHERE  ID_TRAMITE_TEMP  = P_ID_TRAMITE_TEMP
       AND  ID_PARTE         = P_ID_PARTE;


    psResult := 0;
    psTxResult := RUG.FN_MENSAJE_ERROR (psResult);

EXCEPTION
    WHEN OTHERS THEN
        CASE
            WHEN P_ID_PARTE = 1 THEN
                psResult := 8;

            WHEN P_ID_PARTE = 5 THEN
                psResult := 97;
        END CASE;
        psTxResult := 'SP_REL_TRAM_INC_PARTES_UPD: ' || RUG.FN_MENSAJE_ERROR (psResult);

        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_TRAM_INC_PARTES_UPD','psResult',  psResult,  'OUT');
        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_REL_TRAM_INC_PARTES_UPD','psTxResult',psTxResult,'OUT');  
--        RAISE EXCEPTION;              
END;
/

