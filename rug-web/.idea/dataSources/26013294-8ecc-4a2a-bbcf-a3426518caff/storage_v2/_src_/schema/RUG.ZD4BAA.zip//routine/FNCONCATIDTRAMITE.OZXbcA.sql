create FUNCTION           FNCONCATIDTRAMITE (
                                                   peIdTramite      NUMBER,
                                                   peCaracter       CHAR,
                                                   peProcess        NUMBER
                                                   )
RETURN CLOB 

IS
    vlTramitesConcat CLOB;
    vlIdTramiteInd   NUMBER;
    vlFirmadosCount  NUMBER;
    vlDiferentesFirma  NUMBER;
    vlError          CHAR;

    CURSOR cursTramitesFirmaMasiva(cpeIdTramite IN NUMBER) IS
    SELECT ID_TRAMITE_TEMP
    FROM RUG.RUG_FIRMA_MASIVA
    WHERE ID_FIRMA_MASIVA = cpeIdTramite AND STATUS_REG = 'AC';


BEGIN

   vlError := 'F';

   SELECT COUNT(RFM.ID_TRAMITE_TEMP)
   INTO vlFirmadosCount
   FROM RUG_FIRMA_MASIVA RFM,
        DOCTOS_TRAM_FIRMADOS_RUG DCT
   WHERE RFM.ID_TRAMITE_TEMP = DCT.ID_TRAMITE_TEMP       
   AND RFM.ID_FIRMA_MASIVA = peIdTramite;

   SELECT COUNT(RFM.ID_TRAMITE_TEMP)
   INTO vlDiferentesFirma
   FROM RUG_FIRMA_MASIVA RFM,
   TRAMITES_RUG_INCOMP TRI
   WHERE RFM.ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP
   AND RFM.ID_FIRMA_MASIVA = peIdTramite
   AND TRI.ID_STATUS_TRAM NOT IN (5,3);


   IF vlFirmadosCount > 0 OR vlDiferentesFirma > 0 THEN

    vlError := 'V';

    IF vlFirmadosCount > 0 THEN 

        vlTramitesConcat := 'ER1';

    ELSIF vlDiferentesFirma > 0 THEN   

        vlTramitesConcat := 'ER2';

    END IF;

   ELSE

       BEGIN
         OPEN cursTramitesFirmaMasiva(peIdTramite);
            LOOP 
                FETCH cursTramitesFirmaMasiva INTO vlIdTramiteInd;
                EXIT WHEN cursTramitesFirmaMasiva%NOTFOUND;
                    vlTramitesConcat := CONCAT(vlTramitesConcat, vlIdTramiteInd || peCaracter);

            END LOOP; 
         CLOSE  cursTramitesFirmaMasiva;

       END;    

   END IF;

   IF peProcess = 1 AND vlError = 'V' THEN

    RETURN NULL;

    ELSIF (peProcess = 1 AND vlError = 'F') OR (peProcess = 0) THEN

    RETURN substr(vlTramitesConcat, 0, length(vlTramitesConcat)-1);

   END IF;

EXCEPTION
   WHEN OTHERS THEN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'FNCONCATIDTRAMITE', 'Exception', substr(SQLCODE||':'||SQLERRM,1,250), 'OUT');      
    RETURN NULL;
END;
/

