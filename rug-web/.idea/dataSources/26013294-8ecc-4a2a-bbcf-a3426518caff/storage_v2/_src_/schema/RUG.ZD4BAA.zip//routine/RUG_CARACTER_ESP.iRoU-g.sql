create FUNCTION         RUG_CARACTER_ESP (peCadena   IN  VARCHAR2)
   RETURN VARCHAR2 AS


  vlCadResult      varchar2(4000);
  vlCadOrig          varchar2(4000);

 BEGIN
    vlCadResult := UPPER(TRIM(peCadena));
  --Asignacion de variables
   IF peCadena IS NOT NULL THEN
        vlCadOrig := UPPER(TRIM(peCadena));
        --VALIDA CARACTERES ESPECIALES
    --    vlCadOrig := vlCadFin;
        vlCadOrig:= REPLACE(vlCadOrig, '|', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '°', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '!', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '"', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '#', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '$', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '%', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '&', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '/', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '(', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, ')', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '=', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '?', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '''', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '\', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '¿', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '¡', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '´', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '+', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '*', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '~', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '{', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '^', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '[', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '}', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, ']', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '`', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, ',', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, ';', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '.', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, ':', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '-', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '_', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '  ', ' ');
        vlCadOrig:= REPLACE(vlCadOrig, '   ', ' ');


        vlCadResult := vlCadOrig;
    END IF;

    RETURN vlCadResult;

 EXCEPTION
   WHEN OTHERS THEN
    INSTITUCIONAL.pkgse_comun.sptLog('RUG_CARACTER_ESP',SUBSTR('Error '||SQLCODE||':'||SQLERRM,1, 1000),'');
    RAISE_APPLICATION_ERROR( -20734,SQLERRM);
    RETURN vlCadResult;
END RUG_CARACTER_ESP;
/

