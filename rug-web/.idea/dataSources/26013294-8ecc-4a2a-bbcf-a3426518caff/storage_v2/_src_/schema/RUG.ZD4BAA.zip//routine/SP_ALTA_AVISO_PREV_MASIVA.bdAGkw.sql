create PROCEDURE         SP_ALTA_AVISO_PREV_MASIVA 
(
    psIdTramiteIncompleto   IN  NUMBER,
    peIdPersona             IN  NUMBER,
    --peIdAcreedor            IN  NUMBER,
    peAnotacion_Juez        IN  VARCHAR2,
    --peCveRastreo            IN  VARCHAR2,
    --peIdArchivo             IN  NUMBER,
    peDescBienes            IN  CLOB,
    --psIdTramiteIncompleto  OUT  VARCHAR2,
    psResult               OUT  NUMBER,
    psTxResult             OUT  VARCHAR2
)
IS

vlIdGarantiaPend            NUMBER;
--vlIdTramiteIncompleto       NUMBER;
--vlAcreedor                  CHAR(2);
vlIdTipoTramite             NUMBER;
--vlPerJuridica               CHAR(2);
vlTipoGarantiaAnterior      NUMBER;

Ex_Error EXCEPTION;
Ex_Error_No_Descripcion EXCEPTION;

BEGIN


    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_AVISO_PREV_MASIVA', 'INCIA', 'INICIA SP_ALTA_AVISO_PREV_MASIVA', 'IN');


    /*    
    SELECT PER_JURIDICA
      INTO vlPerJuridica
      FROM RUG_PERSONAS
     WHERE ID_PERSONA = peIdAcreedor;

    SP_ALTA_TRAMITE_RASTREO(peIdPersona, 2, peIdAcreedor, vlPerJuridica, 0, NULL, SYSDATE, peCveRastreo, peIdArchivo,  
                                        vlIdTramiteIncompleto, psResult, psTxResult);

    */
    IF(peDescBienes is not null OR TRIM(pedescbienes) <> '') THEN 

    SP_ALTA_AVISO_PREVENTIVO(psIdTramiteIncompleto, peDescBienes, peIdPersona, psResult, psTxResult);
    ELSE
     RAISE Ex_Error_No_Descripcion;
    END IF;

    IF (psResult = 0) THEN

        SP_ORDEN_AUTORIDAD(psIdTramiteIncompleto, peAnotacion_Juez, psResult, psTxResult);        

    END IF;         


    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_AVISO_PREV_MASIVA', 'psResult', psResult, 'OUT');   
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_AVISO_PREV_MASIVA', 'TERMINA', psTxResult, 'OUT');


EXCEPTION
WHEN Ex_Error_No_Descripcion THEN
      psResult:=76;
      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);

      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;

WHEN Ex_Error  THEN

      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);

      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;

WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_ALTA_CANCELACION_MASIVA', 'psTxResult', psTxResult, 'OUT');

END;
/

