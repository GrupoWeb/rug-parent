create PROCEDURE         SP_ALTA_TRAMITE_INCOMPLETO (peIdPersona            IN     NUMBER, -- IDENTIFICADOR DE LA PESONA K SeLOGUEA
                                                           peIdTipoTramite        IN     NUMBER, --INSCRIPCION , ALTA ACREEDORES, AVISO PREVENTIVO
                                                           peIdTramiteIncompleto  OUT    NUMBER, --IDENTIFICADOR UNICO DEL REGISTRO
                                                           psResult               OUT    INTEGER,   
                                                           psTxResult             OUT    VARCHAR2)
IS

  vlIdTramiteRugIncom  NUMBER;


BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Incompleto', 'peIdPersona', CAST(peIdPersona AS VARCHAR2), 'IN');

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Incompleto', 'peIdTipoTramite', CAST(peIdTipoTramite AS VARCHAR2), 'IN');


    vlIdTramiteRugIncom:= SEQ_TRAM_INCOMP.NEXTVAL;


    INSERT INTO TRAMITES_RUG_INCOMP VALUES(vlIdTramiteRugIncom,peIdPersona,peIdTipoTramite,SYSDATE,NULL,'AC', 0, 0, SYSDATE,0);

    INSERT INTO RUG_BITAC_TRAMITES VALUES(vlIdTramiteRugIncom, 0, SYSDATE, 0, peIdTipoTramite, SYSDATE, 'AC');

    COMMIT;

    peIdTramiteIncompleto:=vlIdTramiteRugIncom;
    psResult := 0;
    psTxResult := RUG.FN_MENSAJE_ERROR(psResult);


    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Incompleto', 'peIdTramiteIncompleto', CAST(peIdTramiteIncompleto AS VARCHAR2), 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Incompleto', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Incompleto', 'psTxResult', psTxResult, 'OUT');    


  psResult:=0;   
  psTxResult:= 'ALTA EXITOSA';--pkg_infz_inst_fenx.FunObtMsgErr(psResult);
  EXCEPTION 
   WHEN OTHERS THEN
        psResult:=-1;   
        psTxResult:= 'ocurrio un error';
  dbms_output.put_line(psTxResult);
  psResult  := 999;   
  psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);  
  ROLLBACK;                
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Incompleto', 'peIdTramiteIncompleto', CAST(peIdTramiteIncompleto AS VARCHAR2), 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Incompleto', 'psResult', psResult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_Alta_Tramite_Incompleto', 'psTxResult', psTxResult, 'OUT');    


END;
/

