create PROCEDURE         SP_ALTAPARTE1 
                            (
                                IdTramite            IN  NUMBER, --idTramite al que se asignara la parte 
                                IdParte              IN  NUMBER,  -- ID de tipo de parte, Acreedor, Deudor u Otorgante
                                peTipoPersona        IN  VARCHAR2, -- Fisica (PF) o Moral(PM)
                                peTipo               IN  VARCHAR2,
                                peRazonSocial        IN  VARCHAR2, --Razon social (solo persona moral)                                
                                peNombre             IN  VARCHAR2,  --(solo persona fisica)
                                peApellidoP          IN  VARCHAR2,  --(solo persona fisica)
                                peApellidoM          IN  VARCHAR2,  --(solo persona fisica)
                                peFolioMercantil     IN  VARCHAR2,
                                peRFC                IN  VARCHAR2, -- RFC O IDENTIFICADOR FISCAL DEL PAIS DE ORIGEN
                                peCURP               IN  VARCHAR2,
                                peBDomicilio         IN  CHAR,      --BANDERA QUE INDICA SI SE MANDA EL DOMICILIO LOS VALORES SON V o F
                                peCalle              IN  VARCHAR2,
                                peNumExt             IN  VARCHAR2,
                                peNumInt             IN  VARCHAR2,                                
                                peIdColonia          IN  NUMBER,           
                                peIdLocalidad        IN  NUMBER,
                                peIdPersona          IN  NUMBER,  --idPersona Usuario
                                peIdNacionalidad     IN  NUMBER,
                                peTelefono           IN  VARCHAR2,
                                peExtension          IN  VARCHAR2,   
                                peEmail              IN  VARCHAR2,
                                peDomicilioUno       IN  VARCHAR2,
                                peDomicilioDos       IN  VARCHAR2, 
                                pePoblacion          IN  VARCHAR2,
                                peZonaPostal         IN  VARCHAR2,
                                pePaisResidencia     IN  NUMBER,                                 
                                psIdPersonaAlta     OUT  NUMBER, --ID DE LA PERSONA QUE SE ACABA DE DAR DE ALTA
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2,
                                peBandera            IN  VARCHAR2 DEFAULT 'F'
                            )
IS


vlIdPersona                 NUMBER;
vlCountTotal                NUMBER;
vlIdDomicilio               NUMBER;
vlIdTipoTramite             NUMBER;
vlCountColonias             NUMBER;
vlCountCURPExiste           NUMBER;
vlCountLocalidades          NUMBER;
vlNacionalidad              VARCHAR2(50);
vlFolioElectronicoExist     VARCHAR(250);
vFolioAux                   RUG.RUG_PERSONAS.FOLIO_MERCANTIL%TYPE;

vlCurp          VARCHAR(25);

--VARIABLES VALIDACION RFC
vlPsResultValRFC    NUMBER;
vlPsTxtResultValRFC VARCHAR(4000);

--VARIABLES VALIDACION DE CURP
vlPsResultValCURP    NUMBER;
vlPsTxtResultValCURP VARCHAR(4000);


--Curp
vlCountCurpRegExp NUMBER;

Ex_CurpExistente    EXCEPTION;
Ex_Error            EXCEPTION;

CURSOR cursPartes(cpeIdTramite IN NUMBER) IS
SELECT ID_PARTE FROM RUG_REL_TRAM_INC_PARTES
 WHERE ID_TRAMITE_TEMP = cpeIdTramite 
   AND ID_PARTE IN (1,4) 
   AND STATUS_REG = 'AC';

cursPartes_Rec cursPartes%ROWTYPE;

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'IdTramite', IdTramite, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'IdParte', IdParte, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peTipo', peTipo, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peTipoPersona', peTipoPersona, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peRazonSocial', peRazonSocial, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peNombre', peNombre, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peApellidoP', peApellidoP, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peFolioMercantil', peFolioMercantil, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peRFC', peRFC, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peCURP', peCURP, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peBDomicilio', peBDomicilio, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peCalle', peCalle, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peNumExt', peNumExt, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peNumInt', peNumInt, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peIdColonia', peIdColonia, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peIdLocalidad', peIdLocalidad, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peIdPersona', peIdPersona, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peIdNacionalidad', peIdNacionalidad, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peTelefono', peTelefono, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peExtension', peExtension, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peEmail', peEmail, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peDomicilioUno', peDomicilioUno, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peDomicilioDos', peDomicilioDos, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'pePoblacion', pePoblacion, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peZonaPostal', peZonaPostal, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'pePaisResidencia', pePaisResidencia, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'peBandera', peBandera, 'IN');


    IF peTipoPersona = 'PM' AND (peFolioMercantil IS NULL OR TRIM(peFolioMercantil) = '') AND peTipo != 'OT' AND peIdNacionalidad = 1 THEN

        psResult := 54;
        RAISE Ex_Error;

    END IF;


    IF peIdNacionalidad IS NOT NULL THEN

        SELECT COUNT(*)
          INTO vlCountTotal
          FROM RUG_CAT_NACIONALIDADES
         WHERE ID_NACIONALIDAD = peIdNacionalidad;

        IF vlCountTotal = 0 THEN

            psResult := 19;
            RAISE Ex_Error;

        END IF;

    ELSE

        psResult := 18;
        RAISE Ex_Error;

    END IF;


    IF IdParte IN (4) THEN --SE MODIFICO PARA PERMITIR MAS DE UN OTORGANTE 18022011
     BEGIN
    FOR cursPartes_Rec IN cursPartes(IdTramite)
        LOOP
            IF cursPartes_Rec.ID_PARTE = IdParte THEN

                      psResult := 29;
                      RAISE Ex_Error;

            END IF;
        END LOOP;
    END;
    END IF;


    BEGIN

        IF peIdNacionalidad = 1 THEN 

            RUG.SP_VALIDA_RFC(peIdNacionalidad, peRFC, peTipoPersona, vlPsResultValRFC, vlPsTxtResultValRFC);

            IF vlPsResultValRFC <> 0 THEN

                psResult:= vlPsResultValRFC;    
                RAISE Ex_Error;

            END IF;

        ELSIF peTipoPersona = 'PF' AND peIdNacionalidad != 1 THEN

            SELECT COUNT(*) 
              INTO vlCountTotal
              FROM RUG_PERSONAS
             WHERE TRIM(RFC) = TRIM(peRFC)
               AND ID_NACIONALIDAD = peIdNacionalidad;

            SELECT DESC_NACIONALIDAD
              INTO vlNacionalidad
              FROM RUG_CAT_NACIONALIDADES
             WHERE ID_NACIONALIDAD = peIdNacionalidad;

            IF vlCountTotal > 0 THEN 

                psResult := 121;
                psTxResult := RUG.FN_MENSAJE_ERROR(psResult);            
                psTxResult := REPLACE(psTxResult, '@pais', vlNacionalidad);            
                RAISE Ex_CurpExistente;               

            END IF;

        ELSIF peTipoPersona = 'PM' AND peIdNacionalidad != 1 THEN

            SELECT COUNT(*) 
              INTO vlCountTotal
              FROM RUG_PERSONAS A, RUG_PERSONAS_MORALES B
             WHERE A.ID_PERSONA = B.ID_PERSONA
               AND TRIM(UPPER(B.RAZON_SOCIAL)) = TRIM(UPPER(peRazonSocial))
               AND TRIM(UPPER(A.RFC)) = TRIM(UPPER(peRFC))
               AND A.ID_NACIONALIDAD = peIdNacionalidad;



              IF vlCountTotal > 0 THEN

                SELECT DESC_NACIONALIDAD
                  INTO vlNacionalidad
                  FROM RUG_CAT_NACIONALIDADES
                 WHERE ID_NACIONALIDAD = peIdNacionalidad;

                SELECT A.FOLIO_MERCANTIL 
                  INTO vFolioAux
                  FROM RUG_PERSONAS A, RUG_PERSONAS_MORALES B
                 WHERE A.ID_PERSONA = B.ID_PERSONA
                   AND TRIM(UPPER(B.RAZON_SOCIAL)) = TRIM(UPPER(peRazonSocial))
                   AND TRIM(UPPER(A.RFC)) = TRIM(UPPER(peRFC))
                   AND A.ID_NACIONALIDAD = peIdNacionalidad; 

                psResult := 122;
                psTxResult := RUG.FN_MENSAJE_ERROR(psResult);            
                psTxResult := REPLACE(psTxResult, '@pais', vlNacionalidad);   
                psTxResult := REPLACE(psTxResult, '@denominacion', peRazonSocial);   
                psTxResult := REPLACE(psTxResult, '@folio', vFolioAux);

                RAISE Ex_CurpExistente;               

            END IF;


        END IF;

    END;


    IF peTipoPersona = 'PF' THEN

        --Validar Nombre
        --  peNombre, peApellidoP, peApellidoM, peCURP

        IF(peNombre is null OR TRIM(penombre) <> '') THEN

            psResult := 79;    
            RAISE Ex_Error;

        END IF;


        IF(peApellidoP is null OR TRIM(peApellidoP) <> '') THEN

            psResult := 80;    
            RAISE Ex_Error;

        END IF;


        IF (IdParte = 1 AND peIdNacionalidad = 1) THEN

            IF(TRIM(peCURP) = '' OR peCURP IS NULL) THEN

                   psResult := 65;
                   RAISE Ex_Error;
            ELSE

                RUG.SP_VALIDA_CURP(peCURP, vlPsResultValCURP, vlPsTxtResultValCURP);

                IF vlPsResultValCURP <> 0 THEN

                    psResult := vlPsResultValCURP;                    
                    RAISE Ex_Error;

                END IF;  

                vlCurp := UPPER(peCURP);                                       

                SELECT COUNT(*)
                  INTO vlCountCURPExiste
                  FROM RUG_PERSONAS_FISICAS A , RUG_PERSONAS B
                 WHERE UPPER(A.CURP) = vlCurp
                   AND A.ID_PERSONA = B.ID_PERSONA
                   AND B.SIT_PERSONA != 'BF';

                SELECT ID_TIPO_TRAMITE
                  INTO vlIdTipoTramite
                  FROM TRAMITES_RUG_INCOMP
                 WHERE ID_TRAMITE_TEMP = IdTramite;


                IF (vlCountCURPExiste > 0 AND vlIdTipoTramite NOT IN (6,7,8)) OR (vlCountCURPExiste > 0 AND peBandera = 'V') THEN

                    SELECT FOLIO_MERCANTIL
                      INTO vlFolioElectronicoExist
                      FROM RUG.RUG_PERSONAS 
                     WHERE ID_PERSONA = (SELECT ID_PERSONA
                                           FROM RUG.RUG_PERSONAS_FISICAS
                                          WHERE UPPER(CURP) = vlCurp
                                            AND ROWNUM < 2);

                    psResult := 17;
                    psTxResult := RUG.FN_MENSAJE_ERROR(psResult);            
                    psTxResult := REPLACE(psTxResult, '@vlFolioElectronico', vlFolioElectronicoExist);

                    RAISE Ex_CurpExistente;

                END IF;


            END IF;                

        END IF;        


    END IF;

    IF peIdNacionalidad = 1 THEN 


        IF peIdColonia > 0 THEN

            SELECT COUNT(*)
              INTO vlCountColonias
              FROM V_SE_CAT_COLONIAS_RUG
             WHERE ID_COLONIA = peIdColonia;

            IF vlCountColonias = 0 THEN

                psResult := 20;
                RAISE Ex_Error;

            END IF;

        END IF;


        IF peIdLocalidad > 0 THEN

            SELECT COUNT(*)
              INTO vlCountLocalidades
              FROM V_SE_CAT_LOCALIDADES_RUG
             WHERE ID_LOCALIDAD = peIdLocalidad;

            IF vlCountLocalidades = 0 THEN

                psResult := 20;
                RAISE Ex_Error;

            END IF;

        END IF;

    END IF;


    vlIdDomicilio := SEQ_RUG_ID_DOMICILIO.NEXTVAL;        

    IF(peBDomicilio = 'V') THEN

         IF pePaisResidencia = 1 OR pePaisResidencia IS NULL  THEN

            INSERT INTO RUG_DOMICILIOS (ID_DOMICILIO, CALLE, NUM_EXTERIOR, NUM_INTERIOR, ID_COLONIA, CALLE_COLINDANTE_1, CALLE_COLINDANTE_2,
                                        CALLE_POSTERIOR, LOCALIDAD, ID_VIALIDAD, TX_REFER_ADICIONAL, ID_TIPO_DOMICILIO, ID_LOCALIDAD)
            VALUES   (vlIdDomicilio, peCalle, peNumExt, peNumInt, DECODE(peIdColonia, -1, 0,peIdColonia) , NULL, NULL, NULL, NULL, NULL, NULL, NULL, DECODE(peIdLocalidad,-1,0,peIdLocalidad));
         ELSE    


           INSERT INTO RUG.RUG_DOMICILIOS_EXT(ID_DOMICILIO, ID_PAIS_RESIDENCIA, UBICA_DOMICILIO_1, UBICA_DOMICILIO_2, POBLACION, ZONA_POSTAL)
           VALUES(vlIdDomicilio, pePaisResidencia, peDomicilioUno, peDomicilioDos, pePoblacion, peZonaPostal);

        END IF;                

    END IF;

    vlIdPersona:= SEQ_RUG_ID_PERSONA.NEXTVAL;


    INSERT INTO RUG_PERSONAS (ID_PERSONA, RFC, ID_NACIONALIDAD, PER_JURIDICA, FH_REGISTRO, PROCEDENCIA, SIT_PERSONA,
                                 CVE_NACIONALIDAD, ID_DOMICILIO, FOLIO_MERCANTIL, FECHA_INSCR_CC, REG_TERMINADO, E_MAIL, CURP_DOC)
    VALUES   (vlIdPersona, peRFC, peIdNacionalidad, peTipoPersona, TRUNC(SYSDATE), 'NAL', 'AC', NULL, vlIdDomicilio, peFolioMercantil, NULL, 'N', peEmail, vlCurp);

    IF peTelefono IS NOT NULL THEN

        INSERT INTO RUG_TELEFONOS
        VALUES(vlIdPersona, NULL, peTelefono, peExtension, SYSDATE, 'AC');

    END IF; 


    IF(UPPER(peTipoPersona) = 'PM') THEN

        IF(peRazonSocial is null OR TRIM (peRazonSocial)='' )THEN

            psResult := 77;
            RAISE Ex_Error;


        END IF;

        INSERT INTO RUG_PERSONAS_MORALES (ID_PERSONA, RAZON_SOCIAL, TIPO)
        VALUES   (vlIdPersona, TRIM(peRazonSocial), peTipo);


    ELSIF (UPPER(peTipoPersona) = 'PF') THEN


        INSERT INTO RUG_PERSONAS_FISICAS (ID_PERSONA, NOMBRE_PERSONA, AP_PATERNO, AP_MATERNO, CURP)
        VALUES   (vlIdPersona, TRIM(peNombre), TRIM(peApellidoP), TRIM(peApellidoM), TRIM(vlCurp));

    END IF;



    INSERT INTO RUG_REL_TRAM_INC_PARTES( ID_TRAMITE_TEMP,  ID_PERSONA, ID_PARTE, PER_JURIDICA, STATUS_REG, FECHA_REG)
    VALUES (IdTramite, vlIdPersona, IdParte, peTipoPersona, 'AC', SYSDATE);

    COMMIT;


    psIdPersonaAlta := vlIdPersona;
    psResult    := 0;
    psTxResult  := RUG.FN_MENSAJE_ERROR(psResult);    

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'psIdPersonaAlta', psIdPersonaAlta, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'psTxResult', psTxResult, 'OUT');    


EXCEPTION

WHEN Ex_Error  THEN
      ROLLBACK;

      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);      
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'psIdPersonaAlta', psIdPersonaAlta, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'psTxResult', psTxResult, 'OUT');


WHEN Ex_CurpExistente  THEN            
      ROLLBACK;

      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'psIdPersonaAlta', psIdPersonaAlta, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'psTxResult', psTxResult, 'OUT');


WHEN OTHERS THEN           
      ROLLBACK;

      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);      
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'psIdPersonaAlta', psIdPersonaAlta, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_AltaParte1', 'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE(psTxResult);
END;
/

