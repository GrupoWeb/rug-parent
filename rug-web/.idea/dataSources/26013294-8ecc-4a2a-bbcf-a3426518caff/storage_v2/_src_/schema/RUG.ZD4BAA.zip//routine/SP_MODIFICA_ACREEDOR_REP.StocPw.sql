create PROCEDURE         SP_MODIFICA_ACREEDOR_REP 
                            ( 
                                peIdPersonaModificar IN  NUMBER, --ID DE LA PERSONA QUE SE VA A MODIFICAR
                                peIdUsuario          IN  NUMBER,
                                peTipoPersona        IN  VARCHAR2,
                                IdTipo               IN  VARCHAR2, -- Sociedad Mercantil 'SM' o Otros 'OT'
                                peRazonSocial        IN  VARCHAR2,
                                peRFC                IN  VARCHAR2,
                                peCURP               IN  VARCHAR2,
                                peFolioMercantil     IN  VARCHAR2,
                                peCalle              IN  VARCHAR2,
                                peNumExt             IN  VARCHAR2,
                                peNumInt             IN  VARCHAR2,
                                peNombre             IN  VARCHAR2,
                                peApellidoP          IN  VARCHAR2,
                                peApellidoM          IN  VARCHAR2,
                                peIdColonia          IN  NUMBER,           
                                peIdLocalidad        IN  NUMBER,
                                peIdNacionalidad     IN  NUMBER,
                                peFechaInicio        IN  DATE,  -- Fecha Inicio del contrato
                                peFechaFin           IN  DATE,  -- Fecha Fin del contrato
                                peOtrosTerm          IN  VARCHAR2, -- Terminos y condiciones
                                peTipoContrato       IN  NUMBER,
                                --peIdTramiteTemp      IN  NUMBER,
                                peTelefono           IN  VARCHAR2,
                                peExtension          IN  VARCHAR2,   
                                peEmail              IN  VARCHAR2,
                                peDomicilioUno       IN  VARCHAR2,
                                peDomicilioDos       IN  VARCHAR2, 
                                pePoblacion          IN  VARCHAR2,
                                peZonaPostal         IN  VARCHAR2,
                                pePaisResidencia     IN  NUMBER, 
                                peBandera            IN  CHAR,  
                                peAfolExiste         IN  CHAR ,  -- TRUE = 1, FALSE = 0
                                peNIFP               IN  VARCHAR2,      
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2,   
                                psFolioElectronico  OUT  VARCHAR2,
                                psIdTramiteTemp     OUT  NUMBER                                 
                            )
IS

vlIdContrato          NUMBER;
vlIdPersonaInsertar   NUMBER;
vlCountPersonas       NUMBER;
vlIdDomicilio         NUMBER;
vlIdTramiteTempSalida NUMBER;
vlResult              NUMBER;
vlTxResult            VARCHAR2(100);

Ex_ErrProcess         EXCEPTION;
Ex_PersonaNoExiste    EXCEPTION;
Ex_ErrAlta            EXCEPTION;

--VARIABLES VALIDACION RFC
vlPsResultValRFC    NUMBER;
vlPsTxtResultValRFC VARCHAR(4000);
Ex_ErrRFC EXCEPTION;

--VARIABLES REGRESA FOLIo
vlPsResult    NUMBER;
vlPsTxtResult VARCHAR(4000);
vlNvoFolioElectronico       VARCHAR(250);

BEGIN

    BEGIN

       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peIdPersonaModificar', CAST(peIdPersonaModificar AS VARCHAR2), 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peIdUsuario', CAST(peIdUsuario AS VARCHAR2), 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peTipoPersona', peTipoPersona, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'IdTipo', IdTipo, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peRazonSocial', peRazonSocial, 'IN'); 
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peNombre', peNombre, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peApellidoP', peApellidoP, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peApellidoM', peApellidoM, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peTelefono', peTelefono, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peExtension', peExtension, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peEmail', peEmail, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peRFC', peRFC, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peCURP', peCURP, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peFolioMercantil', peFolioMercantil, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peCalle', peCalle, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peNumExt', peNumExt, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peNumInt', peNumInt, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peIdColonia', CAST(peIdColonia AS VARCHAR2), 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peIdLocalidad', CAST(peIdLocalidad AS VARCHAR2), 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peIdNacionalidad', CAST(peIdNacionalidad AS VARCHAR2), 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peFechaInicio', CAST(peFechaInicio AS VARCHAR2), 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peFechaFin', CAST(peFechaFin AS VARCHAR2), 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peOtrosTerm', peOtrosTerm, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peTipoContrato', CAST(peTipoContrato AS VARCHAR2), 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peTelefono', peTelefono, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peExtension', peExtension, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peEmail', peEmail, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peDomicilioUno', peDomicilioUno, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peDomicilioDos', peDomicilioDos, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'pePoblacion', pePoblacion, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peZonaPostal', peZonaPostal, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peBandera', peBandera, 'IN');
       REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'peNIFP', peNIFP, 'IN');


    END;


    SELECT COUNT(*)
    INTO vlCountPersonas
    FROM RUG_PERSONAS   
    WHERE ID_PERSONA = peIdPersonaModificar; 

    IF vlCountPersonas = 0 THEN

        RAISE Ex_PersonaNoExiste;

    END IF;


    BEGIN

        SP_ALTA_TRAMITE_INCOMPLETO(peIdUsuario, 19, vlIdTramiteTempSalida, vlResult, vlTxResult);        

    EXCEPTION    
    WHEN OTHERS THEN

        RAISE Ex_ErrProcess;

    END;

    IF vlIdTramiteTempSalida IS NULL OR TRIM(vlIdTramiteTempSalida) = '' THEN
        psResult := vlPsResult;
        psTxResult := vlPsTxtResult;
        RAISE Ex_ErrProcess;
    END IF; 

   -- DA DE ALTA EL ACREEDOR
   SP_ALTA_ACREEDOR_REP(peIdUsuario, peTipoPersona, IdTipo, peRazonSocial, peRFC, peCURP, peFolioMercantil, peCalle, peNumExt, peNumInt, peNombre, peApellidoP, peApellidoM, peIdColonia,   peIdLocalidad, peIdNacionalidad, peFechaInicio, peFechaFin, peOtrosTerm, peTipoContrato, vlIdTramiteTempSalida, peTelefono,peExtension, peEmail, peDomicilioUno,  peDomicilioDos, pePoblacion, peZonaPostal, pePaisResidencia, peBandera, peAfolExiste, peNIFP, vlPsResult, vlPsTxtResult, vlNvoFolioElectronico, vlIdPersonaInsertar);                             

    IF vlPsResult <> 0 THEN
        psResult := vlPsResult;
        psTxResult := vlPsTxtResult;
        RAISE Ex_ErrAlta;
    END IF; 

     psFolioElectronico := vlNvoFolioElectronico;

     --vlIdPersonaInsertar := SEQ_RUG_ID_PERSONA.NEXTVAL;

    INSERT INTO RUG.RUG_REL_MODIFICA_ACREEDOR(ID_TRAMITE_TEMP, ID_ACREEDOR, ID_ACREEDOR_NUEVO, B_FIRMADO, 
                                              ID_USUARIO_MODIFICA, FH_MODIFICA, STATUS_REG)
    VALUES(vlIdTramiteTempSalida, peIdPersonaModificar, vlIdPersonaInsertar, 'N', peIdUsuario, SYSDATE, 'AC');

    COMMIT;

  psIdTramiteTemp := vlIdTramiteTempSalida;
  psResult   :=0;        
  psTxResult :=RUG.FN_MENSAJE_ERROR(psResult);

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'psIdTramiteTemp', psIdTramiteTemp, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'psTxResult', psTxResult, 'OUT');    

--dbms_output.put_line(psIdTramiteTemp );
--dbms_output.put_line(psResult );
--dbms_output.put_line(psTxResult );


EXCEPTION 
WHEN Ex_ErrRFC  THEN
      psResult := vlPsResultValRFC;
      psTxResult := vlPsTxtResultValRFC;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;
WHEN Ex_ErrAlta  THEN
      psResult := vlPsResult;
      psTxResult := vlPsTxtResult;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'psTxResult', psTxResult, 'OUT');
      ROLLBACK;
WHEN Ex_PersonaNoExiste  THEN   
      ROLLBACK;
      psResult := 12;
      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'psTxResult', psTxResult, 'OUT');
WHEN Ex_ErrProcess  THEN  
      psResult := vlResult;
      psTxResult:= vlTxResult;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'psTxResult', psTxResult, 'OUT');    
      ROLLBACK;
WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_ACREEDOR_REP', 'psTxResult', psTxResult, 'OUT');    


END SP_MODIFICA_ACREEDOR_REP;
/

