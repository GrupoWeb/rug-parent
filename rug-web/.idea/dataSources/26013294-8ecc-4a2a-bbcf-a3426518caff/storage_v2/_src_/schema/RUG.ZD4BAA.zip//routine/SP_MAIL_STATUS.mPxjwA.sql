create PROCEDURE     SP_MAIL_STATUS (
                                                peIdMail          IN  NUMBER,
                                                peIdStatus        IN  NUMBER,
                                                peExcepcionMsg    IN  CLOB,
                                                psResult         OUT  NUMBER,
                                                psTxResult       OUT  VARCHAR2
                                          )
IS


vlCantidad  NUMBER;
Ex_ErrParametro EXCEPTION;


BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MAIL_STATUS', 'peIdMail', peIdMail, 'IN');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MAIL_STATUS', 'peIdStatus', peIdStatus, 'IN');


    SELECT COUNT(*)
      INTO vlCantidad 
      FROM RUG_CAT_STATUS_MAILS
     WHERE ID_STATUS_MAIL = peIdStatus
       AND STATUS_REG = 'AC';


    IF(vlCantidad = 0) THEN 

        psResult  := -1;   
        psTxResult:= 'STATUS NO VALIDO PARA EL CORREO';
        RAISE Ex_ErrParametro;

    END IF;    


    UPDATE RUG_MAIL_POOL
       SET ID_STATUS_MAIL = peIdStatus,
       FECHA_ENVIO= sysdate
     WHERE ID_MAIL = peIdMail;


    IF(peExcepcionMsg IS NOT NULL) THEN

       INSERT INTO RUG_MAIL_EXCEPTIONS(ID_MAIL, DESC_EXCEPTION, FECHA_REG)
       VALUES(peIdMail, peExcepcionMsg, SYSDATE);   

    END IF; 

    SELECT COUNT(*)
      INTO vlCantidad 
      FROM RUG_MAIL_EXCEPTIONS
     WHERE ID_MAIL = peIdMail;


    IF(vlCantidad > 2) THEN

      UPDATE RUG_MAIL_POOL
         SET ID_STATUS_MAIL = 3
       WHERE ID_MAIL = peIdMail;

    END IF;


   COMMIT;

    psResult  := 0;   
    psTxResult:= 'ALTA EXITOSA';


    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MAIL_STATUS', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MAIL_STATUS', 'psTxResult', psTxResult, 'OUT');

EXCEPTION

   --WHEN Ex_ErrParametro  THEN      
     -- ROLLBACK;
      --REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MAIL_STATUS', 'psResult', psResult, 'OUT');
      --REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MAIL_STATUS', 'psTxResult', psTxResult, 'OUT');


  WHEN OTHERS THEN
     psResult  := 999;   
     psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
     ROLLBACK;
     REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MAIL_STATUS', 'psResult', psResult, 'OUT');
     REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MAIL_STATUS', 'psTxResult', psTxResult, 'OUT');


END;
/

