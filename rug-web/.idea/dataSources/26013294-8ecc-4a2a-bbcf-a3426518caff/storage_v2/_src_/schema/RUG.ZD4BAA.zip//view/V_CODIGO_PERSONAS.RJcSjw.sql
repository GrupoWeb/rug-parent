create view V_CODIGO_PERSONAS as
select t.codigo_registro || decode(t.per_juridica,'PF','I','J') codigo,
       t.id_persona,
       t.rfc,
       t.per_juridica,
       t.curp_doc
from rug_personas t
where t.codigo_registro is not null
/

