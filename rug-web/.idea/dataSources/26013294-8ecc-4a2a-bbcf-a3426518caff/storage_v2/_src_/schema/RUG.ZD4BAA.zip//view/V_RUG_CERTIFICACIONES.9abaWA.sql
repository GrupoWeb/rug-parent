create view V_RUG_CERTIFICACIONES as
SELECT   ID_TRAMITE_CERT,
            ID_TRAMITE,
            ID_GARANTIA,
            ID_TIPO_TRAMITE,
            FECHA_CERT,
            STATUS_REG
     FROM   RUG_CERTIFICACIONES
/

