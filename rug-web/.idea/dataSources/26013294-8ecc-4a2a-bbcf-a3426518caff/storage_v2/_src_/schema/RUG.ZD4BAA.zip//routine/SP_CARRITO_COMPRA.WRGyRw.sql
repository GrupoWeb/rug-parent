create PROCEDURE           SP_CARRITO_COMPRA 
                            (
                                peIdPersona          IN  NUMBER,
                                peIdTipoTramite      IN  NUMBER,
                                psDescripcion       OUT  VARCHAR2,
                                psPrecio            OUT  NUMBER,
                                psCantidad          OUT  NUMBER,
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )
IS

BEGIN

    SELECT DESCRIPCION, PRECIO
    INTO psDescripcion, psPrecio
    FROM RUG_CAT_TIPO_TRAMITE
    WHERE ID_TIPO_TRAMITE = peIdTipoTramite;

    SELECT COUNT(*) AS CANTIDAD 
      INTO psCantidad
      FROM TRAMITES_RUG_INCOMP TRI, RUG_BITAC_TRAMITES RBT 
     WHERE RBT.ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP
       AND TRI.ID_TRAMITE_TEMP NOT IN (SELECT TRA.ID_TRAMITE_TEMP 
                                         FROM TRAMITES TRA
                                        WHERE TRA.ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP)
       AND RBT.ID_STATUS = 2
       AND TRI.ID_PERSONA = peIdPersona
       AND TRI.ID_TIPO_TRAMITE = peIdTipoTramite;

    psResult := 0;    
    psTxResult := 'Consulta Exitosa';   


END SP_CARRITO_COMPRA;
/

