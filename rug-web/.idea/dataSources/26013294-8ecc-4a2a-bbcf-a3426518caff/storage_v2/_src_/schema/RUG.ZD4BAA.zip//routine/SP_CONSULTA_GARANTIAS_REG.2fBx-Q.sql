create PROCEDURE     SP_CONSULTA_GARANTIAS_REG
                                                         (
                                                             peDescBienMueble        IN VARCHAR2
                                                           , peNombOtorganteGarantia IN VARCHAR2
                                                           , peNumGarantiaMobiliaria IN NUMBER
                                                           , peFolioElectronicoOtorg IN VARCHAR
                                                           , peCurpOtorganteGarantia IN VARCHAR2
                                                           , peRfcOtorganteGarantia  IN VARCHAR2
                                                           , peInicio                IN NUMBER
                                                           , peFin                   IN NUMBER
														   , peNumeroSerial			 IN VARCHAR2
                                                           , peIdPersona             IN NUMBER
														   , peTipoTramite           IN NUMBER
                                                           , peNumRegistros OUT         NUMBER
                                                           , psCursorConsulta OUT SYS_REFCURSOR
                                                         )
IS
    
    vlNombre         VARCHAR2 (3000);
    vlGarantia       VARCHAR2 (100);
    vlFolio          VARCHAR2 (3000);
    vlDescBienMueble VARCHAR2 (4000);
    vlConsulta CLOB;
    vlCurp VARCHAR2 (100);
    vlRfc  VARCHAR2 (100);
    vlNombreOt CLOB;
    vlDescBienes CLOB;
	vlSerialBienes VARCHAR2(20000);
    vlidtramite VARCHAR2(20000);
    vl_Curp CLOB;
    vl_Rfc CLOB;
    vl_Folio CLOB;

    vlcont  NUMBER;
    vlcont1 NUMBER;
    vlcont2 NUMBER;
    vlcont3 NUMBER;
    vlmil   NUMBER;
    vlmil1  NUMBER;
    vlmil2  NUMBER;
    vlmil3  NUMBER;
    vltrunc VARCHAR2(4000);

    vlTotalReg CLOB;
    vlTotal  NUMBER;
    vlInicio NUMBER;
    vlFin    NUMBER;

TYPE t_folio
IS
    TABLE OF RUG.RUG_PERSONAS_H.ID_TRAMITE%TYPE;

    v_folio t_folio;

TYPE t_curp
IS
    TABLE OF RUG.RUG_PERSONAS_H.ID_TRAMITE%TYPE;

    v_curp t_curp;

TYPE t_rfc
IS
    TABLE OF RUG.RUG_PERSONAS_H.ID_TRAMITE%TYPE;

    v_rfc t_rfc;

TYPE t_nombreot
IS
    TABLE OF RUG.RUG_PERSONAS_H.ID_TRAMITE%TYPE;

    v_nombreot t_nombreot;

TYPE t_descripcion
IS
    TABLE OF RUG.RUG_PERSONAS_H.ID_TRAMITE%TYPE;

    v_descripcion t_descripcion;


TYPE t_serial
IS
    TABLE OF RUG.RUG_PERSONAS_H.ID_TRAMITE%TYPE;	

v_serial t_serial;	

    vlPsTxtResult VARCHAR(4000);
    vlPsResult    NUMBER;

    Ex_Error EXCEPTION;
    Ex_TramiteSinSaldo      EXCEPTION;

BEGIN
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'peDescBienMueble', peDescBienMueble, 'IN');
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'peNombOtorganteGarantia', peNombOtorganteGarantia, 'IN');
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'peNumGarantiaMobiliaria', peNumGarantiaMobiliaria, 'IN');
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'peCurpOtorganteGarantia', peCurpOtorganteGarantia, 'IN');
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'peRfcOtorganteGarantia', peRfcOtorganteGarantia, 'IN');
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'peFolioElectronicoOtorg', peFolioElectronicoOtorg, 'IN');
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'peInicio', peInicio, 'IN');
    REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'peFin', peFin, 'IN');
	REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'peIdPersona', peIdPersona, 'IN');

     /* Limpiando Los Campos */
    vlNombre         := TRIM(UPPER(RUG_ACENTOS(peNombOtorganteGarantia)));
    vlGarantia       := TRIM(peNumGarantiaMobiliaria);
    vlFolio          := TRIM(UPPER(peFolioElectronicoOtorg));
    vlDescBienMueble := TRIM(UPPER(RUG_CARACTER_ESP(peDescBienMueble)));
    vlCurp           := TRIM(UPPER(peCurpOtorganteGarantia));
    vlRfc            := TRIM(UPPER(peRfcOtorganteGarantia));
    vltrunc          := NULL;


    IF FN_TIENE_SALDO(peIdPersona,peTipoTramite,0) = 0 THEN
            RAISE Ex_TramiteSinSaldo;
    END IF;

    IF peInicio IS NULL THEN
        vlInicio := 1;
    ELSE
        vlInicio := peInicio;
    END IF;

    IF peFin IS NULL THEN
        vlFin := 20;
    ELSE
        vlFin := peFin;
    END IF;

    IF ( vlDescBienMueble = '''') THEN

        vlDescBienMueble := NULL;

    END IF;

    IF (vlGarantia = '0' ) THEN

        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', '1', 1, 'OUT');

        OPEN psCursorConsulta FOR
        SELECT
               ''
        from
               dual
        ;

    ELSIF LENGTH(vlnombre) < 3
        OR
        LENGTH(vldescbienmueble) < 3 THEN

        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'psResult', 1, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'psTxResult', 'Ingresar un valor valido', 'OUT');

        OPEN psCursorConsulta FOR
        SELECT
               ''
        from
               dual
        ;

    ELSE

        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', '2', 2, 'OUT');

        vlmil   := 0;
        vlmil1  := 0;
        vlmil2  := 0;
        vlmil3  := 0;
        vlcont  := 0;
        vlcont1 := 0;
        vlcont2 := 0;
        vlcont3 := 0;

         /***********************************************************/
         /******** Query Base Que Obtiene Los Tramites Vigentes *****/
         /***********************************************************/
        vlConsulta := ' WITH TRAMITE_BASE                        
AS                       
(SELECT ROWNUM RN,                               
ID_TRAMITE,                               
ID_TIPO_TRAMITE,                               
FECHA_CREACION,                               
DESCRIPCION,                               
FN_GETACREEDOR (ID_TRAMITE, 1) NOMBRE,                               
FN_GETACREEDOR (ID_TRAMITE, 2) FOLIO_MERCANTIL,                               
--FNCONCATOTORGANTE (ID_TRAMITE, 5) CURP,                               
ID_GARANTIA,                               
FN_DESC_GARANTIA (ID_GARANTIA, 85) DESC_TIPOS_BIENES                          
FROM RUG.V_BUSQUEDA_TRAMITE_BASE                         
WHERE 1 = 1 ';


         /************************/
         /****** F O L  I O ******/
         /************************/
        IF vlFolio IS NOT NULL THEN

             /*VERIFICA SI EXISTE ESE FOLIO */
            SELECT
                       ID_TRAMITE BULK COLLECT
            INTO       v_folio
            FROM
                       RUG.RUG_REL_TRAM_PARTES A
                       INNER JOIN
                                  RUG.RUG_PERSONAS B
                                  ON
                                             A.ID_PERSONA = B.ID_PERSONA
            WHERE
                       TRIM(UPPER(B.FOLIO_MERCANTIL)) = vlFolio
                       AND A.ID_PARTE                 = 1
                       AND A.STATUS_REG               = 'AC'
            ;


            IF v_folio.FIRST IS NOT NULL THEN

                FOR i IN v_folio.FIRST .. v_folio.LAST
                LOOP

                    IF v_folio(i) IS NOT NULL THEN

                        SELECT
                               COUNT(ID_TRAMITE)
                        INTO   vlcont2
                        FROM
                               RUG.V_BUSQUEDA_TRAMITE_BASE
                        WHERE
                               ID_TRAMITE = TO_NUMBER(v_folio(i))
                        ;

                        IF vlcont2 > 0
                            AND
                            vlmil2 < 1000 THEN

                            vlmil2 := vlmil2 + 1;

                            vl_folio := vl_folio
                            || TO_CHAR(v_folio(i))
                            || ',';

                        END IF;

                        vlcont2 := NULL;

                        EXIT WHEN vlmil2 > 1000;

                    END IF;

                END LOOP;


                IF (vlmil2 IS NULL
                    OR
                    vlmil2 = 0)
                    AND
                    vl_folio IS NULL THEN

                    vlConsulta := vlConsulta
                    || 'AND ID_TRAMITE IN (1) ';
                ELSE
                    vl_folio := RTRIM(vl_folio, ',');

                    vlConsulta := vlConsulta
                    || 'AND ID_TRAMITE IN ( '
                    || vl_folio
                    || ') ';

                END IF;

            ELSE
                vlConsulta := vlConsulta
                || 'AND ID_TRAMITE IN (1) ';
            END IF;

        END IF;

         /************************/
         /*** G A R A N T I A ****/
         /************************/
        IF vlGarantia IS NOT NULL THEN

            vlConsulta := vlConsulta
            || 'AND (ID_GARANTIA ='
            || vlGarantia
            --|| ' OR ID_TRAMITE = '
            --|| vlGarantia
            || ') ';

        END IF;

         /************************/
         /*******  C U R P *******/
         /************************/

        IF vlCurp IS NOT NULL THEN



             /*VERIFICA SI EXISTE ESE CURP */
            SELECT
                       ID_TRAMITE BULK COLLECT
            INTO       v_curp
            FROM
                       RUG.RUG_REL_TRAM_PARTES A
                       INNER JOIN
                                  RUG.RUG_PERSONAS_FISICAS B
                                  ON
                                             A.ID_PERSONA = B.ID_PERSONA
            WHERE
                       B.CURP       = vlCurp
                       AND A.ID_PARTE   IN (1,2)
                       AND A.STATUS_REG = 'AC'
                       AND ROWNUM      <= 2500
            ;


            IF v_curp.FIRST IS NOT NULL THEN

                FOR i IN v_curp.FIRST .. v_curp.LAST
                LOOP

                    IF v_curp(i) IS NOT NULL THEN

                        SELECT
                               COUNT(ID_TRAMITE)
                        INTO   vlcont3
                        FROM
                               RUG.V_BUSQUEDA_TRAMITE_BASE
                        WHERE
                               ID_TRAMITE = TO_NUMBER(v_curp(i))
                        ;

                        IF vlcont3 > 0
                            AND
                            vlmil3 < 1000 THEN

                            vlmil3 := vlmil3 + 1;

                            vl_curp := vl_curp
                            || TO_CHAR(v_curp(i))
                            || ',';

                        END IF;

                        vlcont3 := NULL;

                        EXIT WHEN vlmil3 > 1000;

                    END IF;

                END LOOP;


                IF (vlmil3 IS NULL
                    OR
                    vlmil3 = 0)
                    AND
                    vl_curp IS NULL THEN

                    vlConsulta := vlConsulta
                    || 'AND ID_TRAMITE IN (1) ';

                ELSE

                    vl_curp := RTRIM(vl_curp, ',');

                    vlConsulta := vlConsulta
                    || 'AND ID_TRAMITE IN ( '
                    || vl_curp
                    || ') ';

                END IF;

            ELSE
                vlConsulta := vlConsulta
                || 'AND ID_TRAMITE IN (1) ';
            END IF;

        END IF;


         /************************/
         /*******  RFC      *******/

         /************************/

        IF vlRfc IS NOT NULL THEN
             /*VERIFICA SI EXISTE ESE RFC */
            SELECT
                       A.ID_TRAMITE BULK COLLECT
            INTO       v_rfc
            FROM
                       RUG.RUG_REL_TRAM_PARTES A
                       INNER JOIN
                                  RUG.RUG_PERSONAS B
                                  ON
                                             A.ID_PERSONA = B.ID_PERSONA
            WHERE
                       B.RFC          = vlRfc
                       AND A.ID_PARTE IN (1,2)

                       AND A.STATUS_REG = 'AC'
                       AND ROWNUM      <= 2500
            ;


            IF v_rfc.FIRST IS NOT NULL THEN

                FOR i IN v_rfc.FIRST .. v_rfc.LAST
                LOOP

                    IF v_rfc(i) IS NOT NULL THEN

                        SELECT
                               COUNT(ID_TRAMITE)
                        INTO   vlcont3
                        FROM
                               RUG.V_BUSQUEDA_TRAMITE_BASE
                        WHERE
                               ID_TRAMITE = TO_NUMBER(v_rfc(i))
                        ;

                        IF vlcont3 > 0
                            AND
                            vlmil3 < 1000 THEN

                            vlmil3 := vlmil3 + 1;

                            vl_rfc := vl_rfc
                            || TO_CHAR(v_rfc(i))
                            || ',';

                        END IF;

                        vlcont3 := NULL;

                        EXIT WHEN vlmil3 > 1000;

                    END IF;

                END LOOP;


                IF (vlmil3 IS NULL
                    OR
                    vlmil3 = 0)
                    AND
                    vl_rfc IS NULL THEN

                    vlConsulta := vlConsulta
                    || 'AND ID_TRAMITE IN (1) ';

                ELSE

                    vl_rfc := RTRIM(vl_rfc, ',');

                    vlConsulta := vlConsulta
                    || 'AND ID_TRAMITE IN ( '
                    || vl_rfc
                    || ') ';

                END IF;

            ELSE
                vlConsulta := vlConsulta
                || 'AND ID_TRAMITE IN (1) ';
            END IF;

        END IF;



         /************************************************/
         /*** N O M B R E   D E L  DEUDOR *****/
         /************************************************/

        IF vlNombre IS NOT NULL THEN


             /*Verifica Si Existe El Nombre Del Deudor garante*/
            SELECT
                   ID_TRAMITE BULK COLLECT
            INTO   v_nombreot
            FROM
                   (
                            SELECT DISTINCT
                                     (ID_TRAMITE)
                            FROM
                                     RUG.RUG_PERSONAS_H
                            WHERE
                                     ID_PARTE IN (1,2)
                                     AND TRIM(UPPER(TRIM(NOMBRE_PERSONA)
                                              || ' '
                                              || TRIM(AP_PATERNO)
                                              || ' '
                                              || TRIM(AP_MATERNO))
                                              || ' '
                                              || TRIM(UPPER(RAZON_SOCIAL))) LIKE ('%'
                                              || vlNombre
                                              || '%')
                            ORDER BY
                                     ID_TRAMITE DESC
                   )
            WHERE
                   ROWNUM <= 2500
            ;


             /*Limita El Proceso A 1000 Registros */
            IF v_nombreot.FIRST IS NOT NULL THEN

                FOR i IN v_nombreot.FIRST .. v_nombreot.LAST
                LOOP

                    IF v_nombreot(i) IS NOT NULL THEN

                        SELECT
                               COUNT(ID_TRAMITE)
                        INTO   vlcont1
                        FROM
                               RUG.V_BUSQUEDA_TRAMITE_BASE
                        WHERE
                               ID_TRAMITE = TO_NUMBER(v_nombreot(i))
                        ;

                        IF vlcont1 > 0
                            AND
                            vlmil < 1000 THEN

                            vlmil := vlmil + 1;

                            vlNombreOt := vlNombreOt
                            || TO_CHAR(v_nombreot(i))
                            || ',';

                        END IF;


                        vlcont1 := NULL;

                        EXIT WHEN vlmil > 1000;
                    END IF;
                END LOOP;


                IF (vlmil IS NULL
                    or
                    vlmil= 0)
                    AND
                    vlNombreOt IS NULL THEN

                    vlConsulta := vlConsulta
                    || 'AND ID_TRAMITE IN (1) ';
                ELSE
                    vlNombreOt := RTRIM(vlNombreOt, ',');

                    vlConsulta := vlConsulta
                    || 'AND ID_TRAMITE IN ( '
                    || vlNombreOt
                    || ') ';
                END IF;



            ELSE
                vlConsulta := vlConsulta
                || 'AND ID_TRAMITE IN (1) ';
            END IF;

        END IF;


		/** NO. SERIAL **/

		IF peNumeroSerial IS NOT NULL THEN

			/* verifica si existe ese numero serial */
			SELECT 
				ID_TRAMITE BULK COLLECT 
			INTO 	v_serial
			FROM 	(
						SELECT
                                     ID_TRAMITE
                            FROM
                                     RUG_GARANTIAS_BIENES
                            WHERE
                                     trim(IDENTIFICADOR) = peNumeroSerial
                            ORDER BY
                                     ID_TRAMITE DESC
					)
			WHERE
				ROWNUM <= 1000
            ;

			IF v_serial.FIRST IS NOT NULL THEN

                FOR i IN v_serial.FIRST .. v_serial.LAST
                LOOP

                    IF v_serial(i) IS NOT NULL THEN

                        vlSerialBienes := vlSerialBienes
                        || TO_CHAR(v_serial(i))
                        || ',';

                    END IF;

                END LOOP;

                vlSerialBienes := RTRIM(vlSerialBienes, ',');

                vlConsulta := vlConsulta
                || 'AND ID_TRAMITE IN ( '
                || vlSerialBienes
                || ') ';

            ELSE

                vlConsulta := vlConsulta
                || 'AND ID_TRAMITE IN (1) ';

            END IF;

		END IF;

         /***********************************************************/
         /****** D E S C R I P C I O N    D E   B I E N E S *********/
         /***********************************************************/

        IF vlDescBienMueble IS NOT NULL THEN

             /*Verifica si existe ese descripcion*/
            SELECT
                   ID_TRAMITE BULK COLLECT
            INTO   v_descripcion
            FROM
                   (
                            SELECT
                                     ID_TRAMITE
                            FROM
                                     RUG.RUG_TBL_BUSQUEDA
                            WHERE
                                     CONTAINS (DESC_GARANTIA, vlDescBienMueble) > 0
                            ORDER BY
                                     ID_TRAMITE DESC
                   )
            WHERE
                   ROWNUM <= 1000
            ;


            IF v_descripcion.FIRST IS NOT NULL THEN

                FOR i IN v_descripcion.FIRST .. v_descripcion.LAST
                LOOP

                    IF v_descripcion(i) IS NOT NULL THEN

                        vlDescBienes := vlDescBienes
                        || TO_CHAR(v_descripcion(i))
                        || ',';

                    END IF;

                END LOOP;

                vlDescBienes := RTRIM(vlDescBienes, ',');

                vlConsulta := vlConsulta
                || 'AND ID_TRAMITE IN ( '
                || vlDescBienes
                || ') ';

            ELSE

                vlConsulta := vlConsulta
                || 'AND ID_TRAMITE IN (1) ';

            END IF;


        END IF;


        vlConsulta := vlConsulta
        || ' )                                                     
SELECT ID_TRAMITE, ID_TIPO_TRAMITE, FECHA_CREACION, DESCRIPCION,                                                            
NOMBRE, FOLIO_MERCANTIL, ID_GARANTIA, DESC_TIPOS_BIENES                                                       
FROM TRAMITE_BASE ';

        vlTotalReg := 'SELECT COUNT(ID_TRAMITE) FROM ( '
        || vlConsulta
        || ')';

        EXECUTE IMMEDIATE vlTotalReg INTO vlTotal;

        peNumRegistros:= vlTotal;

        vlConsulta := vlConsulta
        || '  WHERE RN BETWEEN '
        || vlInicio
        || ' AND '
        || vlFin
        || ' ORDER BY ID_GARANTIA DESC ';

        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'peNumRegistros', peNumRegistros , 'OUT');

        SELECT
               CASE
                      WHEN LENGTH(vlconsulta) < 4000
                             THEN SUBSTR( vlconsulta, 1, LENGTH(vlconsulta))
                             ELSE SUBSTR( vlconsulta, 1, 4000)
               END
        INTO   vltrunc
        FROM
               DUAL
        ;

        REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'Consulta', vltrunc , 'OUT');


        OPEN psCursorConsulta FOR vlConsulta;

		INSERT INTO RUG_CONSULTA_REGISTRO(ID_CONSULTA_REG,ID_PERSONA,TOTAL_RESULTADO,CONSULTA,RESPUESTA,ID_TIPO_TRAMITE,FECHAHORA,ESTATUS)
		VALUES(SEQ_CONSULTA_REG.NEXTVAL,peIdPersona,peNumRegistros,vltrunc,null,peTipoTramite,sysdate,'AC');

    END IF;


EXCEPTION
WHEN Ex_Error THEN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'psResult', vlPsResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'psTxResult', vlPsTxtResult, 'OUT');

WHEN Ex_TramiteSinSaldo  THEN
    vlPsResult   :=789;
    vlPsTxtResult:= 'NO TIENE SALDO PARA HACER LA OPERACION';
    ROLLBACK;
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'psResult', vlPsResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'psTxResult', vlPsTxtResult, 'OUT');    

WHEN OTHERS THEN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'psResult', 999, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_CONSULTA_GARANTIAS_REG', 'psTxResult', substr(SQLCODE
    ||':'
    ||SQLERRM,1,250), 'OUT');


END SP_CONSULTA_GARANTIAS_REG;
/

