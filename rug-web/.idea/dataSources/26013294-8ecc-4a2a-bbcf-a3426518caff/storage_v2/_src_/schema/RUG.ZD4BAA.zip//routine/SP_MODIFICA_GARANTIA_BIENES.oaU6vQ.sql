create PROCEDURE         SP_MODIFICA_GARANTIA_BIENES
(    
    peIdTramiteGarantia     IN RUG_GARANTIAS_BIENES.ID_GARAN_BIEN%TYPE,  -- 1  IDENTIFICADOR DEL TRAMITE ASOCIADO A LA GARANTIA
	peTipoBienEspecial		IN RUG_GARANTIAS_BIENES.TIPO_BIEN_ESPECIAL%TYPE, -- 2
	peTipoIdentificador		IN RUG_GARANTIAS_BIENES.TIPO_IDENTIFICADOR%TYPE, -- 3
	peIdentificador 		IN RUG_GARANTIAS_BIENES.IDENTIFICADOR%TYPE, -- 4
	peDescripcionBien		IN RUG_GARANTIAS_BIENES.DESCRIPCION_BIEN%TYPE, -- 5
	peSerie                 IN RUG_GARANTIAS_BIENES.SERIE%TYPE,
    psResult               OUT INTEGER,  -- 6
    psTxResult             OUT VARCHAR2  -- 7
)
IS

--vIdTram                 RUG_REL_TRAM_INC_GARAN.ID_TRAMITE_TEMP%TYPE;
vIdGarantiaBien         RUG_GARANTIAS_BIENES_PEND.ID_GARAN_BIEN_PEND%TYPE;

Ex_Error  EXCEPTION;

BEGIN

      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_BIENES', 'peIdTramiteGarantia', CAST(peIdTramiteGarantia AS VARCHAR2), 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_BIENES', 'peTipoBienEspecial', CAST(peTipoBienEspecial AS VARCHAR2), 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_BIENES', 'peTipoIdentificador', CAST(peTipoIdentificador AS VARCHAR2), 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_BIENES', 'peIdentificador', peIdentificador , 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_BIENES', 'peDescripcionBien', peDescripcionBien , 'IN');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_BIENES', 'peSerie', peSerie , 'IN');

      BEGIN
        SELECT ID_GARAN_BIEN_PEND
        INTO vIdGarantiaBien
        FROM RUG_GARANTIAS_BIENES_PEND
        WHERE ID_GARAN_BIEN_PEND = peIdTramiteGarantia;       
       Exception
         WHEN NO_DATA_FOUND THEN
            psResult := 16;
            RAISE Ex_Error;
      END;


      IF vIdGarantiaBien IS NOT NULL THEN

        UPDATE RUG_GARANTIAS_BIENES_PEND
            SET TIPO_BIEN_ESPECIAL = peTipoBienEspecial,
                TIPO_IDENTIFICADOR = peTipoIdentificador,
                IDENTIFICADOR = peIdentificador,
                DESCRIPCION_BIEN = peDescripcionBien,
                SERIE = peSerie
        WHERE ID_GARAN_BIEN_PEND = peIdTramiteGarantia;

        psResult := 0;

        psTxResult := 'ALTA BIEN EXITOSA';

        COMMIT;

        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_BIENES', 'psResult', psResult, 'OUT');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_BIENES', 'psTxResult', psTxResult, 'OUT');

      END IF;
EXCEPTION
WHEN Ex_Error THEN
      psTxResult := RUG.FN_MENSAJE_ERROR(psResult);
      ROLLBACK;      
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_BIENES', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_BIENES', 'psTxResult', psTxResult, 'OUT');

WHEN OTHERS THEN
      psResult  := 999;
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;      
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_BIENES', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_MODIFICA_GARANTIA_BIENES', 'psTxResult', psTxResult, 'OUT');
END SP_MODIFICA_GARANTIA_BIENES;
/

