create view V_GARANTIAS_CONTR_RECERR as
SELECT   a.ID_GARANTIA,
            a.ID_TIPO_GARANTIA,
            a.TIPO_GARANTIA,
            a.FECHA_CELEB_ACTO,
            a.MONTO_LIMITE,
            a.OTROS_TERMINOS_GARANTIA,
            a.DESC_BIENES_MUEBLES,
            a.TIPO_CONTRATO,
            a.FECHA_CELEB_CONTRATO,
            a.OTROS_TERMINOS_CONTRATO,
            a.VIGENCIA,
            a.RELACION_BIEN,
            a.ID_TIPO_BIEN,
            a.DESC_TIPO_BIEN,
            a.ID_TRAMITE_TEMP,
            A.ID_MONEDA,
            RCM.DESC_MONEDA
     FROM   V_GARANTIA_CONTR_BASICO a,
            TRAMITES_RUG_INCOMP B,
            RUG_CAT_MONEDAS RCM
    WHERE       A.ID_TRAMITE_TEMP = B.ID_TRAMITE_TEMP
            AND A.ID_MONEDA = RCM.ID_MONEDA
            AND B.ID_TIPO_TRAMITE = 6            /* rectificacion por error */
            AND B.ID_STATUS_TRAM <> 3
/

