create PROCEDURE           ELIMINA_FIN_VIGENCIA AS


CURSOR  CTRAMITES IS
SELECT ID_TRAMITE_TEMP FROM RUG_BITAC_TRAMITES
WHERE ID_TRAMITE_TEMP IN ( 
                            SELECT ID_TRAMITE_TEMP FROM RUG_BITAC_TRAMITES
                             WHERE TO_CHAR(FECHA_STATUS, 'hH24:MI:SS') = '00:00:00'
                            AND ID_STATUS = 3
                         )
AND ID_STATUS = 3
AND STATUS_REG = 'AC'
AND ID_TIPO_TRAMITE = 1;
--AND ID_TRAMITE_TEMP = 81663;


VLVIGENCIA      NUMBER;
VLTRAMITE       NUMBER;
VLTRAMITETEMP   NUMBER;
VLULTIMOTRAMITE NUMBER;
VLSTATUSGARAN   VARCHAR2(3);
VLBANDERA       VARCHAR2(3);
VLUPDATE        VARCHAR2(3);
VLGARANTIA      NUMBER;
V1              VARCHAR2(20); 
V2              VARCHAR2(20);

BEGIN




    OPEN CTRAMITES;
        LOOP

            FETCH CTRAMITES INTO VLTRAMITETEMP;
            EXIT WHEN CTRAMITES%NOTFOUND;


            SELECT ID_TRAMITE 
              INTO VLTRAMITE 
              FROM TRAMITES            
             WHERE ID_TRAMITE_TEMP = VLTRAMITETEMP             
             ;

            SELECT B.ID_GARANTIA, C.GARANTIA_STATUS, C.VIGENCIA
              INTO VLGARANTIA, VLSTATUSGARAN, VLVIGENCIA
              FROM TRAMITES A, 
                   RUG_REL_TRAM_GARAN B,
                   RUG_GARANTIAS C 
             WHERE C.ID_GARANTIA = B.ID_GARANTIA 
               AND A.ID_TRAMITE = B.ID_TRAMITE
               AND A.ID_TRAMITE = VLTRAMITE;-- 3540



               IF(VLSTATUSGARAN = 'FV') THEN
                BEGIN


                    SELECT  CASE 
                              WHEN (ADD_MONTHS(TO_DATE(FECHA_STATUS), 12) < SYSDATE) 
                              THEN 'V' 
                              ELSE 'F' 
                            END VALOR --, TO_CHAR(ADD_MONTHS(TO_DATE(FECHA_STATUS), 12) ), SYSDATE, FECHA_STATUS
                      INTO VLBANDERA
                      FROM RUG_BITAC_TRAMITES
                     WHERE ID_TRAMITE_TEMP = VLTRAMITETEMP-- 22771
                       AND ID_STATUS = 3;


                       IF (VLBANDERA = 'F') THEN


                           SELECT COUNT(*)
                             INTO V1
                             FROM RUG_FIRMA_MASIVA
                            WHERE ID_TRAMITE_TEMP = VLTRAMITETEMP; --22771


                            IF (V1 > 0) THEN


                                INSERT INTO RUG_BITAC_TRAMITES_RESP
                                SELECT * FROM RUG_BITAC_TRAMITES                                   
                                 WHERE ID_TRAMITE_TEMP = VLTRAMITETEMP --22771
                                   AND ID_STATUS = 3;


                                UPDATE RUG_BITAC_TRAMITES
                                   SET FECHA_STATUS = (SELECT A.FECHA_STATUS FROM RUG_BITAC_TRAMITES A, RUG_FIRMA_MASIVA B
                                                        WHERE B.ID_TRAMITE_TEMP = VLTRAMITETEMP
                                                          AND A.ID_TRAMITE_TEMP = B.ID_FIRMA_MASIVA
                                                          AND A.ID_STATUS = 8
                                                      )
                                 WHERE ID_TRAMITE_TEMP = VLTRAMITETEMP --22771
                                   AND ID_STATUS = 3;                           

                            END IF;

                            SELECT ID_ULTIMO_TRAMITE
                              INTO VLULTIMOTRAMITE
                              FROM (
                                        SELECT ID_ULTIMO_TRAMITE 
                                          FROM RUG_GARANTIAS_H
                                         WHERE ID_GARANTIA = VLGARANTIA --4534
                                           AND GARANTIA_STATUS != 'FV'
                                         ORDER BY FECHA_REG DESC
                                   ) 
                             WHERE  ROWNUM = 1;


                            UPDATE RUG_GARANTIAS
                              SET GARANTIA_STATUS = 'AC', ID_ULTIMO_TRAMITE = VLULTIMOTRAMITE
                            WHERE ID_GARANTIA = VLGARANTIA; --4534


                            INSERT INTO RUG_DOMICILIOS_H_RESP
                            SELECT * FROM RUG_DOMICILIOS_H  
                              WHERE ID_TRAMITE IN (                            
                            SELECT ID_ULTIMO_TRAMITE FROM RUG_GARANTIAS_H
                            WHERE ID_GARANTIA = VLGARANTIA
                              AND GARANTIA_STATUS = 'FV');


                            DELETE RUG_DOMICILIOS_H  
                              WHERE ID_TRAMITE IN (                            
                            SELECT ID_ULTIMO_TRAMITE FROM RUG_GARANTIAS_H
                            WHERE ID_GARANTIA = VLGARANTIA
                              AND GARANTIA_STATUS = 'FV');


                            INSERT INTO RUG_TELEFONOS_H_RESP
                            SELECT * FROM RUG_TELEFONOS_H  
                              WHERE ID_TRAMITE IN (                            
                            SELECT ID_ULTIMO_TRAMITE FROM RUG_GARANTIAS_H
                            WHERE ID_GARANTIA = VLGARANTIA
                              AND GARANTIA_STATUS = 'FV');



                            DELETE RUG_TELEFONOS_H  
                              WHERE ID_TRAMITE IN (                            
                            SELECT ID_ULTIMO_TRAMITE FROM RUG_GARANTIAS_H
                            WHERE ID_GARANTIA = VLGARANTIA
                              AND GARANTIA_STATUS = 'FV');



                            INSERT INTO RUG_PERSONAS_H_RESP
                            SELECT * FROM RUG_PERSONAS_H
                            WHERE ID_TRAMITE IN (                            
                            SELECT ID_ULTIMO_TRAMITE FROM RUG_GARANTIAS_H
                            WHERE ID_GARANTIA = VLGARANTIA --4534
                              AND GARANTIA_STATUS = 'FV');

                            DELETE RUG_PERSONAS_H
                            WHERE ID_TRAMITE IN (                            
                            SELECT ID_ULTIMO_TRAMITE FROM RUG_GARANTIAS_H
                            WHERE ID_GARANTIA = VLGARANTIA --4534
                              AND GARANTIA_STATUS = 'FV');


                            INSERT INTO RUG_REL_TRAM_PARTES_RESP                            
                            SELECT * FROM RUG_REL_TRAM_PARTES  
                            WHERE ID_TRAMITE IN (                            
                            SELECT ID_ULTIMO_TRAMITE FROM RUG_GARANTIAS_H
                            WHERE ID_GARANTIA = VLGARANTIA --4534
                              AND GARANTIA_STATUS = 'FV');



                            DELETE RUG_REL_TRAM_PARTES  
                            WHERE ID_TRAMITE IN (                            
                            SELECT ID_ULTIMO_TRAMITE FROM RUG_GARANTIAS_H
                            WHERE ID_GARANTIA = VLGARANTIA --4534
                              AND GARANTIA_STATUS = 'FV');


                            INSERT INTO RUG_BITAC_TRAMITES_RESP
                            SELECT * FROM RUG_BITAC_TRAMITES
                            WHERE ID_TRAMITE_TEMP IN (                            
                                                        SELECT ID_TRAMITE_TEMP 
                                                          FROM RUG_GARANTIAS_H A, TRAMITES B 
                                                         WHERE ID_GARANTIA = VLGARANTIA ---4534
                                                           AND GARANTIA_STATUS = 'FV'
                                                           AND A.ID_ULTIMO_TRAMITE = B.ID_TRAMITE
                                                      );  


                            DELETE RUG_BITAC_TRAMITES
                            WHERE ID_TRAMITE_TEMP IN (                            
                                                        SELECT ID_TRAMITE_TEMP 
                                                          FROM RUG_GARANTIAS_H A, TRAMITES B 
                                                         WHERE ID_GARANTIA = VLGARANTIA ---4534
                                                           AND GARANTIA_STATUS = 'FV'
                                                           AND A.ID_ULTIMO_TRAMITE = B.ID_TRAMITE
                                                      );


                            INSERT INTO RUG_REL_TRAM_GARAN_RESP
                            SELECT * FROM RUG_REL_TRAM_GARAN
                             WHERE ID_TRAMITE IN (                            
                                                    SELECT ID_ULTIMO_TRAMITE 
                                                      FROM RUG_GARANTIAS_H  
                                                     WHERE ID_GARANTIA = VLGARANTIA ---4534
                                                       AND GARANTIA_STATUS = 'FV'                                                       
                                                );            



                            DELETE RUG_REL_TRAM_GARAN
                             WHERE ID_TRAMITE IN (                            
                                                    SELECT ID_ULTIMO_TRAMITE 
                                                      FROM RUG_GARANTIAS_H  
                                                     WHERE ID_GARANTIA = VLGARANTIA ---4534
                                                       AND GARANTIA_STATUS = 'FV'                                                       
                                                );            

                            INSERT INTO TRAMITES_RESP
                            SELECT * FROM  TRAMITES
                            WHERE ID_TRAMITE IN (                            
                                                    SELECT ID_ULTIMO_TRAMITE 
                                                      FROM RUG_GARANTIAS_H  
                                                     WHERE ID_GARANTIA = VLGARANTIA ---4534
                                                       AND GARANTIA_STATUS = 'FV'                                                       
                                                );


                            DELETE TRAMITES
                            WHERE ID_TRAMITE IN (                            
                                                    SELECT ID_ULTIMO_TRAMITE 
                                                      FROM RUG_GARANTIAS_H  
                                                     WHERE ID_GARANTIA = VLGARANTIA ---4534
                                                       AND GARANTIA_STATUS = 'FV'                                                       
                                                );                                                    



                       END IF;


                END;
               END IF;

        END LOOP;

    CLOSE CTRAMITES;    

COMMIT;

EXCEPTION

WHEN OTHERS THEN      
      ROLLBACK;      
END;
/

