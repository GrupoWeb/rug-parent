create PROCEDURE         SP_ALTA_CATALOGO_PALABRAS (
   peIdTramite       IN     NUMBER,
   peIdTipoTramite   IN     NUMBER,
   psResult             OUT NUMBER,
   psTxResult           OUT VARCHAR2
)
IS
   vlDescGarantia     CLOB;
   vlIdGarantia       NUMBER;  
   vlIdTramiteTemp    NUMBER;
   vlIdGarantiaPend   NUMBER;
BEGIN
   SELECT   ID_TRAMITE_TEMP
     INTO   vlIdTramiteTemp
     FROM   TRAMITES
    WHERE   ID_TRAMITE = peIdTramite;

   --SE BORRAN LOS TRAMITES DE LA GARANTIA
   IF peIdTipoTramite IN (2, 6, 7, 8
                                 , 23 ) -- /* GGR 23.08.2013   MMSECN2013-82 */
   THEN
      BEGIN
         SELECT   ID_GARANTIA
           INTO   vlIdGarantia
           FROM   RUG_REL_TRAM_GARAN
          WHERE   ID_TRAMITE = peIdTramite;

         IF vlIdGarantia IS NOT NULL
         THEN
            DELETE FROM   RUG_TBL_BUSQUEDA
                  WHERE   ID_TRAMITE IN (SELECT   ID_TRAMITE
                                           FROM   V_OPERACIONES_GARANTIA
                                          WHERE   ID_GARANTIA = vlIdGarantia);
         END IF;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            DBMS_OUTPUT.PUT_LINE ('El tramite No existe');
      END;
   END IF;

   --SE BORRAN LOS TRAMITES ANOTACI? SIN GARANTIA DE LA B?QUEDA CUANDO HAY UNA CANCELACION -- /* GGR 27.08.2013   MMSECN2013-81 */
   IF peIdTipoTramite IN ( 27 ) 
   THEN
      BEGIN


        DELETE 
          FROM   RUG_TBL_BUSQUEDA
         WHERE   ID_TRAMITE = peIdTramite
            OR   ID_TRAMITE IN (SELECT ID_ANOTACION_PADRE
                                  FROM V_ANOTACION_TRAMITES 
                                 WHERE ID_STATUS_TRAM = 3
                                   AND ID_TRAMITE = peIdTramite);
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            DBMS_OUTPUT.PUT_LINE ('El tramite No existe');
      END;
   END IF;

   --SE INSERTA LA NUEVA DESCRIPCION A LA TABLA DE BUSQUEDA
   IF peIdTipoTramite IN (1, 2, 6, 7, 8)
   THEN
      SELECT   ID_GARANTIA_PEND
        INTO   vlIdGarantiaPend
        FROM   RUG_REL_TRAM_INC_GARAN
       WHERE   ID_TRAMITE_TEMP = vlIdTramiteTemp
       AND     ROWNUM = 1;

      SELECT   DESC_GARANTIA
        INTO   vlDescGarantia
        FROM   RUG_GARANTIAS_PENDIENTES
       WHERE   ID_GARANTIA_PEND = vlIdGarantiaPend;

   ELSIF peIdTipoTramite = 3
   THEN
      SELECT   DESC_BIENES
        INTO   vlDescGarantia
        FROM   AVISOS_PREV
       WHERE   ID_TRAMITE_TEMP = vlIdTramiteTemp;

   ELSIF peIdTipoTramite = 10
   THEN
      SELECT   ANOTACION
        INTO   vlDescGarantia
        FROM   RUG_ANOTACIONES_SIN_GARANTIA
       WHERE   ID_TRAMITE_TEMP = vlIdTramiteTemp;

   /* GGR  - 24.04.13  -  MMSECN2013-81   MMSECN2013-82   INICIO */       
   ELSIF peIdTipoTramite IN (28) THEN

      SELECT   ANOTACION 
        INTO   vlDescGarantia
        FROM   RUG_ANOTACIONES_SEG_INC_CSG
       WHERE   ID_ANOTACION_TEMP = vlIdTramiteTemp;

   /* GGR  - 24.04.13  -  MMSECN2013-81  MMSECN2013-82   FIN */
   END IF;


   INSERT INTO RUG.RUG_TBL_BUSQUEDA
     VALUES   (peIdTramite, vlDescGarantia);

   psResult := 0;
   psTxResult := 'Proceso exitoso';
EXCEPTION
   WHEN OTHERS
   THEN
      psResult := 999;
      psTxResult := SUBSTR (SQLCODE || ':' || SQLERRM, 1, 250);
      ROLLBACK;
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                     'SP_ALTA_CATALOGO_PALABRAS',
                     'psResult',
                     psResult,
                     'OUT');
      REG_PARAM_PLS (SEQ_RUG_PARAM_PLS.NEXTVAL,
                     'SP_ALTA_CATALOGO_PALABRAS',
                     'psTxResult',
                     psTxResult,
                     'OUT');
      DBMS_OUTPUT.PUT_LINE (psTxResult);
END;
/

