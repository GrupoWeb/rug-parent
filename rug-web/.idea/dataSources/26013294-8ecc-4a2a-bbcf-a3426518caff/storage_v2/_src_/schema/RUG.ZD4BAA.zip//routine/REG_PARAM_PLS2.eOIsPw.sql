create PROCEDURE     REG_PARAM_PLS2
( 
    peObjeto          IN   RUG_PARAM_PLS.OBJETO%TYPE,
    peNomParametro    IN   RUG_PARAM_PLS.NOM_PARAMETRO%TYPE,
    peValor           IN   RUG_PARAM_PLS.VALOR%TYPE,
    peTipoParametro   IN   RUG_PARAM_PLS.TIPO_PARAMETRO%TYPE
)
IS
psTxResult VARCHAR2(3000);
PRAGMA AUTONOMOUS_TRANSACTION;


BEGIN

INSERT INTO RUG_PARAM_PLS
VALUES(SEQ_RUG_PARAM_PLS.NEXTVAL, peObjeto, peNomParametro, peValor, SYSDATE, 'AC', peTipoParametro);     

COMMIT;


  EXCEPTION 
   WHEN OTHERS THEN 
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,3000);

      INSERT INTO RUG_PARAM_PLS
      VALUES(SEQ_RUG_PARAM_PLS.NEXTVAL, peObjeto, peNomParametro,psTxResult , SYSDATE, 'AC', peTipoParametro);   

END REG_PARAM_PLS2;
/

