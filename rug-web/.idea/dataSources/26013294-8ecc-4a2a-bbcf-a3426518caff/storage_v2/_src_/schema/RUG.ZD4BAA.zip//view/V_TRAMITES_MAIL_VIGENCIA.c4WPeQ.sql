create view V_TRAMITES_MAIL_VIGENCIA as
SELECT
         TRA.ID_TRAMITE_TEMP
       , TRA.ID_TRAMITE
       , TRA.ID_TIPO_TRAMITE
       , RGA.ID_GARANTIA
       , TO_CHAR ( TO_DATE ( TO_CHAR ( ADD_MONTHS ( DECODE (USR.NOMBRE_TABLA, 'RUG_FIRMA_DOCTOS', RBB.FECHA_STATUS - 6 / 24, RBB.FECHA_STATUS), RGA.VIGENCIA*12 ), 'DD/MM/YYYY HH24:MI' ), 'DD/MM/YYYY HH24:MI' ) + 1 / (24 * 60), 'DD/MM/YYYY HH24:MI' ) FECHA_TERM
       , USR.USUARIO_MAIL
       , ACR.Acreedor
       , ACR.Acreedor_MAIL
       , 0 ID_ANOTACION
  FROM
         RUG.RUG_GARANTIAS_H    RGH
       , RUG.TRAMITES           TRA
       , RUG.RUG_BITAC_TRAMITES RBB
       , (
                SELECT
                       ID_GARANTIA
                     , VIGENCIA
                FROM
                       RUG.RUG_GARANTIAS
                WHERE
                       GARANTIA_STATUS = 'AC'
         )
         RGA
       , (
                SELECT
                       A.ID_TRAMITE_TEMP
                     , B.CVE_USUARIO USUARIO_MAIL
                     , A.NOMBRE_TABLA
                FROM
                       V_TRAMITES_FIRMA  A
                     , RUG_SECU_USUARIOS B
                WHERE
                       ID_USUARIO_FIRMO = B.ID_PERSONA
         )
         USR
       , (
                SELECT
                       id_tramite
                     , e_mail Acreedor_MAIL
                     , CASE part.PER_JURIDICA
                              WHEN 'PF'
                                     THEN
                                     (
                                            SELECT
                                                   TRIM(INITCAP( Nombre_Persona
                                                          || ' '
                                                          || ap_paterno
                                                          || ' '
                                                          || ap_materno))
                                            FROM
                                                   RUG_PERSONAS_FISICAS
                                            WHERE
                                                   id_persona = part.id_persona
                                     )
                              WHEN 'PM'
                                     THEN
                                     (
                                            SELECT
                                                   razon_social
                                            FROM
                                                   RUG_PERSONAS_MORALES
                                            WHERE
                                                   id_persona = part.id_persona
                                     )
                       END Acreedor
                FROM
                       rug.RUG_REL_TRAM_PARTES part
                     , rug_personas            per
                WHERE
                       1                   = 1 --                 and id_tramite = 593160
                       AND id_parte        = 4
                       AND part.id_persona = per.id_persona
         )
         ACR
  WHERE
         RGH.ID_ULTIMO_TRAMITE   = TRA.ID_TRAMITE
         AND TRA.ID_TRAMITE      = ACR.ID_TRAMITE
         AND RBB.ID_TRAMITE_TEMP = USR.ID_TRAMITE_TEMP
         AND TRA.ID_TRAMITE_TEMP = RBB.ID_TRAMITE_TEMP
         AND RGH.ID_GARANTIA     = RGA.ID_GARANTIA
         AND TRA.B_CARGA_MASIVA <> -1
         AND TRA.ID_TIPO_TRAMITE IN (1
                                   , 31)
         AND RBB.ID_STATUS                                                          = 3
         AND RBB.STATUS_REG                                                         = 'AC'
         AND TO_CHAR (ADD_MONTHS (RBB.FECHA_STATUS, RGA.VIGENCIA*12), 'dd/mm/yyyy') = TO_CHAR (SYSDATE + 15, 'dd/mm/yyyy') -- 15 Dias antes se envia el correo
  UNION
  SELECT
         TRA.ID_TRAMITE_TEMP
       , TRA.ID_TRAMITE
       , TRA.ID_TIPO_TRAMITE
       , RGA.ID_GARANTIA
       , TO_CHAR( ADD_MONTHS (TO_DATE('15/04/2018 01:00:00','dd/MM/yyyy hh24:mi:ss'), RGA.VIGENCIA*12), 'DD/MM/YYYY HH24:MI' ) FECHA_TERM
       , USR.USUARIO_MAIL
       , ACR.Acreedor
       , ACR.Acreedor_MAIL
       , 0 ID_ANOTACION
  FROM
         RUG.RUG_GARANTIAS_H    RGH
       , RUG.TRAMITES           TRA
       , RUG.RUG_BITAC_TRAMITES RBB
       , (
                SELECT
                       ID_GARANTIA
                     , VIGENCIA
                FROM
                       RUG.RUG_GARANTIAS
                WHERE
                       GARANTIA_STATUS = 'AC'
         )
         RGA
       , (
                SELECT
                       A.ID_TRAMITE_TEMP
                     , B.CVE_USUARIO USUARIO_MAIL
                     , A.NOMBRE_TABLA
                FROM
                       V_TRAMITES_FIRMA  A
                     , RUG_SECU_USUARIOS B
                WHERE
                       ID_USUARIO_FIRMO = B.ID_PERSONA
         )
         USR
       , (
                SELECT
                       id_tramite
                     , e_mail Acreedor_MAIL
                     , CASE part.PER_JURIDICA
                              WHEN 'PF'
                                     THEN
                                     (
                                            SELECT
                                                   TRIM(INITCAP( Nombre_Persona
                                                          || ' '
                                                          || ap_paterno
                                                          || ' '
                                                          || ap_materno))
                                            FROM
                                                   RUG_PERSONAS_FISICAS
                                            WHERE
                                                   id_persona = part.id_persona
                                     )
                              WHEN 'PM'
                                     THEN
                                     (
                                            SELECT
                                                   razon_social
                                            FROM
                                                   RUG_PERSONAS_MORALES
                                            WHERE
                                                   id_persona = part.id_persona
                                     )
                       END Acreedor
                FROM
                       rug.RUG_REL_TRAM_PARTES part
                     , rug_personas            per
                WHERE
                       1                   = 1 --                 and id_tramite = 593160
                       AND id_parte        = 4
                       AND part.id_persona = per.id_persona
         )
         ACR
  WHERE
         RGH.ID_ULTIMO_TRAMITE   = TRA.ID_TRAMITE
         AND TRA.ID_TRAMITE      = ACR.ID_TRAMITE
         AND RBB.ID_TRAMITE_TEMP = USR.ID_TRAMITE_TEMP
         AND TRA.ID_TRAMITE_TEMP = RBB.ID_TRAMITE_TEMP
         AND RGH.ID_GARANTIA     = RGA.ID_GARANTIA
         AND TRA.B_CARGA_MASIVA  = -1
         AND TRA.ID_TIPO_TRAMITE IN (1
                                   , 31)
         AND RBB.ID_STATUS  = 3
         AND RBB.STATUS_REG = 'AC'
         AND TO_CHAR (ADD_MONTHS (TO_DATE('15/04/2018 01:00:00','dd/MM/yyyy hh24:mi:ss'), RGA.VIGENCIA*12), 'dd/mm/yyyy') = TO_CHAR (SYSDATE + 15, 'dd/mm/yyyy') -- 15 Dias antes se envia el correo
/

