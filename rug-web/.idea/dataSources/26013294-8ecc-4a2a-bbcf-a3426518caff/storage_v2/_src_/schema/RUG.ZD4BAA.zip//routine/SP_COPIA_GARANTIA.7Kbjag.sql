create PROCEDURE         SP_COPIA_GARANTIA 
                            (
                                peIdTramiteTemp      IN  RUG_REL_TRAM_INC_GARAN.ID_TRAMITE_TEMP%TYPE,
                                peIdGarantia         IN  NUMBER,
                                psIdGarantiaPend    OUT  NUMBER,
                                psResult            OUT  INTEGER,
                                psTxResult          OUT  VARCHAR2
                            )
IS

vlRelacionBien              NUMBER;
vlIdGarantiaPend            NUMBER;
vlTipoGarantiaAnterior      NUMBER;
vlIdGarantiaPendAnterior    NUMBER;

Ex_ErrParametro EXCEPTION;

--CURSOR cursPartes(cpeIdGarantia IN NUMBER) IS
--   SELECT   RPP.ID_PERSONA, RPP.ID_PARTE, RGP.PER_JURIDICA
--     FROM         RUG_REL_GARANTIA_PARTES RPP
--            INNER JOIN
--               RUG_GARANTIAS RGG
--            ON RPP.ID_RELACION = RGG.ID_RELACION
--         INNER JOIN
--            RUG_PERSONAS RGP
--         ON RPP.ID_PERSONA = RGP.ID_PERSONA
--   WHERE RPP.ID_GARANTIA = cpeIdGarantia;
--   cursPartes_Rec cursPartes%ROWTYPE;

BEGIN

        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_COPIA_GARANTIA', 'peIdTramiteTemp', peIdTramiteTemp, 'IN');
        REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_COPIA_GARANTIA', 'peIdGarantia', peIdGarantia, 'IN');

        SELECT ID_TIPO_GARANTIA
        INTO vlTipoGarantiaAnterior
        FROM RUG_GARANTIAS
        WHERE ID_GARANTIA = peIdGarantia;


        vlIdGarantiaPend := SEQ_GARANTIAS_TEMP.NEXTVAL;

        /*
        INSERT INTO RUG_GARANTIAS_PENDIENTES(ID_GARANTIA_PEND, ID_TIPO_GARANTIA, VIGENCIA, ID_GARANTIA_MODIFICAR)
        VALUES(vlIdGarantiaPend, vlTipoGarantiaAnterior, peVigencia, peIdGarantia);
        */

        INSERT INTO RUG_GARANTIAS_PENDIENTES
        SELECT vlIdGarantiaPend, ID_TIPO_GARANTIA, NUM_GARANTIA, DESC_GARANTIA, MESES_GARANTIA, ID_PERSONA, ID_ANOTACION, ID_RELACION, RELACION_BIEN, VALOR_BIENES,
               TIPOS_BIENES_MUEBLES, UBICACION_BIENES, FOLIO_MERCANTIL, PATH_DOC_GARANTIA, OTROS_TERMINOS_GARANTIA, FECHA_INSCR, FECHA_FIN_GAR, VIGENCIA, GARANTIA_CERTIFICADA,
               GARANTIA_STATUS, ID_ULTIMO_TRAMITE, B_ULTIMO_TRAMITE, MONTO_MAXIMO_GARANTIZADO, ID_GARANTIA, CAMBIOS_BIENES_MONTO, INSTRUMENTO_PUBLICO, ID_MONEDA,NO_GARANTIA_PREVIA_OT,
               ES_PRIORITARIA, OTROS_REGISTROS, TXT_REGISTROS
          FROM RUG_GARANTIAS
         WHERE ID_GARANTIA = peIdGarantia;

         SELECT RELACION_BIEN
           INTO vlRelacionBien
           FROM RUG_GARANTIAS_PENDIENTES
          WHERE ID_GARANTIA_PEND = vlIdGarantiaPend;


         INSERT INTO RUG_REL_GAR_TIPO_BIEN
         SELECT DISTINCT vlIdGarantiaPend, ID_TIPO_BIEN, RELACION_BIEN
           FROM RUG_REL_GAR_TIPO_BIEN
          WHERE RELACION_BIEN = vlRelacionBien;


        --INSERTO RELACION DE PARTES QUE TENIA LA GARANTIA A ESTE NUEVO TRAMITE
--            BEGIN
--            FOR cursPartes_Rec IN cursPartes(peIdGarantia)
--                LOOP
--                INSERT INTO RUG_REL_TRAM_INC_PARTES
--                VALUES(peIdTramiteTemp, cursPartes_Rec.ID_PERSONA, cursPartes_Rec.ID_PARTE, cursPartes_Rec.PER_JURIDICA, 'AC', SYSDATE);
--
--
--                END LOOP;
--            END;

         SELECT ID_GARANTIA_PEND
         INTO vlIdGarantiaPendAnterior
         FROM RUG_GARANTIAS
         WHERE ID_GARANTIA =  peIdGarantia;

         -- INSERTO LOS CONTRATOS QUE TENIA ESTA GARANTIA PARA CONSISTENCIA EN DETALLE
         INSERT INTO RUG_CONTRATO
         SELECT SEQ_CONTRATO.NEXTVAL, vlIdGarantiaPend, CONTRATO_NUM, FECHA_INICIO, FECHA_FIN, OTROS_TERMINOS_CONTRATO, MONTO_LIMITE, OBSERVACIONES, TIPO_CONTRATO, peIdTramiteTemp, SYSDATE, 'AC', ID_USUARIO, CLASIF_CONTRATO
         FROM RUG_CONTRATO
         WHERE ID_GARANTIA_PEND = vlIdGarantiaPendAnterior
           AND CLASIF_CONTRATO = 'OB';

        INSERT INTO RUG_REL_TRAM_INC_GARAN
        VALUES(vlIdGarantiaPend, peIdTramiteTemp, 'AC', SYSDATE);


        COMMIT;

  psIdGarantiaPend := vlIdGarantiaPend;
  psResult   :=0;
  psTxResult :='Actualizacion finalizada satisfactoriamente';

REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_COPIA_GARANTIA', 'psIdGarantiaPend', psIdGarantiaPend, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_COPIA_GARANTIA', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_COPIA_GARANTIA', 'psTxResult', psTxResult, 'OUT');


EXCEPTION
  WHEN Ex_ErrParametro  THEN
      psTxResult:= substr(psResult,1,250);
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_COPIA_GARANTIA', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_COPIA_GARANTIA', 'psTxResult', psTxResult, 'OUT');


   WHEN OTHERS THEN
      psResult  := 999;
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_COPIA_GARANTIA', 'psResult', psResult, 'OUT');
REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_COPIA_GARANTIA', 'psTxResult', psTxResult, 'OUT');

END;
/

