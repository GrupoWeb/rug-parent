create PROCEDURE         SP_BAJA_CLAVE_RASTREO_AUT 
                                                   (
                                                      peIdTramite       IN    NUMBER,
                                                      peClaveRastreo    IN    VARCHAR2,
                                                      psResult         OUT    NUMBER, 
                                                      psTxResult       OUT    VARCHAR2
                                                   )
IS

vlCantidad      NUMBER;
Ex_Error        EXCEPTION;

BEGIN

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO_AUT', 'peIdTramite', peIdTramite, 'IN');                                                
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO_AUT', 'peClaveRastreo', peClaveRastreo, 'IN');

    SELECT COUNT(*)
      INTO vlCantidad 
      FROM RUG_TRAMITE_RASTREO A,
           TRAMITES_RUG_INCOMP B,
           RUG_FIRMA_MASIVA C,
           TRAMITES_RUG_INCOMP D
     WHERE D.ID_STATUS_TRAM NOT IN (3,8)
       AND D.ID_TRAMITE_TEMP = C.ID_FIRMA_MASIVA
       AND A.ID_TRAMITE_TEMP = C.ID_TRAMITE_TEMP
       AND B.ID_STATUS_TRAM != 3
       AND A.ID_TRAMITE_TEMP = B.ID_TRAMITE_TEMP
       AND A.CVE_RASTREO = peClaveRastreo
       AND A.ID_TRAMITE_TEMP = peIdTramite;



    IF vlCantidad > 0 THEN

        psResult := 85;
        RAISE Ex_Error;

    END IF;

    DELETE RUG_TRAMITE_RASTREO
     WHERE ID_TRAMITE_TEMP = peIdTramite
       AND CVE_RASTREO = peClaveRastreo;

    COMMIT;

    psResult:=0;   
    psTxResult:= RUG.FN_MENSAJE_ERROR(psResult);

    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO_AUT', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO_AUT', 'psTxResult', psTxResult, 'OUT');

EXCEPTION
WHEN Ex_Error  THEN
    psTxResult := RUG.FN_MENSAJE_ERROR(psResult);

    ROLLBACK;
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO_AUT', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO_AUT', 'psTxResult', psTxResult, 'OUT');

WHEN OTHERS THEN

    psResult  := 999;   
    psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
    ROLLBACK;
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO_AUT', 'psResult', psResult, 'OUT');
    REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_BAJA_CLAVE_RASTREO_AUT', 'psTxResult', psTxResult, 'OUT');

END;
/

