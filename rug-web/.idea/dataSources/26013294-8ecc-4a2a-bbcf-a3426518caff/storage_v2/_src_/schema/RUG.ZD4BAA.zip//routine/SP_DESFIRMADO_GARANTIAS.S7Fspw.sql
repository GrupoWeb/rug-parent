create PROCEDURE         SP_DESFIRMADO_GARANTIAS 
                            (                                 
                                psGarantiasInscritas     OUT  NUMBER,
                                psResult            OUT  INTEGER,   
                                psTxResult          OUT  VARCHAR2                             
                            )
IS
                        
    vlIdGarantia            NUMBER ;
    vlCountGarantiasInsc    NUMBER ;    
    vlIdUsuarioRealiza      NUMBER ;
    vlIdInscripcion         NUMBER ;
    vlOutIdTramIncomp       NUMBER ;
    vlOutPsResult           NUMBER ;   
    vlIdTramiteTemp         NUMBER ;
    vlIdPersonaParte        NUMBER ;
    vlCantidad              NUMBER ;
    vlIdTipoBien            NUMBER ;
    vlOutIdGarantia         NUMBER ;
    vlMismoOtorgante        NUMBER ;
    vlCountFolioExiste      NUMBER ;
    vlOutTxtResult          VARCHAR2(4000);  
    vlAnotacionJuez         VARCHAR2(4000);
    vlConcatTipoBien        VARCHAR2(4000);
    vlMismoDeudor           VARCHAR2(2);
    Reg_Personas_H          RUG_PERSONAS_H%ROWTYPE;
    Reg_Contrato_Rug        RUG_CONTRATO%ROWTYPE;
    Reg_Garantias_H         RUG_GARANTIAS_H%ROWTYPE;

    ERRORES             EXCEPTION;

    CURSOR CURS_PER_PART(cpeIdTramiteTemp NUMBER) IS
    SELECT ID_PERSONA, ID_PARTE, PER_JURIDICA, RAZON_SOCIAL, NOMBRE_PERSONA, AP_PATERNO_PERSONA, AP_MATERNO_PERSONA, FOLIO_MERCANTIL, RFC,
           CURP, DECODE(CALLE, NULL, 'F', 'V') B_DOMICILIO, CALLE, NUM_EXTERIOR, NUM_INTERIOR, ID_COLONIA, ID_LOCALIDAD, ID_NACIONALIDAD,
           TELEFONO, EXTENSION, E_MAIL AS EMAIL, UBICA_DOMICILIO_1, UBICA_DOMICILIO_2, POBLACION, ZONA_POSTAL, ID_PAIS_RESIDENCIA
      FROM V_TRAMITES_INCOMP_PARTES
     WHERE ID_TRAMITE = cpeIdTramiteTemp
     AND   ID_PARTE <> 4;

    cursPer_Part_Rec    CURS_PER_PART%ROWTYPE;

     CURSOR CURS_BIENES (cpeIdRelacionBien NUMBER) IS
     SELECT ID_TIPO_BIEN
     FROM RUG_REL_GAR_TIPO_BIEN
     WHERE RELACION_BIEN = cpeIdRelacionBien;

     CURSOR CURS_GARANTIAS_ERROR IS
     SELECT   COLUMN_VALUE AS GARANTIAS_ERROR
     FROM   TABLE (SPLIT_TEM ('16173|16174|16175|16176|16177|16178|16179|16181|16180|16182|16184|16183|16185
                               |16186|16187|16189|16188|16190|16191|16192|16193|16194|16195|16196|16197', '|'));

--     CURSOR CURS_GARANTIAS_ERROR IS
--     SELECT   COLUMN_VALUE AS GARANTIAS_ERROR
--     FROM   TABLE (SPLIT_TEM ('3812|3813|3814', '|'));

BEGIN

    vlCountGarantiasInsc := 0;

    OPEN CURS_GARANTIAS_ERROR;
        LOOP
            FETCH CURS_GARANTIAS_ERROR INTO vlIdGarantia;
            EXIT WHEN CURS_GARANTIAS_ERROR%NOTFOUND;

                SELECT COUNT(*)
                  INTO vlCantidad
                  FROM RUG_GARANTIAS
                 WHERE ID_GARANTIA = vlIdGarantia 
                   AND GARANTIA_STATUS = 'EF';

                IF vlCantidad > 0 THEN

                    --CONTINUE;
                    RAISE ERRORES;    

                END IF;

                vlCantidad := NULL; 


            --------------------------------------------------------------------------------
            ----------------------COMIENZA PROCESO COPIA DE GARANTIA------------------------ 
            --------------------------------------------------------------------------------

                SELECT ID_TRAMITE
                INTO vlIdInscripcion
                FROM V_OPERACIONES_GARANTIA 
                WHERE ID_GARANTIA = vlIdGarantia
                AND ID_TIPO_TRAMITE = 1;

                SELECT ID_PERSONA
                INTO vlIdUsuarioRealiza
                FROM RUG_PERSONAS_H
                WHERE ID_TRAMITE = vlIdInscripcion
                AND ID_PARTE = 5;

                SELECT ID_PERSONA, PER_JURIDICA
                INTO Reg_Personas_H.ID_PERSONA, Reg_Personas_H.PER_JURIDICA
                FROM RUG_PERSONAS_H
                WHERE ID_TRAMITE = vlIdInscripcion
                AND ID_PARTE = 4;


                SELECT ID_TRAMITE_TEMP 
                  INTO vlIdTramiteTemp
                  FROM TRAMITES
                 WHERE ID_TRAMITE = vlIdInscripcion;


               SP_ALTA_TRAMITE_ACREEDOR_REP(vlIdUsuarioRealiza, 1, Reg_Personas_H.ID_PERSONA, 
                                            Reg_Personas_H.PER_JURIDICA, 1, 1, SYSDATE, vlOutIdTramIncomp, vlOutPsResult, vlOutTxtResult);

               IF vlOutPsResult = 0 THEN

                    vlOutPsResult:= NULL;
                    vlOutTxtResult:= NULL;

                    SP_ALTA_BITACORA_TRAMITE2(vlOutIdTramIncomp, 1, 1, NULL, 'V', vlOutPsResult, vlOutTxtResult);

                     IF vlOutPsResult = 0 THEN



                        OPEN CURS_PER_PART(vlIdTramiteTemp);
                            LOOP 
                            FETCH CURS_PER_PART INTO cursPer_Part_Rec;
                            EXIT WHEN CURS_PER_PART%NOTFOUND;


                                IF cursPer_Part_Rec.PER_JURIDICA = 'PF' THEN
                                    UPDATE RUG_PERSONAS_FISICAS
                                    SET CURP = '_'||CURP
                                    WHERE CURP = cursPer_Part_Rec.CURP;
                                END IF;

                                vlOutPsResult:= NULL;
                                vlOutTxtResult:= NULL;

                                IF(cursPer_Part_Rec.ID_PARTE = 2) THEN

                                   SELECT RUG.FN_VALIDA_MISMO_OTORGANTE (vlIdInscripcion, cursPer_Part_Rec.ID_PERSONA)
                                   INTO vlMismoDeudor    
                                   FROM DUAL;

                                END IF;

                                IF cursPer_Part_Rec.ID_PARTE = 2 AND vlMismoDeudor = 'SI' THEN


                                    SELECT ID_PERSONA
                                      INTO vlMismoOtorgante 
                                      FROM RUG_REL_TRAM_INC_PARTES
                                     WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp
                                       AND ID_PARTE = 1
                                       AND STATUS_REG = 'AC'; 

                                    SP_AGREGAR_MISMO_DEUDOR(vlOutIdTramIncomp, vlMismoOtorgante, vlOutPsResult, vlOutTxtResult);


                                    IF vlOutPsResult != 0 THEN                 

                                           vlOutPsResult:= -1;
                                           vlOutTxtResult:= 'SE GENERO ERROR';

                                           --CONTINUE;

                                    END IF;

                                ELSE

                                    vlCountFolioExiste := 0;

                                    SELECT COUNT(*)
                                    INTO vlCountFolioExiste
                                    FROM RUG_PERSONAS
                                    WHERE FOLIO_MERCANTIL =  cursPer_Part_Rec.FOLIO_MERCANTIL
                                    AND PER_JURIDICA = 'PF';

                                    IF vlCountFolioExiste > 0 THEN

                                         SP_REL_PARTE(cursPer_Part_Rec.ID_PERSONA, vlOutIdTramIncomp, 1, cursPer_Part_Rec.RFC, vlOutPsResult, vlOutTxtResult);
                                    ELSE

                                         SP_ALTAPARTE(vlOutIdTramIncomp, cursPer_Part_Rec.ID_PARTE, cursPer_Part_Rec.PER_JURIDICA, cursPer_Part_Rec.RAZON_SOCIAL, 
                                             cursPer_Part_Rec.NOMBRE_PERSONA, cursPer_Part_Rec.AP_PATERNO_PERSONA, cursPer_Part_Rec.AP_MATERNO_PERSONA, 
                                             cursPer_Part_Rec.FOLIO_MERCANTIL, cursPer_Part_Rec.RFC, cursPer_Part_Rec.CURP, cursPer_Part_Rec.B_DOMICILIO, 
                                             cursPer_Part_Rec.CALLE, cursPer_Part_Rec.NUM_EXTERIOR, cursPer_Part_Rec.NUM_INTERIOR, cursPer_Part_Rec.ID_COLONIA, 
                                             cursPer_Part_Rec.ID_LOCALIDAD, vlIdUsuarioRealiza, cursPer_Part_Rec.ID_NACIONALIDAD,cursPer_Part_Rec.TELEFONO, 
                                             cursPer_Part_Rec.EXTENSION, cursPer_Part_Rec.EMAIL, cursPer_Part_Rec.UBICA_DOMICILIO_1,
                                             cursPer_Part_Rec.UBICA_DOMICILIO_2, cursPer_Part_Rec.POBLACION, cursPer_Part_Rec.ZONA_POSTAL, 
                                             cursPer_Part_Rec.ID_PAIS_RESIDENCIA, NULL, NULL, NULL, NULL, NULL, NULL, NULL, vlIdPersonaParte, vlOutPsResult, vlOutTxtResult);                                        

                                    END IF;                        

                                END IF;


                                IF vlOutPsResult != 0 THEN                 

                                    vlOutPsResult:= -1;
                                    vlOutTxtResult:= 'SE GENERO ERROR';                                                                    

                                END IF;  
                        END LOOP;

                        CLOSE CURS_PER_PART;

                        vlOutPsResult:= NULL;
                        vlOutTxtResult:= NULL;

                        SP_ALTA_BITACORA_TRAMITE2(vlOutIdTramIncomp, 1, 2, NULL, 'V', vlOutPsResult, vlOutTxtResult);


                        SELECT COUNT(*) 
                          INTO vlCantidad
                          FROM RUG_AUTORIDAD
                         WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

                         IF(vlCantidad > 0) THEN

                            vlOutPsResult:= NULL;
                            vlOutTxtResult:= NULL;

                            SELECT ANOTACION_JUEZ 
                              INTO vlAnotacionJuez
                              FROM RUG_AUTORIDAD
                             WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;


                            SP_ORDEN_AUTORIDAD(vlOutIdTramIncomp, vlAnotacionJuez, vlOutPsResult, vlOutTxtResult);

                         END IF;   

                        SELECT ID_TIPO_GARANTIA, FECHA_INSCR, MONTO_MAXIMO_GARANTIZADO, RELACION_BIEN, DESC_GARANTIA, OTROS_TERMINOS_GARANTIA,
                               CAMBIOS_BIENES_MONTO, INSTRUMENTO_PUBLICO, ID_MONEDA, VIGENCIA
                        INTO Reg_Garantias_H.ID_TIPO_GARANTIA, Reg_Garantias_H.FECHA_INSCR, Reg_Garantias_H.MONTO_MAXIMO_GARANTIZADO,
                        Reg_Garantias_H.RELACION_BIEN, Reg_Garantias_H.DESC_GARANTIA, Reg_Garantias_H.OTROS_TERMINOS_GARANTIA, 
                        Reg_Garantias_H.CAMBIOS_BIENES_MONTO, Reg_Garantias_H.INSTRUMENTO_PUBLICO, Reg_Garantias_H.ID_MONEDA,
                        Reg_Garantias_H.VIGENCIA
                        FROM RUG_GARANTIAS_H
                        WHERE ID_GARANTIA = vlIdGarantia
                        AND ID_ULTIMO_TRAMITE = vlIdInscripcion;

                        SELECT TIPO_CONTRATO, FECHA_INICIO, FECHA_FIN, OTROS_TERMINOS_CONTRATO
                        INTO Reg_Contrato_Rug.TIPO_CONTRATO, Reg_Contrato_Rug.FECHA_INICIO, Reg_Contrato_Rug.FECHA_FIN, 
                             Reg_Contrato_Rug.OTROS_TERMINOS_CONTRATO
                        FROM RUG_CONTRATO 
                        WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp
                        AND CLASIF_CONTRATO = 'OB';

                        vlConcatTipoBien := NULL;

                        OPEN CURS_BIENES(Reg_Garantias_H.RELACION_BIEN);
                            LOOP
                                FETCH CURS_BIENES INTO vlIdTipoBien;
                                EXIT WHEN CURS_BIENES%NOTFOUND;
                                vlConcatTipoBien := vlConcatTipoBien ||'|'|| vlIdTipoBien;
                            END LOOP;
                        CLOSE CURS_BIENES;

                        vlConcatTipoBien := SUBSTR(vlConcatTipoBien, 1, LENGTH(vlConcatTipoBien)); 

                        SP_ALTA_GARANTIA(vlIdUsuarioRealiza, vlOutIdTramIncomp, Reg_Garantias_H.ID_TIPO_GARANTIA, Reg_Garantias_H.FECHA_INSCR, 
                                        Reg_Garantias_H.MONTO_MAXIMO_GARANTIZADO, vlConcatTipoBien, Reg_Garantias_H.DESC_GARANTIA, 
                                        Reg_Garantias_H.OTROS_TERMINOS_GARANTIA, Reg_Garantias_H.CAMBIOS_BIENES_MONTO, NULL,
                                        Reg_Garantias_H.INSTRUMENTO_PUBLICO, Reg_Contrato_Rug.TIPO_CONTRATO, Reg_Contrato_Rug.FECHA_INICIO, 
                                        Reg_Contrato_Rug.FECHA_FIN, Reg_Contrato_Rug.OTROS_TERMINOS_CONTRATO, Reg_Garantias_H.ID_MONEDA, 
                                        NULL, NULL, NULL, vlOutIdGarantia, vlOutPsResult, vlOutTxtResult);                                

                        UPDATE RUG_GARANTIAS_PENDIENTES
                        SET VIGENCIA = Reg_Garantias_H.VIGENCIA
                        WHERE ID_GARANTIA_PEND = vlOutIdGarantia;                                 

                         SP_ALTA_BITACORA_TRAMITE2(vlOutIdTramIncomp, 1, 3, NULL, 'V', vlOutPsResult, vlOutTxtResult);                              

                         SP_ALTA_BITACORA_TRAMITE2(vlOutIdTramIncomp, 5, 3, NULL, 'V', vlOutPsResult, vlOutTxtResult);


                     ELSE

                        vlOutPsResult:= -1;
                        vlOutTxtResult:= 'SE GENERO ERROR';

                        --CONTINUE;

                     END IF;  


               ELSE

                    vlOutPsResult:= -1;
                    vlOutTxtResult:= 'SE GENERO ERROR';
                    --CONTINUE;

               END IF;    

            --------------------------------------------------------------------------------
            ----------------------TERMINA PROCESO COPIA DE GARANTIA------------------------- 
            --------------------------------------------------------------------------------


            --------------------------------------------------------------------------------
            ----------------------COMIENZA PROCESO DESHABILITAR GARANTIA-------------------- 
            --------------------------------------------------------------------------------
            /*
            ESTATUS EF = EXCEPCION DE FIRMA;
            */

                UPDATE TRAMITES
                SET STATUS_REG = 'EF'
                WHERE ID_TRAMITE IN (SELECT ID_ULTIMO_TRAMITE FROM RUG_GARANTIAS_H WHERE ID_GARANTIA = vlIdGarantia);

                UPDATE RUG_REL_TRAM_GARAN
                SET STATUS_REG = 'EF', FECHA_REG = SYSDATE
                WHERE ID_GARANTIA = vlIdGarantia;

                UPDATE RUG.RUG_BITAC_TRAMITES
                SET STATUS_REG = 'IN'
                WHERE ID_TRAMITE_TEMP = vlIdTramiteTemp;

                INSERT INTO RUG.RUG_BITAC_TRAMITES (
                ID_TRAMITE_TEMP, ID_STATUS, FECHA_STATUS, 
                ID_PASO, ID_TIPO_TRAMITE, FECHA_REG, STATUS_REG) 
                VALUES (vlIdTramiteTemp, 11, SYSDATE, 0, 1, SYSDATE, 'AC');

                UPDATE RUG_GARANTIAS_H
                SET  STATUS_REG = 'EF'
                WHERE ID_GARANTIA = vlIdGarantia;

                UPDATE RUG_GARANTIAS
                SET  GARANTIA_STATUS = 'EF'
                WHERE ID_GARANTIA = vlIdGarantia;
            --------------------------------------------------------------------------------
            ----------------------TERMINA PROCESO DESHABILITAR GARANTIA-------------------- 
            --------------------------------------------------------------------------------

        vlCountGarantiasInsc := vlCountGarantiasInsc+1;
        END LOOP;
    CLOSE CURS_GARANTIAS_ERROR;

  COMMIT;
  psGarantiasInscritas:= vlCountGarantiasInsc;

  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_DESFIRMADO_GARANTIAS', 'psGarantiasInscritas', psGarantiasInscritas, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_DESFIRMADO_GARANTIAS', 'psResult', psResult, 'OUT');
  REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_DESFIRMADO_GARANTIAS', 'psTxResult', psTxResult, 'OUT');    



EXCEPTION

    WHEN ERRORES THEN
      psResult  := 521;   
      psTxResult:= 'YA FUE DADO DE BAJA';
      DBMS_OUTPUT.PUT_LINE(psTxResult);
      ROLLBACK;

   WHEN OTHERS THEN
      psResult  := 999;   
      psTxResult:= substr(SQLCODE||':'||SQLERRM,1,250);
      ROLLBACK;
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_DESFIRMADO_GARANTIAS', 'psGarantiasInscritas', psGarantiasInscritas, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_DESFIRMADO_GARANTIAS', 'psResult', psResult, 'OUT');
      REG_PARAM_PLS(SEQ_RUG_PARAM_PLS.NEXTVAL, 'SP_DESFIRMADO_GARANTIAS', 'psTxResult', psTxResult, 'OUT');
      DBMS_OUTPUT.PUT_LINE(psTxResult);
END SP_DESFIRMADO_GARANTIAS;
/

