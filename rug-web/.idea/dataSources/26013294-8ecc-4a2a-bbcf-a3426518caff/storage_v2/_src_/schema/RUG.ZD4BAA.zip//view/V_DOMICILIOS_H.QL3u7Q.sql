create view V_DOMICILIOS_H as
SELECT   RDH.ID_TRAMITE,
            RDH.ID_PARTE,
            RDH.ID_PERSONA,
               RDH.CALLE
            || ' '
            || RDH.NUM_EXTERIOR
            || ' '
            || RDH.NUM_INTERIOR
            || ' '
            || RDH.NOM_COLONIA
            || ' '
            || RDH.NOM_DELEG_MUNICIP
            || ' C.P. '
            || RDH.CODIGO_POSTAL
            || ', '
            || RDH.NOM_ESTADO
               AS DOMICILIO,
            1 ID_PAIS_RESIDENCIA
     FROM   RUG.RUG_DOMICILIOS_H RDH
   UNION ALL
   SELECT   REH.ID_TRAMITE,
            REH.ID_PARTE,
            REH.ID_PERSONA,
               REH.UBICA_DOMICILIO_2
            || ' '
            || REH.UBICA_DOMICILIO_1
            || ' '
            || REH.POBLACION
            || ' '
            || REH.ZONA_POSTAL
               AS DOMICILIO,
            REH.ID_PAIS_RESIDENCIA
     FROM   RUG.RUG_DOMICILIOS_EXT_H REH
/

