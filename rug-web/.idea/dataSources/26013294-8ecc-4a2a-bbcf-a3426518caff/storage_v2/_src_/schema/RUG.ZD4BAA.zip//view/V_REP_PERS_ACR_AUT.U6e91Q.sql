create view V_REP_PERS_ACR_AUT as
SELECT   RSU.ID_PERSONA,
            RPF.NOMBRE_PERSONA,
            RPF.AP_PATERNO,
            RPF.AP_MATERNO,
            RSU.CVE_USUARIO,
            RPU.CVE_PERFIL,
            (  SELECT   MAX(TELEFONO
                            || DECODE (EXTENSION, '', '', ' EXT ' || EXTENSION))
                 FROM   RUG.RUG_TELEFONOS
                WHERE   ID_PERSONA = RPF.ID_PERSONA
             GROUP BY   ID_PERSONA)
               TELEFONO
     FROM   RUG.RUG_PERSONAS_FISICAS RPF,
            RUG.RUG_SECU_USUARIOS RSU,
            RUG.RUG_SECU_PERFILES_USUARIO RPU
    WHERE       RPF.ID_PERSONA = RSU.ID_PERSONA
            AND RSU.ID_PERSONA = RPU.ID_PERSONA
            AND CVE_PERFIL IN ('ACREEDOR', 'AUTORIDAD')
/

comment on table V_REP_PERS_ACR_AUT is 'Vista que es utilizada por la aplicacion de reportes que muestra los datos de los usuarios que son acreedores y autoridad'
/

