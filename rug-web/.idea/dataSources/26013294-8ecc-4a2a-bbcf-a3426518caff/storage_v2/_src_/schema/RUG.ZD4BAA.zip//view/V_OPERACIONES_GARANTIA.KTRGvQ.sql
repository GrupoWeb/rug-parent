create view V_OPERACIONES_GARANTIA as
SELECT   T.ID_TRAMITE,
                      RG.ID_GARANTIA,
                      RG.DESC_GARANTIA,
                      TRI.ID_TIPO_TRAMITE,
                      RCTT.DESCRIPCION,
                      T.FECHA_CREACION,
                      RG.ID_PERSONA,
                      PF.NOMBRE_PERSONA
               FROM   RUG_GARANTIAS_H RG
              INNER JOIN RUG_REL_TRAM_GARAN RRTG
                 ON   RRTG.ID_TRAMITE = RG.ID_ULTIMO_TRAMITE
              INNER JOIN TRAMITES T
                 ON   T.ID_TRAMITE = RRTG.ID_TRAMITE
              -- GGR 11042013 - MMESCN2013-81  /* inicio */
--              INNER JOIN TRAMITES_RUG_INCOMP TRI
--                 ON   T.ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP
              INNER JOIN ( SELECT TI.ID_TRAMITE_TEMP
                                , TI.ID_TIPO_TRAMITE
                                , TI.ID_STATUS_TRAM
                             FROM TRAMITES_RUG_INCOMP TI 
                           UNION
                           SELECT TAI.ID_ANOTACION_TEMP
                                , TI.ID_TIPO_TRAMITE
                                , TI.ID_STATUS_TRAM
                             FROM RUG_ANOTACIONES_SEG_INC_CSG TAI
                            INNER JOIN RUG.TRAMITES_RUG_INCOMP TI
                               ON TI.ID_TRAMITE_TEMP = TAI.ID_ANOTACION_TEMP
                            WHERE TAI.STATUS_REG = 'AC'
                              AND TI.STATUS_REG = 'AC' 
                         ) TRI
                 ON   T.ID_TRAMITE_TEMP = TRI.ID_TRAMITE_TEMP
               -- GGR 11042013 - MMESCN2013-81  /* fin */
              INNER JOIN RUG_CAT_TIPO_TRAMITE RCTT
                 ON   T.ID_TIPO_TRAMITE = RCTT.ID_TIPO_TRAMITE
              JOIN RUG_PERSONAS_FISICAS PF
          		 ON PF.ID_PERSONA = T.ID_PERSONA
              WHERE   TRI.ID_STATUS_TRAM = 3
           ORDER BY   T.ID_TRAMITE DESC
/

